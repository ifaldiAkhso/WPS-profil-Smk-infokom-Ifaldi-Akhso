<?php
require_once __DIR__ . '/includes/functions.php';
$pdo = getDB();
$pageTitle = 'Akademik';
$programs = activePrograms();
$sectionsAll = academicSections($pdo, true);
$kurikulumSections = array_values(array_filter($sectionsAll, static fn(array $sec): bool => (string)($sec['section_key'] ?? '') === 'kurikulum'));
$kalenderSections  = array_values(array_filter($sectionsAll, static fn(array $sec): bool => (string)($sec['section_key'] ?? '') === 'kalender'));

$bodyClass = 'page-profil pf-akademik no-tabs';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'Akademik';
$heroTitle   = 'Akademik';
$heroText    = 'Program keahlian, kurikulum, dan kegiatan akademik yang menyiapkan lulusan siap kerja dan berdaya saing.';
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Akademik', null]];
$heroImage = 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';

/** id anchor stabil untuk tiap bagian informasi */
function academicAnchor(array $sec): string
{
    $key = !empty($sec['section_key']) ? preg_replace('/[^a-z0-9-]/', '', strtolower((string)$sec['section_key'])) : '';
    return 'info-' . ($key !== '' ? $key : (!empty($sec['id']) ? (int)$sec['id'] : 'x'));
}
?>
<section class="profile-section">
  <div class="container">

    <div class="profile-tabs-wrap">
      <nav class="profile-tabs profile-tabs-auto" aria-label="Navigasi Akademik">
        <a href="#program-keahlian" class="active"><i class="fa-solid fa-layer-group"></i><span>Program Keahlian</span></a>
        <a href="#info-kurikulum"><i class="fa-solid fa-book-open"></i><span>Kurikulum</span></a>
        <a href="#info-kalender"><i class="fa-solid fa-calendar-check"></i><span>Kalender Pendidikan</span></a>
        <a href="<?= BASE_URL ?>kesiswaan.php"><i class="fa-solid fa-people-group"></i><span>Kesiswaan</span></a>
      </nav>
    </div>

    <div class="profile-heading reveal" id="program-keahlian">
      <div class="article-kicker"><span></span> Program Keahlian <span></span></div>
      <h2>Kompetensi Keahlian SMK INFOKOM BOGOR</h2>
      <p>Kurikulum disusun berbasis kompetensi untuk mempersiapkan lulusan siap kerja dan berdaya saing.</p>
    </div>

    <?php if (count($programs) === 0): ?>
      <div class="empty-state modern-empty" style="margin-top:22px;"><i class="fa-solid fa-layer-group"></i><p>Program keahlian belum tersedia.</p></div>
    <?php else: ?>
      <?php foreach ($programs as $i => $p): ?>
        <?php
        $pk = strtolower(($p['slug'] ?? '') . ' ' . ($p['name'] ?? ''));
        $progClass = preg_match('/rpl|rekayasa perangkat/', $pk) ? ' prog-rpl'
                   : (preg_match('/tkj|teknik komputer|jaringan/', $pk) ? ' prog-tkj'
                   : (preg_match('/dkv|desain komunikasi/', $pk) ? ' prog-dkv'
                   : (preg_match('/pspt|siaran|televisi|produksi/', $pk) ? ' prog-pspt' : '')));
        ?>
        <div class="profile-story-grid program-story reveal<?= $i % 2 === 1 ? ' is-reverse' : '' ?><?= $progClass ?>" id="<?= e($p['slug']) ?>">
          <div class="profile-photo-card">
            <img src="<?= uploadUrl($p['image'], 'assets/images/program-placeholder.jpg') ?>" alt="<?= e($p['name']) ?>">
            <div class="photo-caption"><i class="fa-solid fa-layer-group"></i><span>Program Keahlian</span></div>
          </div>
          <article class="profile-article-card">
            <div class="article-kicker"><span></span> Program Keahlian <span></span></div>
            <h2><?= e($p['name']) ?></h2>
            <div class="article-copy">
              <?php
                $desc = trim((string)($p['description'] ?? ''));
                foreach (preg_split('/\R{2,}/', $desc !== '' ? $desc : 'Deskripsi program keahlian belum diisi.') as $para):
                  if (trim($para) === '') continue;
              ?>
                <p><?= nl2br(e(trim($para))) ?></p>
              <?php endforeach; ?>
            </div>
            <?php if (!empty(trim((string)($p['excellence'] ?? '')))): ?>
              <div class="program-excellence">
                <i class="fa-solid fa-star"></i>
                <div><small>Keunggulan</small><p><?= nl2br(e($p['excellence'])) ?></p></div>
              </div>
            <?php endif; ?>
          </article>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

    <?php if ($kurikulumSections): ?>
      <div class="profile-heading reveal" id="info-kurikulum">
        <div class="article-kicker"><span></span> Kurikulum <span></span></div>
        <h2>Kurikulum yang Diterapkan</h2>
      </div>
      <?php foreach ($kurikulumSections as $sec): ?>
        <?php $kurRows = parseTableLines($sec['content'] ?? ''); ?>
        <article class="cal-card reveal" id="<?= e(academicAnchor($sec)) ?>">
          <div class="cal-card-head"><i class="<?= e($sec['icon'] ?: 'fa-solid fa-book-open') ?>"></i><h3><?= e($sec['title']) ?></h3></div>
          <?php if ($kurRows): ?>
            <div class="cal-table-wrap">
              <table class="cal-table">
                <thead><tr><th>Komponen</th><th>Keterangan</th></tr></thead>
                <tbody>
                  <?php foreach ($kurRows as $row): ?>
                    <tr><td><?= e($row[0]) ?></td><td><?= e($row[1]) ?></td></tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php else: ?>
            <p class="vm-lead"><?= nl2br(e(trim((string)($sec['content'] ?? '')) !== '' ? $sec['content'] : 'Informasi belum diisi.')) ?></p>
          <?php endif; ?>
        </article>
      <?php endforeach; ?>
    <?php endif; ?>

    <?php if ($kalenderSections): ?>
      <div class="profile-heading reveal" id="info-kalender" style="margin-top:56px;">
        <div class="article-kicker"><span></span> Kalender Pendidikan <span></span></div>
        <h2>Agenda &amp; Kalender Pendidikan</h2>
      </div>
      <?php foreach ($kalenderSections as $sec): ?>
        <?php $calRows = parseTableLines($sec['content'] ?? ''); ?>
        <article class="cal-card reveal" id="<?= e(academicAnchor($sec)) ?>">
          <div class="cal-card-head"><i class="<?= e($sec['icon'] ?: 'fa-solid fa-calendar-check') ?>"></i><h3><?= e($sec['title']) ?></h3></div>
          <?php if ($calRows): ?>
            <div class="cal-table-wrap">
              <table class="cal-table">
                <thead><tr><th>Tanggal</th><th>Kegiatan</th></tr></thead>
                <tbody>
                  <?php foreach ($calRows as $row): ?>
                    <tr><td><?= e($row[0]) ?></td><td><?= e($row[1]) ?></td></tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php else: ?>
            <p class="vm-lead"><?= nl2br(e(trim((string)($sec['content'] ?? '')) !== '' ? $sec['content'] : 'Kalender pendidikan belum diisi.')) ?></p>
          <?php endif; ?>
        </article>
      <?php endforeach; ?>
    <?php endif; ?>

  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

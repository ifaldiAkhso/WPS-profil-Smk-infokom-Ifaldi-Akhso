<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-info no-footer';
$pdo = getDB();
$pageTitle = 'Lowongan Kerja';
ensureBkkTables($pdo);

$search   = trim($_GET['q'] ?? '');
$program  = (int)($_GET['jurusan'] ?? 0);
$location = trim($_GET['lokasi'] ?? '');
$company  = (int)($_GET['perusahaan'] ?? 0);
$status   = trim($_GET['status'] ?? '');
$page     = max(1, (int)($_GET['page'] ?? 1));
$perPage  = 9;

$where  = [];
$params = [];
if ($search !== '')   { $where[] = "(jv.position LIKE ? OR jv.company_name LIKE ? OR c.name LIKE ? OR jv.location LIKE ?)"; $like = likeParam($search); array_push($params, $like, $like, $like, $like); }
if ($program > 0)     { $where[] = "(jv.program_id = ? OR jv.program_id IS NULL)"; $params[] = $program; }   // lowongan "Semua Jurusan" ikut tampil di tiap jurusan
if ($location !== '') { $where[] = "jv.location = ?"; $params[] = $location; }
if ($company > 0)     { $where[] = "jv.company_id = ?"; $params[] = $company; }
if ($status === 'aktif')   { $where[] = "jv.status = 'aktif' AND (jv.deadline IS NULL OR jv.deadline >= CURDATE())"; }
elseif ($status === 'ditutup') { $where[] = "(jv.status = 'ditutup' OR (jv.deadline IS NOT NULL AND jv.deadline < CURDATE()))"; }
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM job_vacancies jv LEFT JOIN partner_companies c ON c.id = jv.company_id $whereSql");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($total / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$sql = "SELECT jv.*, jv.company_name AS company_name_free, c.name AS partner_name, c.logo AS company_logo, c.location AS company_location, p.name AS program_name
        FROM job_vacancies jv
        LEFT JOIN partner_companies c ON c.id = jv.company_id
        LEFT JOIN programs p ON p.id = jv.program_id
        $whereSql ORDER BY jv.created_at DESC LIMIT $perPage OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$list = $stmt->fetchAll();

$programs  = activePrograms();
$companies = activePartnerCompanies($pdo);
$locations = array_values(array_filter(array_column(
    $pdo->query("SELECT DISTINCT location FROM job_vacancies WHERE location IS NOT NULL AND location <> '' ORDER BY location ASC")->fetchAll(),
    'location'
)));

function bkkKeepQuery(array $override = []): string
{
    return http_build_query(array_merge($_GET, $override));
}

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'BKK';
$heroTitle   = 'Lowongan Kerja';
$heroText    = 'Informasi lowongan kerja terbaru dari perusahaan mitra SMK INFOKOM BOGOR.';
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['BKK', BASE_URL . 'bkk.php'], ['Lowongan Kerja', null]];
$heroImage   = file_exists(BASE_PATH . '/assets/images/bkk-hero.jpg') ? 'assets/images/bkk-hero.jpg' : 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';
?>
<section class="profile-section">
  <div class="container">

    <div class="profile-heading reveal">
      <div class="article-kicker"><span></span> Lowongan Kerja <span></span></div>
      <h2>Lowongan Kerja (<?= $total ?>)</h2>
      <p>Cari lowongan sesuai jurusan dan lokasi yang kamu inginkan.</p>
    </div>

    <?php
    $fbSearch = $search; $fbPlaceholder = 'Cari posisi, perusahaan, atau lokasi...'; $fbNoun = 'lowongan'; $fbTotal = $total;
    $fbSelects = [
        ['name' => 'jurusan', 'label' => 'Jurusan', 'all' => 'Semua Jurusan', 'options' => array_column($programs, 'name', 'id'), 'value' => $program > 0 ? (string)$program : ''],
        ['name' => 'status', 'label' => 'Status', 'all' => 'Semua Status', 'options' => ['aktif' => 'Aktif', 'ditutup' => 'Ditutup'], 'value' => $status],
    ];
    // Filter Perusahaan hanya muncul bila ada Perusahaan Mitra (lowongan tanpa mitra tetap bisa dicari lewat kolom cari).
    if (count($companies) > 0) {
        array_splice($fbSelects, 1, 0, [['name' => 'perusahaan', 'label' => 'Perusahaan', 'all' => 'Semua Perusahaan', 'options' => array_column($companies, 'name', 'id'), 'value' => $company > 0 ? (string)$company : '']]);
    }
    if (count($locations) > 0) {
        array_splice($fbSelects, 1, 0, [['name' => 'lokasi', 'label' => 'Lokasi', 'all' => 'Semua Lokasi', 'options' => array_combine($locations, $locations), 'value' => $location]]);
    }
    include __DIR__ . '/includes/filter-bar.php';
    ?>

    <?php if (count($list) === 0): ?>
      <div class="empty-state modern-empty" style="margin-top:26px;"><i class="fa-solid fa-briefcase"></i><p>Belum ada lowongan kerja sesuai pencarian/filter.</p></div>
    <?php else: ?>
      <div class="bkk-job-grid">
        <?php foreach ($list as $jv): ?>
          <?php $isOpen = $jv['status'] === 'aktif' && (empty($jv['deadline']) || $jv['deadline'] >= date('Y-m-d')); ?>
          <?php $jvCompany = jobCompanyName($jv); $jvHasPoster = jobHasImage($jv); ?>
          <div class="bkk-job-card reveal">
            <?php if ($jvHasPoster): ?>
              <a class="bkk-job-poster" style="--ar:<?= round(imageRatio($jv['image']), 4) ?>;--bg:url('<?= e(jobImageUrl($jv)) ?>')" href="<?= BASE_URL ?>bkk-lowongan-detail.php?id=<?= (int)$jv['id'] ?>" tabindex="-1" aria-hidden="true">
                <img src="<?= jobImageUrl($jv) ?>" alt="" loading="lazy" onerror="this.closest('.bkk-job-poster').remove();">
              </a>
            <?php endif; ?>
            <div class="bkk-job-body">
              <div class="bkk-job-top">
                <div>
                  <h3><?= e(jobTitle($jv)) ?></h3>
                  <?php if ($jvCompany !== ''): ?><span class="bkk-job-company"><?= e($jvCompany) ?></span><?php endif; ?>
                </div>
              </div>
              <div class="bkk-job-badges">
                <span class="bkk-badge <?= $isOpen ? 'bkk-badge-aktif' : 'bkk-badge-ditutup' ?>"><?= $isOpen ? 'Aktif' : 'Ditutup' ?></span>
                <?php if (!empty($jv['program_name'])): ?><span class="bkk-badge bkk-badge-jurusan"><?= e($jv['program_name']) ?></span><?php endif; ?>
              </div>
              <ul class="bkk-job-meta">
                <?php $jvLoc = jobLocation($jv); if ($jvLoc !== ''): ?><li><i class="fa-solid fa-location-dot"></i> <?= e($jvLoc) ?></li><?php endif; ?>
                <?php if (!empty($jv['deadline'])): ?><li><i class="fa-solid fa-hourglass-half"></i> Batas: <?= tanggalIndo($jv['deadline']) ?></li><?php endif; ?>
              </ul>
              <div class="bkk-job-actions">
                <a href="<?= BASE_URL ?>bkk-lowongan-detail.php?id=<?= (int)$jv['id'] ?>" class="btn btn-outline-navy btn-sm">Detail</a>
                <?php if ($isOpen && !empty($jv['registration_link'])): ?>
                  <a href="<?= e($jv['registration_link']) ?>" target="_blank" rel="noopener" class="btn btn-gold btn-sm">Daftar</a>
                <?php endif; ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <?php if ($totalPages > 1): ?>
      <div class="pagination" style="margin-top:30px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap;">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
          <a href="?<?= bkkKeepQuery(['page' => $i]) ?>" class="btn btn-sm <?= $i === $page ? 'btn-primary' : 'btn-outline-navy' ?>"><?= $i ?></a>
        <?php endfor; ?>
      </div>
      <?php endif; ?>
    <?php endif; ?>

  </div>
</section>
<?php $backHref = BASE_URL . 'bkk.php'; $backLabel = 'Kembali ke BKK'; include __DIR__ . '/includes/back-button.php'; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>

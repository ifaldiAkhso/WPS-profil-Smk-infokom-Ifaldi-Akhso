<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-info no-footer';
$pdo = getDB();
$pageTitle = 'Agenda';
ensureAgendaColumns($pdo);
// Akan datang = tanggal belum lewat, ATAU tanpa tanggal, ATAU diberi status "Akan Datang" oleh admin. Yang bertanggal tampil dulu, tanpa tanggal di akhir.
$upcoming = $pdo->query("SELECT * FROM agendas WHERE event_date IS NULL OR event_date >= CURDATE() OR status = 'akan_datang' ORDER BY (event_date IS NULL) ASC, event_date ASC, id DESC LIMIT 40")->fetchAll();
$past = $pdo->query("SELECT * FROM agendas WHERE event_date < CURDATE() AND status <> 'akan_datang' ORDER BY event_date DESC LIMIT 20")->fetchAll();
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
$heroEyebrow = 'Informasi';
$heroTitle = 'Agenda Sekolah';
$heroText = 'Jadwal kegiatan dan acara SMK INFOKOM BOGOR.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['Agenda', null]];
include __DIR__ . '/includes/page-hero.php';
?>
<section>
  <div class="container">
    <?php foreach ([['Akan Datang', $upcoming, 'Belum ada agenda mendatang.'], ['Telah Berlalu', $past, '']] as [$label, $rows, $empty]): ?>
      <?php if (count($rows) === 0 && $empty === '') continue; ?>
      <div class="profile-heading"><h2><?= e($label) ?></h2></div>
      <?php if (count($rows) === 0): ?>
        <div class="empty-state"><i class="fa-solid fa-calendar-days"></i><p><?= e($empty) ?></p></div>
      <?php else: ?>
        <div class="agenda-list">
          <?php foreach ($rows as $g): $ts = !empty($g['event_date']) ? strtotime($g['event_date']) : null; ?>
            <article class="agenda-item reveal">
              <?php if ($ts && $g['status'] !== 'akan_datang'): ?>
                <div class="agenda-date"><b><?= date('d', $ts) ?></b><span><?= e(date('M Y', $ts)) ?></span></div>
              <?php elseif ($ts): ?>
                <div class="agenda-date is-soon"><b>Akan Datang</b><span><?= e(date('j M Y', $ts)) ?></span></div>
              <?php else: ?>
                <div class="agenda-date is-soon"><b>Akan Datang</b><span>Segera</span></div>
              <?php endif; ?>
              <div>
                <h3><?= e($g['title']) ?></h3>
                <?php if (!empty($g['location'])): ?><div class="agenda-loc"><i class="fa-solid fa-location-dot"></i> <?= e($g['location']) ?></div><?php endif; ?>
                <?php if (trim((string)$g['description']) !== ''): ?><p><?= nl2br(e(trim($g['description']))) ?></p><?php endif; ?>
              </div>
            </article>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    <?php endforeach; ?>
  </div>
</section>
<?php $backHref = BASE_URL . 'index.php'; $backLabel = 'Kembali ke Beranda'; include __DIR__ . '/includes/back-button.php'; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>

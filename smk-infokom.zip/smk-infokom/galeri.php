<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'pf-info';
$pdo = getDB();
$pageTitle = 'Galeri Kegiatan';

// Foto Program Magang ke Jepang TIDAK tampil di galeri umum (hanya di halaman Magang).
$search = trim($_GET['q'] ?? '');
$galleryWhere = galleryPublicSql($pdo, 'g');
$galleryParams = [];
if ($search !== '') {
    $galleryWhere .= " AND g.title LIKE ?";
    $galleryParams = [likeParam($search)];
}
$galleryStmt = $pdo->prepare("SELECT g.* FROM gallery g WHERE $galleryWhere ORDER BY g.created_at DESC, g.id DESC");
$galleryStmt->execute($galleryParams);
$gallery = $galleryStmt->fetchAll();

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>
<?php
$heroEyebrow = 'Informasi';
$heroTitle = 'Galeri Kegiatan';
$heroText = 'Dokumentasi kegiatan dan momen terbaik siswa serta guru SMK INFOKOM BOGOR.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['Galeri', null]];
$heroImage = 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';
?>

<section>
  <div class="container">
    <?php
    $fbSearch = $search; $fbPlaceholder = 'Cari foto kegiatan...'; $fbNoun = 'foto'; $fbTotal = count($gallery); $fbSelects = [];
    include __DIR__ . '/includes/filter-bar.php';
    ?>
    <?php if (count($gallery) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-images"></i><p><?= $search !== '' ? 'Tidak ada foto yang sesuai pencarian.' : 'Belum ada dokumentasi kegiatan.' ?></p></div>
    <?php else: ?>
      <div class="gallery-grid">
        <?php foreach ($gallery as $g): ?>
          <div class="gallery-item reveal">
            <img src="<?= uploadUrl($g['image'], 'assets/images/gallery-placeholder.jpg') ?>" alt="<?= e($g['title'] ?? 'Galeri') ?>" loading="lazy">
            <?php if (trim((string)($g['title'] ?? '')) !== ''): ?><div class="gallery-cap"><?= e($g['title']) ?></div><?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

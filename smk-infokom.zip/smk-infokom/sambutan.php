<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-school no-tabs';
$profile = schoolProfile();
$pageTitle = 'Sambutan Kepala Sekolah';
$activeProfile = 'sambutan.php';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
$message = trim((string)($profile['principal_message'] ?? ''));
?>
<?php
$heroEyebrow = 'Profil Sekolah';
$heroTitle = 'Sambutan Kepala Sekolah';
$heroText = 'Pesan dan harapan kepala sekolah untuk seluruh keluarga besar SMK INFOKOM BOGOR.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Sambutan Kepala Sekolah', null]];
include __DIR__ . '/includes/page-hero.php';
?>

<section class="profile-section">
  <div class="container">
    <?php include __DIR__ . '/includes/profile-nav.php'; ?>

    <article class="principal-modern reveal">
      <div class="principal-modern-media">
        <img src="<?= uploadUrl($profile['principal_photo'] ?? null, 'assets/images/principal-placeholder.jpg') ?>" alt="<?= e($profile['principal_name'] ?? 'Kepala Sekolah') ?>">
        <div class="principal-tag"><i class="fa-solid fa-user-tie"></i><span>Kepala Sekolah</span></div>
      </div>
      <div class="principal-modern-copy">
        <div class="article-kicker"><span></span> Kata Sambutan <span></span></div>
        <h2>Selamat Datang di<br>SMK INFOKOM BOGOR</h2>
        <div class="quote-mark">“</div>
        <div class="principal-message">
          <?= nl2br(e($message !== '' ? $message : 'Sambutan kepala sekolah belum diisi.')) ?>
        </div>
        <div class="principal-signature">
          <strong><?= e($profile['principal_name'] ?? '[Nama Kepala Sekolah]') ?></strong>
          <span>Kepala SMK INFOKOM BOGOR</span>
        </div>
      </div>
    </article>

    <a href="<?= BASE_URL ?>visi-misi.php" class="btn btn-outline-navy profile-back"><i class="fa-solid fa-arrow-left"></i> Kembali ke Visi &amp; Misi</a>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

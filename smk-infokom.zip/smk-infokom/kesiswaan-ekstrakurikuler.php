<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-akademik';
$pdo = getDB();
$pageTitle = 'Ekstrakurikuler';
ensureKesiswaanTables($pdo);

$search   = trim($_GET['q'] ?? '');
$category = trim($_GET['kategori'] ?? '');

$categories = array_values(array_filter(array_column(
    $pdo->query("SELECT DISTINCT category FROM extracurriculars WHERE is_active = 1 AND category IS NOT NULL AND category <> '' ORDER BY category ASC")->fetchAll(),
    'category'
)));

$where = ['is_active = 1'];
$params = [];
if ($search !== '') { $where[] = "(name LIKE ? OR category LIKE ?)"; $like = likeParam($search); array_push($params, $like, $like); }
if ($category !== '') { $where[] = "category = ?"; $params[] = $category; }
$whereSql = 'WHERE ' . implode(' AND ', $where);

$stmt = $pdo->prepare("SELECT * FROM extracurriculars $whereSql ORDER BY sort_order ASC, name ASC");
$stmt->execute($params);
$list = $stmt->fetchAll();

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'Kesiswaan';
$heroTitle   = 'Ekstrakurikuler';
$heroText    = 'Wadah pengembangan bakat dan minat siswa di luar kegiatan belajar mengajar.';
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Kesiswaan', BASE_URL . 'kesiswaan.php'], ['Ekstrakurikuler', null]];
$heroImage = null;
include __DIR__ . '/includes/page-hero.php';
?>
<section class="profile-section">
  <div class="container">

    <div class="profile-heading reveal">
      <div class="article-kicker"><span></span> Ekstrakurikuler <span></span></div>
      <h2>Daftar Ekstrakurikuler</h2>
      <p>Pilih ekstrakurikuler sesuai minat dan bakatmu, lengkap dengan jadwal dan pembina.</p>
    </div>

    <?php
    $fbSearch = $search; $fbPlaceholder = 'Cari nama atau kategori ekstrakurikuler...'; $fbNoun = 'ekstrakurikuler'; $fbTotal = count($list);
    $fbSelects = count($categories) > 0 ? [['name' => 'kategori', 'label' => 'Kategori', 'all' => 'Semua Kategori', 'options' => array_combine($categories, $categories), 'value' => $category]] : [];
    include __DIR__ . '/includes/filter-bar.php';
    ?>

    <?php if (count($list) === 0): ?>
      <div class="empty-state modern-empty" style="margin-top:26px;"><i class="fa-solid fa-person-running"></i><p>Belum ada data ekstrakurikuler sesuai pencarian/filter.</p></div>
    <?php else: ?>
      <div class="ks-ekskul-grid">
        <?php foreach ($list as $ek): ?>
          <div class="ks-ekskul-card reveal">
            <div class="ks-ekskul-media">
              <img src="<?= uploadUrl($ek['photo'], 'assets/images/program-placeholder.jpg') ?>" alt="<?= e($ek['name']) ?>">
              <span class="ks-ekskul-status aktif">Aktif</span>
            </div>
            <div class="ks-ekskul-body">
              <h3><?= e($ek['name']) ?></h3>
              <ul class="ks-ekskul-facts">
                <li><i class="fa-solid fa-clock"></i><div><small>Jadwal</small><strong><?= e($ek['schedule'] ?: 'Belum diinformasikan') ?></strong></div></li>
                <li><i class="fa-solid fa-user-tie"></i><div><small>Pembina</small><strong><?= e($ek['supervisor'] ?: 'Belum diinformasikan') ?></strong></div></li>
                <li><i class="fa-solid fa-location-dot"></i><div><small>Tempat</small><strong><?= e($ek['location'] ?: 'Belum diinformasikan') ?></strong></div></li>
                <li><i class="fa-solid fa-tag"></i><div><small>Kategori</small><strong><?= e($ek['category'] ?: '-') ?></strong></div></li>
              </ul>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

-- Migrasi manual (OPSIONAL: aplikasi sudah menjalankannya otomatis saat halaman admin dibuka).
ALTER TABLE announcements ADD COLUMN image VARCHAR(255) DEFAULT NULL AFTER content;
ALTER TABLE job_vacancies ADD COLUMN company_name VARCHAR(150) DEFAULT NULL AFTER company_id;
ALTER TABLE job_vacancies ADD COLUMN image VARCHAR(255) DEFAULT NULL AFTER company_name;
ALTER TABLE job_vacancies DROP FOREIGN KEY job_vacancies_ibfk_1;
ALTER TABLE job_vacancies MODIFY company_id INT(11) DEFAULT NULL;
ALTER TABLE job_vacancies ADD CONSTRAINT job_vacancies_company_fk FOREIGN KEY (company_id) REFERENCES partner_companies(id) ON DELETE SET NULL;
ALTER TABLE industry_visits MODIFY title VARCHAR(200) DEFAULT NULL;

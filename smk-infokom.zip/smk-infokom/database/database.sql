-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 29 Sep 2026 pada 06.54
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

CREATE DATABASE IF NOT EXISTS `smk_infokom` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `smk_infokom`;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smk_infokom`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `academic_info`
--

CREATE TABLE `academic_info` (
  `id` int(11) NOT NULL,
  `section_key` varchar(60) DEFAULT NULL,
  `title` varchar(150) NOT NULL,
  `content` text DEFAULT NULL,
  `icon` varchar(60) DEFAULT 'fa-solid fa-book-open',
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `academic_info`
--

INSERT INTO `academic_info` (`id`, `section_key`, `title`, `content`, `icon`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'kurikulum', 'Kurikulum', 'Sekolah menerapkan Kurikulum Merdeka yang berfokus pada penguatan kompetensi keahlian dan karakter siswa.\r\nKurikulum Pembelajaran\r\n\r\nKurikulum pembelajaran di sekolah terdiri dari muatan umum,muatan kejuruan sesuai program keahlian, serta program implementasi tambahan yang mendukung pengembangan kompetensi dan pengalaman siswa di dunia industri.\r\n1. Kelompok Muatan Umum\r\n\r\nMata pelajaran muatan umum wajib dipelajari oleh seluruh siswa dari kelas X hingga kelas XII, terlepas dari program keahlian yang dipilih.\r\nMata Pelajaran\r\n\r\n* Pendidikan Agama dan Budi Pekerti\r\n* Pendidikan Pancasila dan Kewarganegaraan (PPKn)\r\n* Bahasa Indonesia\r\n* Matematika\r\n* Sejarah\r\n* Bahasa Inggris dan Bahasa Asing Lainnya\r\n* Pendidikan Jasmani, Olahraga, dan Kesehatan (PJOK)\r\n* Seni Budaya\r\n* Projek Ilmu Pengetahuan Alam dan Sosial (IPAS)\r\n\r\n2. Kelompok Muatan Kejuruan\r\nKelompok muatan kejuruan disesuaikan dengan program keahlian masing-masing siswa.Pembelajaran kejuruan mencakup dasar-dasar program keahlian pada kelas X serta pengembangan kompetensi dan konsentrasi keahlian pada kelas XI dan XII.\r\n\r\nRekayasa Perangkat Lunak (RPL)\r\nBerfokus pada pengembangan perangkat lunak, pemrograman, pengelolaan basis data, serta pengembangan aplikasi berbasis web dan perangkat bergerak.\r\n\r\nMata Pelajaran Kejuruan:\r\n\r\n* Dasar-Dasar Teknik Jaringan Komputer dan Telekomunikasi\r\n* Pemrograman Berorientasi Objek (PBO)\r\n* Pemrograman Web dan Perangkat Bergerak\r\n* Basis Data (Database Management)\r\n* Produk Kreatif dan Kewirausahaan (PKK)\r\n\r\nTeknik Komputer dan Jaringan (TKJ)\r\n\r\nBerfokus pada pembangunan dan pengelolaan infrastruktur jaringan, administrasi sistem, perangkat keras, serta keamanan jaringan.\r\n\r\nMata Pelajaran Kejuruan:\r\n\r\n* Dasar-Dasar Teknik Komputer dan Informatika\r\n* Administrasi Infrastruktur Jaringan (AIJ)\r\n* Administrasi Sistem Jaringan (ASJ)\r\n* Teknologi Jaringan Berbasis Luas (WAN)\r\n* Keamanan Jaringan dan Cyber Security\r\n\r\nDesain Komunikasi Visual (DKV) / Multimedia\r\n\r\nBerfokus pada pengembangan kemampuan desain grafis, ilustrasi, animasi, produksi visual, serta pengolahan audio dan video.\r\n\r\nMata Pelajaran Kejuruan:\r\n\r\n* Dasar-Dasar Seni Visual dan Desain\r\n* Desain Grafis, Percetakan, dan Media Digital\r\n* Animasi 2D dan 3D\r\n* Desain Efek Visual dan Ilustrasi\r\n* Teknik Pengolahan Audio dan Video\r\n\r\nProduksi dan Siaran Program Televisi (Broadcasting)\r\n\r\nBerfokus pada proses produksi program penyiaran, jurnalistik, pengoperasian kamera, tata cahaya, tata suara, hingga proses editing dan pascaproduksi.\r\n\r\nMata Pelajaran Kejuruan:\r\n\r\n* Dasar-Dasar Penyiaran dan Jurnalistik Media\r\n* Manajemen Produksi Siaran Televisi\r\n* Tata Kamera, Tata Cahaya, dan Tata Suara\r\n* Editing Video dan Pascaproduksi Siaran\r\n* Penyutradaraan dan Scriptwriting\r\n\r\n3. Program Implementasi Tambahan\r\n\r\nSelain pembelajaran di kelas, siswa juga mengikuti berbagai program yang bertujuan untuk meningkatkan pengalaman, karakter, kreativitas, serta kesiapan menghadapi dunia kerja.\r\nProjek Penguatan Profil Pelajar Pancasila (P5)\r\n\r\nKegiatan kokurikuler yang dirancang untuk mengembangkan karakter, kreativitas, kolaborasi, serta kepedulian siswa melalui berbagai tema dan projek yang relevan.\r\n\r\nPraktik Kerja Lapangan (PKL)\r\n\r\nProgram pembelajaran berbasis industri yang memberikan kesempatan kepada siswa untuk memperoleh **pengalaman kerja secara langsung** di dunia usaha dan dunia industri.\r\n\r\nPKL dilaksanakan sesuai program dan ketentuan sekolah, terutama sebagai bagian dari persiapan siswa sebelum memasuki dunia kerja maupun melanjutkan pendidikan.\r\n\r\nStruktur Singkat\r\nMuatan Umum\r\n→ Pendidikan umum yang dipelajari seluruh siswa\r\n\r\nMuatan Kejuruan\r\n→ Kompetensi khusus sesuai program keahlian:\r\n\r\n* RPL\r\n* TKJ\r\n* DKV / Multimedia\r\n* Broadcasting\r\n\r\nProgram Implementasi Tambahan\r\n→ P5 dan PKL', 'fa-solid fa-book-open', 1, 1, '2026-09-20 08:29:24', '2026-09-27 20:18:43'),
(2, 'kalender', 'Kalender Pendidikan', 'Kalender pendidikan tahun ajaran berjalan belum diisi. Admin dapat memperbaruinya melalui Dashboard Admin > Akademik.\r\nKalender Pendidikan Tahun Ajaran 2026/2027\r\n\r\nKalender pendidikan berikut memuat jadwal utama kegiatan pembelajaran, asesmen, libur semester, serta kegiatan penting selama Tahun Ajaran 2026/2027.\r\n\r\n Semester 1 (Ganjil)\r\n\r\n| Waktu                               | Kegiatan                                                                                              |\r\n| **13 Juli 2026**                    | Hari pertama masuk sekolah dan awal Tahun Ajaran 2026/2027                                            |\r\n| **13–15 Juli 2026**                 | Masa Pengenalan Lingkungan Sekolah (MPLS) bagi siswa baru kelas X                                     |\r\n| **September 2026**                  | Asesmen Nasional (ANBK) dan perkiraan Sumatif Tengah Semester (STS) / Penilaian Tengah Semester (PTS) |\r\n| **Awal Desember 2026**              | Sumatif Akhir Semester (SAS) / Penilaian Akhir Semester (PAS) Ganjil                                  |\r\n| **18 Desember 2026**                | Pembagian Rapor Semester Ganjil                                                                       |\r\n| **21 Desember 2026–2 Januari 2027** | Libur Semester Ganjil                                                                                 |\r\n\r\nSemester 2 (Genap)\r\n\r\n| Waktu                   | Kegiatan                                                                    |\r\n| **4 Januari 2027**      | Hari pertama masuk sekolah Semester Genap                                   |\r\n| **8–12 Februari 2027**  | Perkiraan libur awal Ramadan 1448 H                                         |\r\n| **8–19 Maret 2027**     | Perkiraan libur Hari Raya Idulfitri 1448 H                                  |\r\n| **Februari–Maret 2027** | Ujian Kompetensi Keahlian (UKK) produktif kejuruan bagi siswa kelas XII     |\r\n| **Mei 2027**            | Perkiraan pengumuman kelulusan siswa kelas XII                              |\r\n| **Awal Juni 2027**      | Sumatif Akhir Tahun (SAT) / Penilaian Akhir Tahun (PAT) bagi kelas X dan XI |\r\n| **25 Juni 2027**        | Pembagian Rapor Semester Genap / Kenaikan Kelas                             |\r\n| **28 Juni–Juli 2027**   | Libur Akhir Tahun Pelajaran                                                 \r\nCatatan\r\n\r\nJadwal pelaksanaan ujian, kegiatan pembelajaran, serta agenda internal SMK Infokom Bogor, seperti kunjungan industri, Praktik Kerja Lapangan (PKL), dan kegiatan sekolah lainnya, dapat disesuaikan dengan kebijakan dan kalender kegiatan sekolah.\r\n\r\nKeterangan:\r\nTanggal yang tercantum di atas merupakan jadwal/perkiraan kegiatan dan dapat mengalami perubahan sesuai dengan ketentuan yang berlaku.', 'fa-solid fa-calendar-check', 2, 1, '2026-09-20 08:29:24', '2026-09-27 20:23:16'),
(3, 'pkl', 'Praktik Kerja Lapangan (PKL)', 'Siswa melaksanakan PKL di industri mitra sesuai kompetensi keahlian masing-masing.', 'fa-solid fa-briefcase', 3, 1, '2026-09-20 08:29:24', '2026-09-20 08:29:24'),
(4, 'ekstrakurikuler', 'Ekstrakurikuler', 'Daftar ekstrakurikuler belum diisi. Admin dapat memperbaruinya melalui Dashboard Admin > Akademik.', 'fa-solid fa-people-group', 4, 1, '2026-09-20 08:29:24', '2026-09-20 08:29:24'),
(5, 'kesiswaan', 'Kesiswaan', 'Bidang Kesiswaan mengelola pembinaan karakter, kedisiplinan, OSIS, dan pengembangan minat-bakat siswa untuk mendukung tumbuh kembang peserta didik secara akademik maupun non-akademik.', 'fa-solid fa-user-graduate', 2, 1, '2026-09-22 12:34:40', '2026-09-22 12:34:40'),
(6, 'bk', 'Bimbingan Konseling (BK)', 'Layanan Bimbingan Konseling mendampingi siswa dalam pengembangan pribadi, sosial, belajar, dan karir, termasuk konsultasi akademik dan pengarahan lanjutan studi.', 'fa-solid fa-comments', 6, 1, '2026-09-22 12:34:40', '2026-09-22 12:34:40'),
(7, 'bkk', 'Bursa Kerja Khusus (BKK)', 'BKK SMK INFOKOM BOGOR menjembatani lulusan dengan dunia industri melalui informasi lowongan kerja, rekrutmen bersama mitra perusahaan, pelatihan kesiapan kerja, dan penyaluran alumni.', 'fa-solid fa-handshake', 7, 1, '2026-09-22 12:34:40', '2026-09-22 12:34:40'),
(8, 'luar-negeri', 'Program Luar Negeri', 'Program kerja sama dan pengembangan wawasan internasional bagi siswa dan lulusan, meliputi informasi magang/kerja ke luar negeri serta kelas persiapan bahasa asing bersama mitra terkait.', 'fa-solid fa-earth-asia', 8, 1, '2026-09-22 12:34:40', '2026-09-22 12:34:40');

-- --------------------------------------------------------

--
-- Struktur dari tabel `achievements`
--

CREATE TABLE `achievements` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `level` enum('Kabupaten/Kota','Provinsi','Nasional','Internasional') DEFAULT 'Kabupaten/Kota',
  `year` year(4) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `source_url` varchar(500) DEFAULT NULL,
  `source_name` varchar(150) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `role` enum('superadmin','admin') DEFAULT 'admin',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `admins`
--

INSERT INTO `admins` (`id`, `username`, `email`, `password`, `full_name`, `photo`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@smkinfokombogor.sch.id', '$2b$10$TPn0g//uVB/aI0ymmrE/zukWnOAYjtYG/WDbKsA00/zcWOo.gybE6', 'Administrator', 'lainnya/dda474ff90f816d03da07db1.png', 'superadmin', 1, '2026-09-29 08:52:52', '2026-09-19 20:07:37', '2026-09-29 09:40:35');

-- --------------------------------------------------------

--
-- Struktur dari tabel `agendas`
--

CREATE TABLE `agendas` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `event_date` date NOT NULL,
  `location` varchar(150) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `file_attachment` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `banners`
--

CREATE TABLE `banners` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `button_text` varchar(50) DEFAULT NULL,
  `button_link` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `banners`
--

INSERT INTO `banners` (`id`, `title`, `subtitle`, `image`, `button_text`, `button_link`, `is_active`, `sort_order`, `created_at`) VALUES
(2, 'SMK INFOKOM KOTA BOGOR', 'SMK INFORMATIKA &\r\nTELEKOMUNIKASI (INFOKOM) KOTA BOGOR', 'lainnya/fd62d225a63434b3e45f7ef6.png', '', '', 1, 0, '2026-09-20 11:25:33');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bkk_sections`
--

CREATE TABLE `bkk_sections` (
  `id` int(11) NOT NULL,
  `section_key` varchar(60) DEFAULT NULL,
  `title` varchar(150) NOT NULL,
  `content` text DEFAULT NULL,
  `icon` varchar(60) DEFAULT 'fa-solid fa-briefcase',
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `bkk_sections`
--

INSERT INTO `bkk_sections` (`id`, `section_key`, `title`, `content`, `icon`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'tentang', 'Tentang BKK', 'Tentang BKK menjelaskan mengenai keberadaan dan peran Bursa Kerja Khusus di SMK INFOKOM. BKK merupakan bagian dari sekolah yang membantu menghubungkan lulusan dengan dunia kerja dan dunia industri. Melalui BKK, siswa dan alumni dapat memperoleh informasi mengenai lowongan pekerjaan, kebutuhan tenaga kerja, proses rekrutmen, serta berbagai kegiatan yang berkaitan dengan persiapan memasuki dunia kerja.\r\n\r\nBKK SMK INFOKOM juga menjadi sarana untuk membantu siswa mempersiapkan diri sebelum memasuki dunia profesional. Kegiatan yang dapat dilakukan antara lain pemberian informasi karier, pendataan alumni, penyampaian informasi lowongan kerja, serta koordinasi dengan perusahaan atau mitra industri yang membutuhkan tenaga kerja sesuai kompetensi lulusan.', 'fa-solid fa-building-user', 1, 1, '2026-09-22 20:01:44', '2026-09-28 20:57:10'),
(2, 'tujuan', 'Tujuan BKK', 'Tujuan BKK adalah membantu siswa dan lulusan SMK INFOKOM agar memiliki akses yang lebih mudah terhadap informasi dan kesempatan kerja yang sesuai dengan kompetensi mereka. BKK juga bertujuan meningkatkan kesiapan siswa dalam menghadapi proses rekrutmen serta memberikan gambaran mengenai kebutuhan dan tuntutan dunia kerja.\r\n\r\nSelain itu, BKK berperan dalam membangun hubungan yang baik antara sekolah dengan dunia usaha dan dunia industri. Dengan adanya kerja sama tersebut, sekolah dapat memperoleh informasi mengenai kebutuhan tenaga kerja sehingga pembinaan dan persiapan siswa dapat lebih sesuai dengan perkembangan dunia kerja.', 'fa-solid fa-bullseye', 2, 1, '2026-09-22 20:01:44', '2026-09-28 20:57:52'),
(3, 'fungsi', 'Fungsi BKK', 'BKK memiliki fungsi sebagai pusat informasi dan layanan karier bagi siswa tingkat akhir maupun alumni SMK INFOKOM. BKK membantu menyampaikan berbagai informasi terkait lowongan pekerjaan, perusahaan mitra, proses seleksi, jadwal rekrutmen, serta persyaratan yang harus dipenuhi oleh calon pelamar.\r\n\r\nFungsi lainnya adalah membantu siswa dalam mempersiapkan diri menghadapi dunia kerja, seperti memberikan informasi mengenai proses pembuatan lamaran, wawancara kerja, etika di tempat kerja, dan kesiapan kompetensi. BKK juga dapat melakukan pendataan alumni serta membangun komunikasi dengan perusahaan untuk menciptakan peluang kerja bagi lulusan.', 'fa-solid fa-gears', 3, 1, '2026-09-22 20:01:44', '2026-09-28 20:58:14'),
(4, 'layanan', 'Layanan BKK', 'Layanan BKK merupakan berbagai bentuk bantuan yang diberikan kepada siswa dan alumni dalam proses persiapan dan pencarian kerja. Layanan tersebut dapat mencakup penyebaran informasi lowongan pekerjaan, informasi rekrutmen perusahaan, pendataan pencari kerja, serta pemberian informasi mengenai jadwal dan tahapan seleksi.\r\n\r\nBKK juga dapat menyediakan layanan pendampingan karier, informasi persyaratan pekerjaan, serta membantu siswa memahami proses rekrutmen dari tahap pendaftaran hingga seleksi. Dengan layanan tersebut, siswa dan alumni diharapkan dapat memperoleh informasi kerja yang lebih terarah serta mempersiapkan diri secara lebih baik sebelum memasuki dunia profesional.', 'fa-solid fa-handshake', 4, 1, '2026-09-22 20:01:44', '2026-09-28 20:58:50');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bkk_settings`
--

CREATE TABLE `bkk_settings` (
  `id` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `contact_phone` varchar(50) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `contact_address` varchar(255) DEFAULT NULL,
  `coordinator_name` varchar(150) DEFAULT NULL,
  `coordinator_position` varchar(150) DEFAULT NULL,
  `coordinator_photo` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `bkk_settings`
--

INSERT INTO `bkk_settings` (`id`, `description`, `contact_phone`, `contact_email`, `contact_address`, `coordinator_name`, `coordinator_position`, `coordinator_photo`, `updated_at`) VALUES
(1, 'Bursa Kerja Khusus (BKK) SMK INFOKOM merupakan layanan sekolah yang membantu siswa tingkat akhir dan alumni dalam mempersiapkan diri memasuki dunia kerja.', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-28 21:01:17');

-- --------------------------------------------------------

--
-- Struktur dari tabel `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `extracurriculars`
--

CREATE TABLE `extracurriculars` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(170) NOT NULL,
  `category` varchar(80) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `schedule` varchar(150) DEFAULT NULL,
  `supervisor` varchar(150) DEFAULT NULL,
  `location` varchar(150) DEFAULT NULL,
  `achievement_note` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `extracurriculars`
--

INSERT INTO `extracurriculars` (`id`, `name`, `slug`, `category`, `photo`, `description`, `schedule`, `supervisor`, `location`, `achievement_note`, `is_active`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 'PASKIBRA', 'paskibra', NULL, 'kesiswaan/ekstrakurikuler/f79ef54179367171c92dd4fd.jpg', '', 'Jumat, 15.30–17.00 WIB', 'Pembina Paskibra SMK INFOKOM', 'Lapangan sekolah', '', 1, 0, '2026-09-27 20:30:28', '2026-09-28 20:34:23'),
(2, 'PMR', 'pmr', NULL, 'kesiswaan/ekstrakurikuler/f81a7bdd5523410eefecada9.jpg', '', 'Sabtu, 08.00–10.00 WIB', 'Pembina PMR SMK INFOKOM', 'Ruang UKS & lingkungan sekolah', '', 1, 0, '2026-09-27 20:32:24', '2026-09-28 20:36:29'),
(3, 'PRAMUKA', 'pramuka-2', NULL, 'kesiswaan/ekstrakurikuler/70a243638413466681c589bd.jpg', '', 'Sabtu, 14.00–16.00 WIB', 'Pembina Pramuka SMK INFOKOM', 'Lapangan sekolah', '', 1, 0, '2026-09-27 20:35:16', '2026-09-28 20:35:30');

-- --------------------------------------------------------

--
-- Struktur dari tabel `facilities`
--

CREATE TABLE `facilities` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `facilities`
--

INSERT INTO `facilities` (`id`, `name`, `image`, `description`, `sort_order`, `created_at`) VALUES
(3, 'LAPANGAN', 'fasilitas/3db51b71be55a17d31bdba5a.jpg', '', 0, '2026-09-27 19:45:06'),
(4, 'TOILET', 'fasilitas/ae0e79976c2ef5912ca6e723.jpg', '', 0, '2026-09-27 19:55:48'),
(5, 'PERPUSTAKAAN', 'fasilitas/df8763298692eb90ea5d1c56.jpg', '', 0, '2026-09-27 19:57:21'),
(6, 'LAB (RPL)', 'fasilitas/f81f176339f1745c4a4f6434.jpg', '', 0, '2026-09-27 19:57:38'),
(7, 'GEDUNG BELAKANG', 'fasilitas/9467cfa7a10b56878b74856a.jpg', '', 0, '2026-09-27 19:58:03'),
(8, 'ADMINISTRASI', 'fasilitas/81cf30be8e99aaa638398dd3.jpg', '', 0, '2026-09-27 19:58:47'),
(9, 'MUSHOLA', 'fasilitas/e239d17bc35e5325090739dd.jpg', '', 0, '2026-09-27 19:59:07'),
(10, 'RUANG GURU', 'fasilitas/c8964b51b5e7129353564bb5.jpg', '', 0, '2026-09-27 19:59:28'),
(11, 'LAB (TKJ)', 'fasilitas/2c9195abec99811291c199f2.jpg', '', 0, '2026-09-27 19:59:50'),
(12, 'GEDUNG DEPAN', 'fasilitas/5f379e368260c73d244c354c.jpg', '', 0, '2026-09-27 20:00:17'),
(13, 'TATA USAHA (TU)', 'fasilitas/78998a30221271d766838314.jpg', '', 0, '2026-09-27 20:01:02'),
(14, 'LAB (DKV)', 'fasilitas/d99ebea58b2457e34a4704bf.jpg', '', 0, '2026-09-27 20:01:28'),
(15, 'RUANG KELAS', 'fasilitas/e27bed79d1755040c7613226.jpg', '', 0, '2026-09-27 20:01:50'),
(16, 'KANTIN', 'fasilitas/ce136444d1c1599e00f3b7de.jpg', '', 0, '2026-09-27 20:02:17'),
(17, 'STUDIO (PSPT)', 'fasilitas/48263cdde7d2e565730e18d7.jpg', '', 0, '2026-09-27 20:02:50');

-- --------------------------------------------------------

--
-- Struktur dari tabel `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(150) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `gallery`
--

INSERT INTO `gallery` (`id`, `category_id`, `title`, `image`, `created_at`) VALUES
(1, 1, 'lomba 17 agustus', 'galeri/4005f7c3172308336d5baf63.jpg', '2026-09-22 09:17:55'),
(2, 1, 'upacara  bendera', 'galeri/e52e1efe51c95b42a2a962a3.jpeg', '2026-09-22 09:18:39'),
(3, 1, 'upacara 17 agustus', 'galeri/577100e38dc1494f2791b091.jpg', '2026-09-22 09:19:50'),
(4, NULL, '', 'galeri/b8909d4be87b52f84aefdf99.jpg', '2026-09-22 09:39:14'),
(13, 8, 'IRFAN RIZQOLLAH', 'galeri/03d96a61f6167b35cf247598.jpg', '2026-09-29 09:42:00'),
(14, 8, 'ANGELIA CALLISTA', 'galeri/b58149f5904d8fc5bc7c1f20.jpg', '2026-09-29 09:42:44'),
(15, 8, 'NAJIB SOFIAN', 'galeri/b08d440c7185aa848275f5e8.jpg', '2026-09-29 09:43:28'),
(16, 8, 'SURYA DIFRAJA', 'galeri/7af1c6cceade2e3e168bb778.jpg', '2026-09-29 09:44:04'),
(17, 8, 'AZZAHRA PUJIA', 'galeri/d98fdb6a3be4dea0f0cd0c52.jpg', '2026-09-29 09:44:43');

-- --------------------------------------------------------

--
-- Struktur dari tabel `gallery_categories`
--

CREATE TABLE `gallery_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `gallery_categories`
--

INSERT INTO `gallery_categories` (`id`, `name`, `slug`) VALUES
(1, 'Kegiatan Sekolah', 'kegiatan-sekolah'),
(2, 'Pembelajaran', 'pembelajaran'),
(3, 'Praktik', 'praktik'),
(4, 'Lomba', 'lomba'),
(5, 'Prestasi', 'prestasi'),
(6, 'Event', 'event'),
(7, 'Ekstrakurikuler', 'ekstrakurikuler'),
(8, 'Program Jepang', 'program-jepang');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jepang_profile`
--

CREATE TABLE `jepang_profile` (
  `id` int(11) NOT NULL,
  `about` text DEFAULT NULL,
  `purpose` text DEFAULT NULL,
  `target_participants` text DEFAULT NULL,
  `duration` varchar(150) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `important_info` text DEFAULT NULL,
  `source_url` varchar(500) DEFAULT NULL,
  `source_name` varchar(150) DEFAULT NULL,
  `video_url` text DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `jepang_profile`
--

INSERT INTO `jepang_profile` (`id`, `about`, `purpose`, `target_participants`, `duration`, `status`, `important_info`, `source_url`, `source_name`, `video_url`, `updated_at`) VALUES
(1, 'Program Kerja ke Jepang merupakan program persiapan dan pengembangan kompetensi bagi siswa dan lulusan yang memiliki minat untuk memperoleh pengalaman kerja di Jepang. Program ini membekali peserta dengan kemampuan bahasa Jepang, kedisiplinan, keterampilan kerja, serta pemahaman budaya dan lingkungan kerja Jepang.', 'Mempersiapkan peserta agar memiliki kompetensi dan sikap kerja yang sesuai dengan kebutuhan dunia industri.\r\nMeningkatkan kemampuan komunikasi bahasa Jepang.\r\nMemberikan pemahaman mengenai budaya dan etika kerja di Jepang.\r\nMembekali peserta dengan kesiapan administrasi dan proses seleksi kerja.\r\nMembuka peluang pengalaman kerja internasional bagi peserta.', 'Program ditujukan bagi siswa tingkat akhir dan/atau lulusan SMK yang memenuhi persyaratan program serta memiliki minat untuk mengikuti proses persiapan dan seleksi kerja ke Jepang.', 'Disesuaikan dengan program dan ketentuan penyelenggara.', 'Program dan proses pendaftaran disesuaikan dengan informasi serta kerja sama yang sedang berlaku.', NULL, NULL, NULL, 'https://youtu.be/Mu-SRdUvVVk?si=cqC7tPXLpCGOUqKW', '2026-09-28 21:03:58');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jepang_sections`
--

CREATE TABLE `jepang_sections` (
  `id` int(11) NOT NULL,
  `module` enum('persyaratan','pelatihan_bahasa','pelatihan_kompetensi','budaya_etika','tahapan') NOT NULL,
  `tag` varchar(80) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `content` text DEFAULT NULL,
  `icon` varchar(60) DEFAULT 'fa-solid fa-circle-info',
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `jepang_sections`
--

INSERT INTO `jepang_sections` (`id`, `module`, `tag`, `title`, `content`, `icon`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'persyaratan', 'Persyaratan Umum', 'Persyaratan Mengikuti Program', 'Persyaratan dapat ditetapkan oleh sekolah dan mitra program. Secara umum peserta perlu:\r\n\r\nBerstatus sebagai siswa kelas akhir atau lulusan SMK sesuai ketentuan program.\r\nMemiliki kondisi fisik dan kesehatan yang memenuhi persyaratan.\r\nMemiliki kedisiplinan dan sikap kerja yang baik.\r\nBersedia mengikuti pembelajaran dan pelatihan bahasa Jepang.\r\nBersedia mengikuti seluruh tahapan seleksi.\r\nMemenuhi persyaratan administrasi dan dokumen yang ditentukan.\r\nMemiliki komitmen untuk mengikuti program sampai selesai.', 'fa-solid fa-circle-info', 0, 1, '2026-09-28 09:39:51', '2026-09-28 09:39:51');

-- --------------------------------------------------------

--
-- Struktur dari tabel `job_vacancies`
--

CREATE TABLE `job_vacancies` (
  `id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `company_name` varchar(150) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `position` varchar(150) NOT NULL,
  `program_id` int(11) DEFAULT NULL,
  `location` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `registration_link` varchar(255) DEFAULT NULL,
  `status` enum('aktif','ditutup') DEFAULT 'aktif',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `slug` varchar(220) NOT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `excerpt` varchar(300) DEFAULT NULL,
  `content` text NOT NULL,
  `source_url` varchar(500) DEFAULT NULL,
  `source_name` varchar(150) DEFAULT NULL,
  `status` enum('draft','published') DEFAULT 'draft',
  `views` int(11) DEFAULT 0,
  `published_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `news`
--

INSERT INTO `news` (`id`, `category_id`, `admin_id`, `title`, `slug`, `thumbnail`, `excerpt`, `content`, `source_url`, `source_name`, `status`, `views`, `published_at`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Kegiatan Pengabdian kepada Masyarakat melalui Pelatihan Informatika di SMK Infokom Bogor', 'kegiatan-pengabdian-kepada-masyarakat-melalui-pelatihan-informatika-di-smk-infokom-bogor-443c7', 'berita/6cd7ef102a8a14ac4da486af.jpg', 'Kegiatan pengabdian kepada masyarakat yang dilaksanakan di SMK Infokom Bogor. Kegiatan ini berupa pelatihan informatika yang melibatkan mahasiswa dan siswa dalam proses belajar bersama, meningkatkan keterampilan teknologi, serta mempererat kerja sama di bidang pendidikan.', 'SMK Infokom Bogor melaksanakan kegiatan pengabdian kepada masyarakat berupa pelatihan informatika. Kegiatan ini diikuti oleh siswa dan mahasiswa yang bersama-sama belajar dan mempraktikkan keterampilan teknologi. Melalui kegiatan ini, siswa diharapkan dapat meningkatkan pengetahuan, kreativitas, dan kemampuan di bidang informatika.', NULL, NULL, 'published', 5, '2026-09-22 04:34:49', '2026-09-22 09:34:49', '2026-09-29 11:47:03'),
(2, 1, 1, 'Gelar Karya dan Gelar Budaya: Wujud Kreativitas dan Pelestarian Budaya', 'gelar-karya-dan-gelar-budaya-wujud-kreativitas-dan-pelestarian-budaya-65b27', 'berita/5a5805f86297fe1132909a8b.jpg', 'Gelar Karya dan Gelar Budaya: Wujud Kreativitas dan Pelestarian Budaya', 'SMK Infokom Bogor turut berpartisipasi dalam kegiatan Gelar Karya dan Gelar Budaya. Kegiatan ini menjadi wadah bagi siswa untuk menampilkan kreativitas, bakat, dan kemampuan dalam bidang seni serta budaya. Melalui acara ini, diharapkan siswa dapat meningkatkan rasa percaya diri, melestarikan budaya, dan mengembangkan potensi diri.', NULL, NULL, 'published', 1, '2026-09-22 04:40:46', '2026-09-22 09:40:24', '2026-09-22 10:34:57'),
(3, 1, 1, 'Peringatan Maulid Nabi Muhammad SAW', 'peringatan-maulid-nabi-muhammad-saw-27c88', 'berita/84857d9a707d6f1fd6651570.jpg', 'SMK INFOKOM Bogor menyelenggarakan Peringatan Maulid Nabi Muhammad SAW pada Kamis, 27 Agustus 2026 dengan tema “Menjadikan Rasulullah SAW sebagai Teladan Utama dalam Etika di Lingkungan Sekolah dan Bermasyarakat\".', 'SMK INFOKOM Bogor akan menyelenggarakan kegiatan Peringatan Maulid Nabi Muhammad SAW pada Kamis, 27 Agustus 2026, bertepatan dengan 14 Rabi’ul Awal 1448 H.\r\n\r\nKegiatan ini mengusung tema “Menjadikan Rasulullah SAW sebagai Teladan Utama dalam Etika di Lingkungan Sekolah dan Bermasyarakat.” Tema tersebut menjadi pengingat bagi seluruh warga sekolah untuk menjadikan akhlak dan keteladanan Rasulullah SAW sebagai pedoman dalam kehidupan sehari-hari, khususnya dalam membangun etika yang baik di lingkungan sekolah maupun masyarakat.\r\n\r\nDalam poster kegiatan, acara menghadirkan Ust. Arian Faqih sebagai pengisi kajian. Kegiatan ini menjadi bagian dari upaya SMK INFOKOM Bogor dalam menanamkan nilai-nilai keagamaan, membentuk karakter peserta didik, serta meningkatkan sikap saling menghormati dan berakhlak mulia.', 'https://www.instagram.com/p/DcciRUJoev0/?stkn=MWF1OWs2dzhxNzAwMA==', NULL, 'published', 4, '2026-09-28 15:50:10', '2026-09-28 20:50:10', '2026-09-29 11:44:46');

-- --------------------------------------------------------

--
-- Struktur dari tabel `news_categories`
--

CREATE TABLE `news_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `news_categories`
--

INSERT INTO `news_categories` (`id`, `name`, `slug`) VALUES
(1, 'Kegiatan Sekolah', 'kegiatan-sekolah'),
(2, 'Prestasi', 'prestasi'),
(3, 'Pengumuman', 'pengumuman'),
(4, 'Akademik', 'akademik');

-- --------------------------------------------------------

--
-- Struktur dari tabel `news_gallery`
--

CREATE TABLE `news_gallery` (
  `id` int(11) NOT NULL,
  `news_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `organization_structure`
--

CREATE TABLE `organization_structure` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `position` varchar(150) NOT NULL,
  `group_name` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `organization_structure`
--

INSERT INTO `organization_structure` (`id`, `name`, `position`, `group_name`, `photo`) VALUES
(1, 'Ir. Hj. Liliek Rahmaningsih, M.MPd', 'kepala sekolah', 'Pimpinan', 'lainnya/d283da8c821878d5234eca22.jpg'),
(2, 'Dea Rijalul Fikri, S.Kom.,Gr.', 'Wakil Kepala Sekolah Bidang Kesiswaan', 'Kesiswaan & Kurikulum', 'lainnya/71a88a463450f8ab57538fb6.jpg'),
(4, 'R. Radiani Srirestuti Dewi, SS.,Gr.', 'Wakil Kepala Sekolah Bidang Hubungan Industri dan Masyarakat', 'Bidang Sarana dan Prasarana,PSDM,HUBINMAS', 'lainnya/e1af5bd5401596034ff6d2ac.jpg'),
(5, 'Mila Yaelasari, M.Pd.', 'Wakil Kepala Sekolah Bidang Kurikulum', 'Kesiswaan & Kurikulum', 'lainnya/9a7d28969075a5e10aa86f7e.jpg'),
(6, 'Heny Handayani, S.Pd.', 'Wakil Kepala Sekolah Bidang Pengembangan Sumber Daya Manusia', 'Bidang Sarana dan Prasarana,PSDM,HUBINMAS', 'lainnya/f40074a17fc4aa271e873c52.jpg'),
(7, 'Agus Tiyono, M.Pd.', 'Wakil Kepala Sekolah Bidang Sarana dan Prasarana', 'Bidang Sarana dan Prasarana,PSDM,HUBINMAS', 'lainnya/43773c537ae03c5fdf83bde7.jpg'),
(8, 'Aditya Nugraha, ST.', 'Ketua Manajemen Mutu Kepala & Program Keahlian Jurusan TKJ', 'program keahlian (jurusan)', 'lainnya/ef3dee3e3f85df7848908013.jpg'),
(9, 'Cahyadi Rozi, ST.', 'Kepala Tata Usaha', 'Kepala Tata Usaha,Kepala Bendahara & ⁠Kepala Perpustakaan', 'lainnya/041607dbcaad3e8b0cfe9e1c.jpg'),
(10, 'Drs. Puji Marhaen Waluyo', '⁠Kepala Perpustakaan', 'Kepala Tata Usaha,Kepala Bendahara & ⁠Kepala Perpustakaan', 'lainnya/6a555708cd29f767cb55dd7f.jpg'),
(11, 'Putri Riandini, S.Hut., M.Pd.,Gr.', 'Kepala Bendahara', 'Kepala Tata Usaha,Kepala Bendahara & ⁠Kepala Perpustakaan', 'lainnya/6a2b545ff588c1ff654a5293.jpg'),
(12, 'Muhammad Ibnu Arif, S.IKom.', 'Kepala Program Keahlian DKV', 'program keahlian (jurusan)', 'lainnya/05ca1984e542915ebfeee98e.jpg'),
(13, 'Ridwan Hala, S.Kom.,Gr.', 'Kepala Program Keahlian RPL', 'program keahlian (jurusan)', 'lainnya/e2ef174a4cdaa8d880e49760.jpg'),
(14, '⁠Erli Suherli, A.Md.Kom.', 'Kepala Program Keahlian PSPT', 'program keahlian (jurusan)', 'lainnya/132183145be210c8c653ebfb.jpg'),
(15, 'Ahmad Hotib, S.Pd.I', 'pembina osis', 'Pembina OSIS', 'lainnya/0c91285c649b833b4a4f1624.jpg'),
(16, 'Abdul Azis, M.Pd.', 'pembina osis', 'Pembina OSIS', 'lainnya/a49a1922ee569e01a69b6080.jpg'),
(17, 'Vera Yuni Astuti, SP., M.IKom.,Gr.', 'Kurikulum', '⁠Staf Kurikulum', 'lainnya/ee29d6cbc4e0561b906b8d38.jpg'),
(18, 'M. Fauzan Arifin, S.IKom.,Gr.', 'Kurikulum', '⁠Staf Kurikulum', 'lainnya/d7dd2f3a190a10d4c48f2394.jpg'),
(19, 'Dian Hardianti, S.Kom.,Gr.', 'BK', 'Bimbingan & Konseling', 'lainnya/b7993870e449144f42dafc3d.jpg'),
(20, 'Dra. Popon Puspitasari', 'BK', 'Bimbingan & Konseling', 'lainnya/332f1488c1b337eae5a70c99.jpg'),
(21, 'Richo Santana, S.Kom.', 'BK', 'Bimbingan & Konseling', 'lainnya/8afa2bb29e18ddc05c485d06.jpg'),
(22, 'Yeni Yuliawati, S.Pd.,Gr.', '⁠Staf Teller (Bendahara)', '⁠Staf Teller (Bendahara)', 'lainnya/369f63f1908683d00dd31b5f.jpg'),
(23, 'Rita Widyastuti', 'Staf Teller (Bendahara)', '⁠Staf Teller (Bendahara)', 'lainnya/ec8a7a59c58d27e46e1bdd37.jpg'),
(24, 'Eva Farida Rahayu, S.Pd.,Gr.', '⁠Staf Teller (Bendahara)', '⁠Staf Teller (Bendahara)', 'lainnya/a61ec8d5ac6d941c45db73ab.jpg'),
(25, 'Jayadi, S.Pd.,Gr.', 'Staf Tata Usaha', 'Staf Tata Usaha', 'lainnya/b46800e778b1169b012a65ea.jpg'),
(26, 'Yadi Setiadi, S.Sos.,Gr.', 'Staf Tata Usaha', 'Staf Tata Usaha', 'lainnya/e96cbef475fb014d744e39e9.jpg'),
(27, 'Siti Nuraeni', 'Staf Tata Usaha', 'Staf Tata Usaha', 'lainnya/006d1f5267df56aef9420b00.jpg'),
(28, 'Reza Prafitriansyah, S.Kom.,Gr.', '⁠Staf Perpustakaan', '⁠Staf Perpustakaan', 'lainnya/fc4a4ec41d136bf766686e7e.jpg'),
(29, 'Dra. Diana Octaria', 'guru', 'bidang lainnya', 'lainnya/263f57b122a580f28ff08d79.jpg'),
(30, 'Erwin Hasiholan Gultom, S.Kom.', 'guru', 'bidang lainnya', 'lainnya/4a3d5c5c0af286a1955b2eb9.jpg'),
(31, 'Dara Purwanita, S.Pd.,Gr.', 'guru', 'bidang lainnya', 'lainnya/c35b3a72989cf0c3ac561a6a.png'),
(32, 'Widyatama Nuranisa, SM.', 'guru', 'bidang lainnya', 'lainnya/5dfb0b5eee34d167a2b4e552.png'),
(33, 'Nabila Ahmadia Pratama, S.Pd.', 'guru', 'bidang lainnya', 'lainnya/09d1e08fabb3801cbc6befdb.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `partner_companies`
--

CREATE TABLE `partner_companies` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `field` varchar(150) DEFAULT NULL,
  `location` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `is_partner` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `partner_companies`
--

INSERT INTO `partner_companies` (`id`, `name`, `logo`, `field`, `location`, `description`, `website`, `is_partner`, `created_at`, `updated_at`) VALUES
(1, 'PT Syngenta Indonesia', 'bkk/perusahaan/7d88766f8365a309bda5a896.jpg', 'Pertanian, perlindungan tanaman, benih, dan solusi pertanian', 'Jakarta Selatan, dengan fasilitas industri antara lain di Cikampek dan Gunung Putri, Jawa Barat.', 'PT Syngenta Indonesia merupakan perusahaan yang bergerak di bidang pertanian dan menyediakan berbagai solusi untuk membantu meningkatkan produktivitas pertanian, termasuk produk perlindungan tanaman, benih, serta teknologi dan solusi pertanian. Syngenta Indonesia juga memiliki fasilitas riset, pengembangan, dan produksi di Indonesia. Perusahaan ini berpartisipasi dalam kegiatan Campus Hiring Polbangtan Bogor sebagai bagian dari hubungan dengan dunia usaha dan dunia industri.', 'https://www.syngenta.co.id', 1, '2026-09-28 21:09:59', '2026-09-28 21:09:59');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pkl_items`
--

CREATE TABLE `pkl_items` (
  `id` int(11) NOT NULL,
  `kind` varchar(20) NOT NULL,
  `title` varchar(150) NOT NULL,
  `content` text DEFAULT NULL,
  `icon` varchar(60) DEFAULT 'fa-solid fa-circle-check',
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pkl_items`
--

INSERT INTO `pkl_items` (`id`, `kind`, `title`, `content`, `icon`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'tujuan', 'Menerapkan Kompetensi', 'Mempraktikkan ilmu dan keterampilan dari kelas ke pekerjaan nyata di industri.', 'fa-solid fa-screwdriver-wrench', 1, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(2, 'tujuan', 'Membangun Etos Kerja', 'Melatih tanggung jawab, disiplin, kerja sama tim, dan komunikasi profesional.', 'fa-solid fa-user-tie', 2, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(3, 'tujuan', 'Mengenal Dunia Industri', 'Memahami struktur organisasi, budaya kerja, dan standar mutu di perusahaan.', 'fa-solid fa-building', 3, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(4, 'kerjasama', 'Penempatan PKL Siswa', 'Industri mitra menerima siswa PKL pada bidang pekerjaan yang relevan dengan program keahlian, sehingga siswa belajar dari alur kerja yang sebenarnya.', 'fa-solid fa-user-gear', 1, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(5, 'kerjasama', 'Penyelarasan Kurikulum', 'Masukan dari industri dipakai untuk menyelaraskan materi dan praktik di sekolah dengan teknologi, standar, dan kebutuhan kompetensi terbaru.', 'fa-solid fa-diagram-project', 2, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(6, 'kerjasama', 'Guru Tamu & Kunjungan Industri', 'Praktisi industri dapat berbagi pengalaman di sekolah, dan siswa berkesempatan mengunjungi tempat kerja untuk mengenal budaya serta lingkungan industri.', 'fa-solid fa-chalkboard-user', 3, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(7, 'kerjasama', 'Penyaluran Lulusan', 'Melalui Bursa Kerja Khusus (BKK), hubungan yang terjalin selama PKL membuka peluang informasi lowongan dan rekrutmen bagi lulusan.', 'fa-solid fa-briefcase', 4, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(8, 'tahapan', 'Koordinasi & Penjajakan Industri', 'Sekolah bersama tim Hubungan Industri menjalin komunikasi dengan perusahaan dan instansi mitra, menyepakati bidang pekerjaan yang sesuai kompetensi keahlian, kuota peserta, serta bentuk pendampingan yang akan diberikan selama PKL berlangsung.', 'fa-solid fa-handshake-simple', 1, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(9, 'tahapan', 'Pembekalan Siswa', 'Sebelum berangkat, siswa mengikuti pembekalan yang mencakup etika dan budaya kerja, keselamatan dan kesehatan kerja (K3), disiplin waktu, komunikasi profesional, serta tata tertib sekolah yang tetap berlaku selama siswa berada di tempat PKL.', 'fa-solid fa-clipboard-list', 2, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(10, 'tahapan', 'Penempatan & Administrasi', 'Siswa ditempatkan di industri mitra sesuai jurusan dan minat. Sekolah mengurus surat pengantar, perjanjian kerja sama, dan kelengkapan administrasi, sementara orang tua/wali memberikan persetujuan agar siswa siap menjalani praktik.', 'fa-solid fa-file-signature', 3, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(11, 'tahapan', 'Pelaksanaan & Pendampingan', 'Siswa mengerjakan tugas nyata di tempat PKL dengan bimbingan pembimbing industri. Guru pembimbing dari sekolah memantau perkembangan melalui kunjungan, komunikasi berkala, dan jurnal harian yang diisi siswa selama kegiatan.', 'fa-solid fa-route', 4, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(12, 'tahapan', 'Monitoring & Evaluasi', 'Pembimbing sekolah dan pembimbing industri mengevaluasi ketercapaian tugas, sikap kerja, dan kompetensi teknis. Kendala yang muncul di lapangan dibahas bersama agar pelaksanaan PKL tetap berjalan aman, nyaman, dan bermanfaat.', 'fa-solid fa-chart-column', 5, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(13, 'tahapan', 'Penilaian, Laporan & Sertifikat', 'Di akhir PKL, siswa menyusun laporan kegiatan dan mempresentasikan hasilnya. Penilaian dari industri dan sekolah digabungkan, lalu siswa yang memenuhi ketentuan memperoleh sertifikat PKL sebagai bukti pengalaman dan kompetensi kerja.', 'fa-solid fa-award', 6, 1, '2026-09-28 13:59:38', '2026-09-28 13:59:38'),
(14, 'tentang', 'pkl', 'Praktik Kerja Lapangan (PKL) merupakan program pembelajaran yang memberikan kesempatan kepada siswa SMK INFOKOM untuk memperoleh pengalaman kerja secara langsung di dunia usaha dan dunia industri. Melalui kegiatan PKL, siswa dapat menerapkan pengetahuan dan keterampilan yang telah dipelajari di sekolah ke dalam lingkungan kerja yang nyata, sekaligus memahami budaya kerja, kedisiplinan, tanggung jawab, komunikasi, dan kerja sama dalam tim. Kegiatan ini juga membantu siswa meningkatkan kompetensi sesuai bidang keahlian, menambah pengalaman profesional, serta mempersiapkan diri untuk melanjutkan pendidikan maupun memasuki dunia kerja setelah menyelesaikan pendidikan di SMK INFOKOM.', 'fa-solid fa-circle-info', 1, 1, '2026-09-28 20:53:13', '2026-09-28 20:53:13');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ppdb_documents`
--

CREATE TABLE `ppdb_documents` (
  `id` int(11) NOT NULL,
  `registration_id` int(11) NOT NULL,
  `document_type` varchar(100) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `ppdb_registrations`
--

CREATE TABLE `ppdb_registrations` (
  `id` int(11) NOT NULL,
  `registration_number` varchar(30) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `nisn` varchar(20) DEFAULT NULL,
  `birth_place` varchar(100) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` enum('Laki-laki','Perempuan') NOT NULL,
  `religion` varchar(30) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `parent_name` varchar(150) DEFAULT NULL,
  `parent_phone` varchar(20) DEFAULT NULL,
  `previous_school` varchar(150) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `academic_year` varchar(20) DEFAULT NULL,
  `status` enum('Menunggu','Diverifikasi','Diterima','Ditolak') DEFAULT 'Menunggu',
  `admin_note` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `ppdb_settings`
--

CREATE TABLE `ppdb_settings` (
  `id` int(11) NOT NULL,
  `academic_year` varchar(20) NOT NULL DEFAULT '2026/2027',
  `is_open` tinyint(1) DEFAULT 1,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  `info_image` varchar(255) DEFAULT NULL,
  `form_pdf` varchar(255) DEFAULT NULL,
  `form_pdf_label` varchar(150) DEFAULT NULL,
  `flow` text DEFAULT NULL,
  `faq` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `ppdb_settings`
--

INSERT INTO `ppdb_settings` (`id`, `academic_year`, `is_open`, `start_date`, `end_date`, `requirements`, `info_image`, `form_pdf`, `form_pdf_label`, `flow`, `faq`) VALUES
(1, '2026/2027', 1, '2026-07-14', '2026-07-25', '', 'ppdb/c68f62cc3525a341413a82ce.jpg', NULL, NULL, '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ppdb_faqs` (FAQ PPDB, diubah lewat Admin > Ubah FAQ)
--

CREATE TABLE IF NOT EXISTS `ppdb_faqs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `answer` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `principal_message`
--

CREATE TABLE `principal_message` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT '[NAMA KEPALA SEKOLAH]',
  `photo` varchar(255) DEFAULT NULL,
  `message` text DEFAULT '[ISI SAMBUTAN KEPALA SEKOLAH]',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `principal_message`
--

INSERT INTO `principal_message` (`id`, `name`, `photo`, `message`, `updated_at`) VALUES
(1, '[NAMA KEPALA SEKOLAH]', NULL, '[ISI SAMBUTAN KEPALA SEKOLAH]', '2026-09-19 20:07:39');

-- --------------------------------------------------------

--
-- Struktur dari tabel `programs`
--

CREATE TABLE `programs` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(170) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `excellence` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `programs`
--

INSERT INTO `programs` (`id`, `name`, `slug`, `image`, `description`, `excellence`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Rekayasa Perangkat Lunak', 'rekayasa-perangkat-lunak', 'jurusan/4860aac382302185f20d881b.jpg', '1. Pemrograman Aplikasi Berbasis Desktop\r\n2. Analisa dan Perancangan sistem\r\n3. Arsitektur Aplikasi Desktop , Mobile, Web dan Enterprise', 'Meningkatkan Efisiensi dan Produktivitas: Mengoptimalkan waktu, tenaga, dan sumber daya tim pengembang melalui pendekatan yang terstruktur.\r\n Memastikan sistem mudah diperbarui, diperbaiki, atau ditingkatkan fiturnya seiring perkembangan teknologi.', 1, 1, '2026-09-19 20:07:39', '2026-09-22 09:03:16'),
(2, 'Teknik Komputer dan Jaringan', 'teknik-komputer-dan-jaringan', 'jurusan/7bc9d6d955eebe8d726553ea.jpg', '1. IT Support Jaringan\r\n2. Perakitan dan Perbaikan Komputer\r\n3. Administrator Jaringan Komputer LAN dan WAN\r\n4. aplikasi Teknik Komputer dan Jaringan interaktif\r\n6. Keamanan Jaringan Terpusat', 'Menguasai Hardware dan Software: Siswa bisa merakit komputer, memasang sistem operasi (operating system), serta memperbaiki kerusakan komponen fisik seperti RAM, CPU, dan harddisk.\r\nAhli Jaringan Komputer: Siswa mampu mengatur jaringan lokal (LAN) maupun luas (WAN), mengonfigurasi router, serta membangun server dan keamanan jaringan (network security).', 2, 1, '2026-09-19 20:07:39', '2026-09-22 09:04:26'),
(3, 'desain komunikasi visual', 'desain-komunikasi-visual', 'jurusan/f5e1841ea46872d99049c033.jpg', '1. Mengembangkan citra dan animasi digital\r\n2. Mengembangkan laman (web) interaktif\r\n3. Mengembangkan Merekam dan menyunting audio-video\r\n4. Mengembangkan aplikasi multimedia interaktif', 'Peluang Karier Luas: Lulusan DKV bisa bekerja sebagai desainer grafis, animator, ilustrator, videografer, hingga desainer UI/UX di berbagai sektor industri.\r\nMahasiswa dapat mulai mencari penghasilan dan memperkaya pengalaman dengan menerima proyek lepas (freelance) secara online.', 3, 1, '2026-09-19 20:07:39', '2026-09-22 09:05:32'),
(4, 'Produksi dan Siaran Program Televisi', 'produksi-dan-siaran-program-televisi', 'jurusan/8eea5435c7bd89a30cf7d92f.jpg', '1. Program Pertelevisian\r\n2. Penyutradaraan, Editor, Kameramen\r\n3. Penata Artistik dan Suara, Penulis Naskah dan Skenario\r\n4. Aplikasi Teknik Produksi dan Penyiaran Program Pertelevisian interaktif', 'Keterampilan Produksi Menyeluruh: Siswa mempelajari seluruh tahapan pembuatan program, mulai dari penulisan naskah, penyutradaraan, teknik kamera, tata cahaya, tata suara, hingga proses editing pasca-produksi.\r\nPeluang Wirausaha yang Luas: Di tengah tingginya kebutuhan dokumentasi dan tren video sinematik, lulusan dapat langsung membuka usaha mandiri di bidang videografi, fotografi, atau agensi konten tanpa harus bergantung pada perusahaan.', 4, 1, '2026-09-19 20:07:39', '2026-09-22 09:06:41');

-- --------------------------------------------------------

--
-- Struktur dari tabel `school_profile`
--

CREATE TABLE `school_profile` (
  `id` int(11) NOT NULL,
  `school_name` varchar(150) NOT NULL DEFAULT 'SMK INFOKOM BOGOR',
  `npsn` varchar(20) DEFAULT NULL,
  `short_description` text DEFAULT NULL,
  `about_image` varchar(255) DEFAULT NULL,
  `history` text DEFAULT NULL,
  `history_image` varchar(255) DEFAULT NULL,
  `vision` text DEFAULT NULL,
  `mission` text DEFAULT NULL,
  `excellence` text DEFAULT NULL,
  `principal_name` varchar(100) DEFAULT NULL,
  `principal_photo` varchar(255) DEFAULT NULL,
  `principal_message` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `operating_hours` varchar(150) DEFAULT NULL,
  `map_embed` text DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `kabar_video_url` varchar(500) DEFAULT NULL,
  `tiktok` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `school_profile`
--

INSERT INTO `school_profile` (`id`, `school_name`, `npsn`, `short_description`, `about_image`, `history`, `history_image`, `vision`, `mission`, `excellence`, `principal_name`, `principal_photo`, `principal_message`, `logo`, `address`, `phone`, `email`, `operating_hours`, `map_embed`, `facebook`, `instagram`, `youtube`, `tiktok`, `updated_at`) VALUES
(1, 'SMK INFOKOM BOGOR', '20238531', 'Membangun generasi kompeten, berkarakter, kreatif, dan siap menghadapi dunia kerja serta perkembangan teknologi.', 'lainnya/956b43f1308f06e8a88ed0e4.jpg', 'Yayasan Telekomunikasi Nasional terletak di dua lokasi yang berbeda tepatnya di Jalan RE Abdullah Nomor 15 Gunung Batu, Bogor menempati lahan seluas 800 m2 dijadikan lokasi pertama satuan pendidikan: SMP INFOKOM Bogor. Sedangkan untuk lokasi kedua di Jalan Letjen Ibrahim Adjie Nomor 178 Sindang Barang Bogor menempati lahan seluas 2.600 m2 satuan pendidikan: SMK INFOKOM Bogor', 'lainnya/504070039f467901b8218772.jpg', 'Terwujudnya SMK Infokom Bogor sebagai SMK yang peduli dan berbudaya lingkungan hidup dengan tamatan yang kompeten dan mampu bersaing di tingkat Nasional, maupun Internasional.', '1. Membangun mental dan sikap peserta didik yang beriman dan bertaqwa kepada Tuhan yang Maha Esa.\r\n2. Mengembangkan kurikulum dan menyelenggarakan pembelajaran berstandar Nasional.\r\n3. Melalui kemitraan, keterbukaan dan pelayanan prima, SMK Infokom Kota Bogor :\r\n * Meningkatkan kualitas dan kuantitas tamatan yang siap kerja.\r\n * Menyiapkan wirausahawan yang handal dan mampu bersaing.\r\n * Menyiapkan tenaga terampil yang memiliki etos kerja dan kepribadian.', 'SMK INFOKOM Bogor memiliki akreditasi “A” dan berfokus pada pendidikan kejuruan di bidang teknologi, digital, dan media. Sekolah ini menawarkan berbagai program keahlian yang disesuaikan dengan perkembangan kebutuhan industri.\r\n\r\nKeunggulan Utama\r\n\r\n Terakreditasi A\r\nSMK INFOKOM Bogor memiliki akreditasi A, yang menunjukkan bahwa mutu pendidikan dan penyelenggaraan sekolah telah memenuhi standar yang ditetapkan. Profil SMK INFOKOM Bogor\r\n\r\n Program Keahlian Relevan dengan Industri\r\nSMK INFOKOM Bogor memiliki empat kompetensi keahlian yang berfokus pada bidang teknologi dan industri kreatif, yaitu:\r\n\r\nTeknik Komputer dan Jaringan (TKJ) / Teknik Jaringan Komputer\r\nRekayasa Perangkat Lunak (RPL)\r\nDesain Komunikasi Visual (DKV) / Multimedia\r\nProduksi dan Siaran Program Televisi (PSPT) / Broadcasting\r\nProfil SMK INFOKOM Bogor\r\n\r\n Pembekalan Praktik Kerja\r\nSiswa mendapatkan pembelajaran berbasis praktik dan pengalaman kerja yang membantu mempersiapkan mereka menghadapi dunia kerja maupun industri, khususnya di bidang teknologi dan digital. Jurusan RPL SMK INFOKOM Bogor\r\n\r\n Pembangunan Karakter\r\nSelain mengembangkan kompetensi kejuruan, SMK INFOKOM Bogor juga menekankan pembentukan karakter, mental, serta sikap peserta didik yang beriman dan bertakwa kepada Tuhan Yang Maha Esa. SMK INFOKOM Bogor\r\n\r\nBerorientasi pada Teknologi dan Kreativitas\r\nDengan bidang keahlian yang mencakup jaringan komputer, perangkat lunak, desain, serta broadcasting, siswa mendapatkan kesempatan untuk mengembangkan kemampuan teknis sekaligus kreativitas sesuai minat dan kompetensinya.', 'Ir. Hj. Liliek Rahmaningsih, M.MPd (Kepala Sekolah)', 'lainnya/8b73ee77d4af0cbd6d47fff2.png', 'Assalaamu’alaikum Warahmatullahi Wabarakatuh. Salam sejahtera untuk kita semua. Segala puji syukur kita panjatkan ke hadirat Allah SWT, karena atas limpahan Rahmat, dan Karunia-Nya sehingga Website resmi SMK INFOKOM Kota Bogor ini dapat terus kita kembangkan sebagai sarana Informasi yang akurat mengenai segala hal yang berkaitan dengan sekolah ini. Ucapan terima kasih juga kami haturkan kepada semua pihak yang telah memberikan dukungan dan masukan dalam kelancaran pengembangan Website ini. Selamat datang di Website resmi SMK INFOKOM Kota Bogor. Di era digital saat ini, website sekolah merupakan pintu gerbang informasi terdepan sebagai sarana untuk menyebarluaskan berbagai publikasi terkait kemajuan pendidikan dan pencapaian sekolah terkini. Sebagai media pembelajaran, terlebih di masa pandemi masih berlangsung, Website sekolah juga diarahkan dapat mendatangkan kemanfaatan sebagai sarana pembelajaran dengan memuat blog, e-learning, karya dan media pembelajaran yang dibuat oleh pendidik serta para siswa. Di sisi lain kami sungguh berharap Website ini juga dapat menjadi sarana silaturahmi dan komunikasi antara sekolah dengan para alumni di berbagai tempat, sebagai sebuah keluarga besar yang solid serta dapat berkontribusi dalam memajukan pendidikan di SMK INFOKOM tercinta. Kami menyadari website SMK INFOKOM ini masih memiliki banyak kekurangan, oleh karena itu, kami akan terus belajar dan meng-update diri, sehingga konten dan kualitas tampilan website sekolah ini akan semakin berkembang. Kritik, saran dan masukan dari berbagai stake holder sekolah tentu sangat kami harapkan. Kepada tim pengembang dan pengelola, kami berharap agar dapat terus menyempurnakannya dengan penuh keikhlasan serta tanggung jawab. Terima kasih atas kerjasamanya, mari terus berkarya menuju SMK INFOKOM yang lebih berkualitas dan berjaya dalam mencerdaskan kehidupan anak bangsa Indonesia. SMK, Bisa...! SMK INFOKOM, Luar Biasa…! Wassalamu\'alaikum Warahmatullahi Wabarakatuh', 'lainnya/99d5f13f2d2236f91210cec3.jpg', 'Jl. Letjend Ibrahim Adjie No. 178, Sindang Barang, Kec. Bogor Barat, Kota Bogor, Jawa Barat 16617', '0251-8348108 0878-7307-1400 (Humas SMK INFOKOM)', 'smk.infokom@gmail.com', 'Senin - Jumat: 07.00 - 16.00 WIB', '', '', '', '', '', '2026-09-28 19:53:26');

-- --------------------------------------------------------

--
-- Struktur dari tabel `school_statistics`
--

CREATE TABLE `school_statistics` (
  `id` int(11) NOT NULL,
  `label` varchar(100) NOT NULL,
  `value` int(11) NOT NULL DEFAULT 0,
  `suffix` varchar(10) DEFAULT '+',
  `icon` varchar(50) DEFAULT 'fa-solid fa-chart-simple',
  `sort_order` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `school_statistics`
--

INSERT INTO `school_statistics` (`id`, `label`, `value`, `suffix`, `icon`, `sort_order`) VALUES
(1, 'Siswa Aktif', 900, '+', 'fa-solid fa-user-graduate', 1),
(2, 'Guru & Staff', 50, '+', 'fa-solid fa-chalkboard-user', 2),
(3, 'Program Keahlian', 4, '', 'fa-solid fa-layer-group', 3),
(4, 'Prestasi', 500, '+', 'fa-solid fa-trophy', 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `social_media`
--

CREATE TABLE `social_media` (
  `id` int(11) NOT NULL,
  `platform` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `social_media`
--

INSERT INTO `social_media` (`id`, `platform`, `url`, `icon`, `sort_order`) VALUES
(1, 'Facebook', '#', 'fa-brands fa-facebook-f', 1),
(2, 'Instagram', 'https://www.instagram.com/smk.infokom_official?stkn=MWhqaHR5MjkxOTdxYQ==', 'fa-brands fa-instagram', 2),
(3, 'YouTube', '#', 'fa-brands fa-youtube', 3),
(4, 'TikTok', '#', 'fa-brands fa-tiktok', 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `category` enum('guru','staff') NOT NULL DEFAULT 'guru',
  `position` varchar(150) DEFAULT NULL,
  `subject` varchar(150) DEFAULT NULL,
  `nip` varchar(50) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `staff`
--

INSERT INTO `staff` (`id`, `name`, `category`, `position`, `subject`, `nip`, `photo`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 'Dian Hardianti, S.Kom.,Gr.', 'guru', '', '', '', 'staff/6ce153a282d8f17f6f2acd3e.png', 1, 1, '2026-09-22 09:22:20', '2026-09-28 09:30:08'),
(3, 'Ahmad Hotib, S.Pd.I', 'guru', '', '', '', 'staff/5643aff047a36be2549ec397.jpg', 2, 1, '2026-09-22 09:23:04', '2026-09-28 20:11:23'),
(4, '⁠Erli Suherli, A.Md.Kom.', 'guru', '', '', '', 'staff/a7b5a01fab01417b8b06fc0f.jpg', 3, 1, '2026-09-22 09:24:21', '2026-09-28 20:11:36'),
(5, 'Eva Farida Rahayu, S.Pd.,Gr.', 'guru', '', '', '', 'staff/062e75c09aa9003772992abf.png', 4, 1, '2026-09-22 09:24:47', '2026-09-28 09:32:16'),
(6, 'Cahyadi Rozi, ST.', 'guru', '', '', '', 'staff/a17ec6cb354b9c42d0b39e23.jpeg', 5, 1, '2026-09-22 09:25:44', '2026-09-28 09:33:05'),
(7, 'Aditya Nugraha, ST.', 'guru', '', '', '', 'staff/c1b2f09217427a7c366e35ed.jpg', 6, 1, '2026-09-27 11:23:08', '2026-09-28 20:12:14'),
(9, 'Mila Yaelasari, M.Pd.', 'guru', '', '', '', 'staff/7cffcf04c73d1ffaebdc9625.jpg', 8, 1, '2026-09-27 11:23:38', '2026-09-28 20:12:30'),
(10, 'Agus Tiyono, M.Pd.', 'guru', '', '', '', 'staff/f08ad473f0eceda112334f37.jpg', 9, 1, '2026-09-27 11:24:08', '2026-09-28 20:12:43'),
(11, 'Dea Rijalul Fikri, S.Kom.,Gr.', 'guru', '', '', '', 'staff/2e7b30a6ee8b5e87e14823a0.jpg', 10, 1, '2026-09-27 11:24:25', '2026-09-28 20:12:55'),
(13, 'Heny Handayani, S.Pd.', 'guru', '', '', '', 'staff/1c2263d64aa5598a79d38e36.jpg', 12, 1, '2026-09-27 11:25:01', '2026-09-28 20:13:10'),
(14, 'Vera Yuni Astuti, SP., M.IKom.,Gr.', 'guru', '', '', '', 'staff/a6a4270a53fe7fa74e15f9f1.jpg', 13, 1, '2026-09-27 11:25:18', '2026-09-28 20:13:37'),
(15, 'Drs. Puji Marhaen Waluyo', 'guru', '', '', '', 'staff/ee21d5efec43f41bfce5b329.jpg', 14, 1, '2026-09-27 11:25:34', '2026-09-28 20:13:47'),
(16, 'Putri Riandini, S.Hut., M.Pd.,Gr.', 'guru', '', '', '', 'staff/851ea77defa06de6bb06038b.jpg', 15, 1, '2026-09-27 11:26:00', '2026-09-28 20:13:59'),
(17, 'Muhammad Ibnu Arif, S.IKom.', 'guru', '', '', '', 'staff/20f7eec252163a03c38dc3f9.jpg', 16, 1, '2026-09-27 11:26:15', '2026-09-28 20:14:18'),
(18, 'Ridwan Hala, S.Kom.,Gr.', 'guru', '', '', '', 'staff/ca464d925395bc35b120e780.jpg', 17, 1, '2026-09-27 11:26:36', '2026-09-28 20:14:32'),
(19, 'Abdul Azis, M.Pd.', 'guru', '', '', '', 'staff/fca8a00449b87e0e619280e3.jpg', 18, 1, '2026-09-27 11:26:57', '2026-09-28 20:14:46'),
(20, 'Radiani Srirestuti Dewi, SS.,Gr.', 'guru', '', '', '', 'staff/0526d71ae1a3d210f8b327e1.jpg', 19, 1, '2026-09-28 09:21:05', '2026-09-28 20:14:59'),
(21, 'Dara Purwanita, S.Pd.,Gr.', 'guru', '', '', '', 'staff/dcb58df4e1a6e67e08be4a2d.png', 20, 1, '2026-09-28 09:25:24', '2026-09-28 20:15:16'),
(22, 'Widyatama Nuranisa, SM.', 'guru', '', '', '', 'staff/0b0bde730d776669396a3570.png', 21, 1, '2026-09-28 09:33:30', '2026-09-28 20:15:28'),
(23, 'Erwin Hasiholan Gultom, S.Kom.', 'guru', '', '', '', 'staff/c0fab8b8bb9ba66961c915ae.jpg', 22, 1, '2026-09-28 09:33:46', '2026-09-28 20:15:43'),
(24, 'Nabila Ahmadia Pratama, S.Pd.', 'guru', '', '', '', 'staff/c84a17d44e518e0c383f6a6c.png', 23, 1, '2026-09-28 09:34:01', '2026-09-28 20:15:56'),
(25, 'Dra. Diana Octaria', 'guru', '', '', '', 'staff/f5db39313e0dc43ad9176b65.jpg', 24, 1, '2026-09-28 09:34:19', '2026-09-28 20:16:12'),
(26, 'Reza Prafitriansyah, S.Kom.,Gr.', 'staff', '', '', '', 'staff/6d744e1931d04ef09d59ad3e.jpg', 25, 1, '2026-09-28 09:34:57', '2026-09-28 20:16:32'),
(27, 'Jayadi, S.Pd.,Gr.', 'staff', '', '', '', 'staff/360aed45a2b4d7afc7d347b8.jpg', 26, 1, '2026-09-28 09:35:24', '2026-09-28 20:17:26'),
(28, 'Yadi Setiadi, S.Sos.,Gr.', 'staff', '', '', '', 'staff/909359be20cde981ab48fc4c.jpg', 27, 1, '2026-09-28 09:36:00', '2026-09-28 20:17:39'),
(29, 'Siti Nuraeni', 'staff', '', '', '', 'staff/a3bfa1b272cb5b7fd86ba6ab.jpg', 28, 1, '2026-09-28 09:36:25', '2026-09-28 20:21:16'),
(30, 'Dra. Popon Puspitasari', 'guru', '', '', '', 'staff/c9a0d1c1e12e6a4ce73b198d.jpg', 29, 1, '2026-09-28 09:46:16', '2026-09-28 20:16:49'),
(31, 'Richo Santana, S.Kom.', 'guru', '', '', '', 'staff/8f85f3f79cd3a5e6fa0ce400.jpg', 30, 1, '2026-09-28 09:46:40', '2026-09-28 20:17:01'),
(32, 'Yeni Yuliawati, S.Pd.,Gr.', 'guru', '', '', '', 'staff/d6c90436f16421db5f10ed32.jpg', 31, 1, '2026-09-28 20:20:21', '2026-09-28 20:20:21'),
(33, 'Rita Widyastuti', 'staff', '', '', '', 'staff/20050c2f26f3063cdc0af7c0.jpg', 32, 1, '2026-09-28 20:20:55', '2026-09-28 20:20:55');

-- --------------------------------------------------------

--
-- Struktur dari tabel `student_rules`
--

CREATE TABLE `student_rules` (
  `id` int(11) NOT NULL,
  `category` varchar(80) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `student_rules`
--

INSERT INTO `student_rules` (`id`, `category`, `title`, `content`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Kewajiban Siswa', 'Datang tepat waktu dan mengikuti kegiatan belajar sesuai jadwal.', '', 0, 1, '2026-09-27 20:41:41', '2026-09-27 20:41:41'),
(2, 'Hak Siswa', 'Mendapatkan pembelajaran dan bimbingan dari guru.', '', 0, 1, '2026-09-27 20:45:17', '2026-09-27 20:45:17'),
(3, 'Hak Siswa', 'Menggunakan fasilitas sekolah sesuai ketentuan.', '', 0, 1, '2026-09-27 20:45:28', '2026-09-27 20:45:28'),
(4, 'Hak Siswa', 'Menyampaikan pendapat secara sopan dan bertanggung jawab.', '', 0, 1, '2026-09-27 20:45:41', '2026-09-27 20:45:41'),
(5, 'Kewajiban Siswa', 'Mengikuti kegiatan pembelajaran dengan tertib.', '', 0, 1, '2026-09-27 20:45:56', '2026-09-27 20:45:56'),
(6, 'Kewajiban Siswa', 'Menghormati guru, karyawan, dan sesama siswa.', '', 0, 1, '2026-09-27 20:46:39', '2026-09-27 20:46:39'),
(7, 'Kewajiban Siswa', 'Menjaga kebersihan dan fasilitas sekolah.', '', 0, 1, '2026-09-27 20:46:57', '2026-09-27 20:46:57'),
(8, 'Kewajiban Siswa', 'Menaati seluruh tata tertib sekolah.', '', 0, 1, '2026-09-27 20:47:07', '2026-09-27 20:47:07'),
(9, 'Ketentuan Seragam', 'Memakai seragam sesuai jadwal yang ditentukan.', '', 0, 1, '2026-09-28 20:40:27', '2026-09-28 20:40:27'),
(10, 'Ketentuan Seragam', 'Seragam harus bersih, rapi, dan sopan.', '', 0, 1, '2026-09-28 20:40:42', '2026-09-28 20:40:42'),
(11, 'Ketentuan Seragam', 'Memakai atribut sekolah secara lengkap.', '', 0, 1, '2026-09-28 20:40:56', '2026-09-28 20:40:56'),
(12, 'Ketentuan Kehadiran', 'Mengikuti seluruh kegiatan pembelajaran.', '', 0, 1, '2026-09-28 20:41:09', '2026-09-28 20:41:09'),
(13, 'Ketentuan Kehadiran', 'Hadir di sekolah tepat waktu.', '', 0, 1, '2026-09-28 20:41:21', '2026-09-28 20:41:21'),
(14, 'Ketentuan Kehadiran', 'Tidak meninggalkan sekolah tanpa izin.', '', 0, 1, '2026-09-28 20:41:39', '2026-09-28 20:41:39');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `academic_info`
--
ALTER TABLE `academic_info`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `achievements`
--
ALTER TABLE `achievements`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indeks untuk tabel `agendas`
--
ALTER TABLE `agendas`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `bkk_sections`
--
ALTER TABLE `bkk_sections`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `bkk_settings`
--
ALTER TABLE `bkk_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `extracurriculars`
--
ALTER TABLE `extracurriculars`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indeks untuk tabel `facilities`
--
ALTER TABLE `facilities`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indeks untuk tabel `gallery_categories`
--
ALTER TABLE `gallery_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indeks untuk tabel `jepang_profile`
--
ALTER TABLE `jepang_profile`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `jepang_sections`
--
ALTER TABLE `jepang_sections`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `job_vacancies`
--
ALTER TABLE `job_vacancies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `program_id` (`program_id`);

--
-- Indeks untuk tabel `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indeks untuk tabel `news_categories`
--
ALTER TABLE `news_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indeks untuk tabel `news_gallery`
--
ALTER TABLE `news_gallery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `news_id` (`news_id`);

--
-- Indeks untuk tabel `organization_structure`
--
ALTER TABLE `organization_structure`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `partner_companies`
--
ALTER TABLE `partner_companies`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pkl_items`
--
ALTER TABLE `pkl_items`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `ppdb_documents`
--
ALTER TABLE `ppdb_documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `registration_id` (`registration_id`);

--
-- Indeks untuk tabel `ppdb_registrations`
--
ALTER TABLE `ppdb_registrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `registration_number` (`registration_number`),
  ADD KEY `program_id` (`program_id`);

--
-- Indeks untuk tabel `ppdb_settings`
--
ALTER TABLE `ppdb_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `principal_message`
--
ALTER TABLE `principal_message`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indeks untuk tabel `school_profile`
--
ALTER TABLE `school_profile`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `school_statistics`
--
ALTER TABLE `school_statistics`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `social_media`
--
ALTER TABLE `social_media`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `student_rules`
--
ALTER TABLE `student_rules`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `academic_info`
--
ALTER TABLE `academic_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `achievements`
--
ALTER TABLE `achievements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `agendas`
--
ALTER TABLE `agendas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `bkk_sections`
--
ALTER TABLE `bkk_sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `bkk_settings`
--
ALTER TABLE `bkk_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `extracurriculars`
--
ALTER TABLE `extracurriculars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `facilities`
--
ALTER TABLE `facilities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `gallery_categories`
--
ALTER TABLE `gallery_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `jepang_profile`
--
ALTER TABLE `jepang_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `jepang_sections`
--
ALTER TABLE `jepang_sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `job_vacancies`
--
ALTER TABLE `job_vacancies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `news_categories`
--
ALTER TABLE `news_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `news_gallery`
--
ALTER TABLE `news_gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `organization_structure`
--
ALTER TABLE `organization_structure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT untuk tabel `partner_companies`
--
ALTER TABLE `partner_companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `pkl_items`
--
ALTER TABLE `pkl_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `ppdb_documents`
--
ALTER TABLE `ppdb_documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `ppdb_registrations`
--
ALTER TABLE `ppdb_registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `ppdb_settings`
--
ALTER TABLE `ppdb_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `principal_message`
--
ALTER TABLE `principal_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `programs`
--
ALTER TABLE `programs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `school_profile`
--
ALTER TABLE `school_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `school_statistics`
--
ALTER TABLE `school_statistics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `social_media`
--
ALTER TABLE `social_media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT untuk tabel `student_rules`
--
ALTER TABLE `student_rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `gallery`
--
ALTER TABLE `gallery`
  ADD CONSTRAINT `gallery_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `gallery_categories` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `job_vacancies`
--
ALTER TABLE `job_vacancies`
  ADD CONSTRAINT `job_vacancies_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `partner_companies` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `job_vacancies_ibfk_2` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `news`
--
ALTER TABLE `news`
  ADD CONSTRAINT `news_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `news_categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `news_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `news_gallery`
--
ALTER TABLE `news_gallery`
  ADD CONSTRAINT `news_gallery_ibfk_1` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `ppdb_documents`
--
ALTER TABLE `ppdb_documents`
  ADD CONSTRAINT `ppdb_documents_ibfk_1` FOREIGN KEY (`registration_id`) REFERENCES `ppdb_registrations` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `ppdb_registrations`
--
ALTER TABLE `ppdb_registrations`
  ADD CONSTRAINT `ppdb_registrations_ibfk_1` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- =====================================================================
-- BERSIHKAN DATA & TABEL FITUR LAMA (OPSIONAL)
-- =====================================================================
-- Skrip ini HANYA relevan untuk instalasi LAMA yang dulu pernah memakai
-- fitur Program/Bidang, Pelatihan, Budaya & Etika, Mitra, Dokumen, FAQ,
-- dan Pendaftar Program Kerja ke Jepang, atau fitur Kegiatan Siswa.
--
-- Fitur-fitur tersebut sudah dihapus dari kode aplikasi (lihat
-- CATATAN-PERBAIKAN.md bagian "Perubahan final"). Tabel & datanya
-- SENGAJA TIDAK dihapus otomatis oleh aplikasi supaya tidak ada data
-- yang hilang tanpa sepengetahuan admin.
--
-- Jalankan skrip ini HANYA jika Anda yakin data lama tersebut memang
-- tidak diperlukan lagi. PROSES INI PERMANEN DAN TIDAK BISA DIBATALKAN.
-- Sebaiknya backup database terlebih dahulu (phpMyAdmin > Export) sebelum
-- menjalankan skrip ini.
--
-- Cara pakai:
--   1. phpMyAdmin: buka database smk_infokom > tab SQL > tempel isi file
--      ini > klik Go.
--   2. Terminal: mysql -u root -p smk_infokom < database/bersihkan-fitur-lama.sql
--
-- Baris yang tidak diinginkan boleh dihapus/dikomentari (beri "-- " di
-- depan baris) sebelum menjalankan skrip ini.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) Sisa data modul Pelatihan & Budaya-Etika di dalam tabel jepang_sections
--    (kolom "module" lama sudah tidak dipakai kode; hanya module
--    'persyaratan' yang masih dibaca, termasuk kategori "Tahapan Program").
-- ---------------------------------------------------------------------
DELETE FROM jepang_sections WHERE module IN ('pelatihan_bahasa', 'pelatihan_kompetensi', 'budaya_etika');

-- ---------------------------------------------------------------------
-- 2) Tabel-tabel milik fitur Program/Bidang, Mitra, Dokumen, FAQ, dan
--    Pendaftar Program Kerja ke Jepang yang sudah dihapus dari aplikasi.
--    IF EXISTS dipakai supaya aman dijalankan meski sebagian tabel
--    sudah tidak ada.
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS jepang_registrations;   -- data pendaftar program Jepang
DROP TABLE IF EXISTS jepang_documents;       -- dokumen unduhan program Jepang
DROP TABLE IF EXISTS jepang_faqs;            -- FAQ program Jepang
DROP TABLE IF EXISTS jepang_partners;        -- mitra program Jepang
DROP TABLE IF EXISTS jepang_programs;        -- daftar program/bidang Jepang

-- ---------------------------------------------------------------------
-- 3) Tabel fitur Kegiatan Siswa (modul Kesiswaan) yang sudah dihapus.
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS student_activities;

-- ---------------------------------------------------------------------
-- 3b) Tabel fitur Prestasi Siswa (modul Kesiswaan, BUKAN Prestasi Sekolah
--     di tabel "achievements" — tabel itu berbeda dan TIDAK dihapus)
--     yang sudah dihapus dari aplikasi.
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS student_achievements;

-- ---------------------------------------------------------------------
-- 4) File fisik yang pernah diunggah untuk fitur-fitur di atas
--    (folder assets/uploads/jepang/program, mitra, dokumen, pendaftaran)
--    TIDAK dihapus oleh skrip SQL ini karena berada di luar database.
--    Jika ingin menghapusnya, hapus folder tersebut secara manual lewat
--    File Manager hosting atau FTP setelah skrip ini selesai dijalankan.
-- ---------------------------------------------------------------------

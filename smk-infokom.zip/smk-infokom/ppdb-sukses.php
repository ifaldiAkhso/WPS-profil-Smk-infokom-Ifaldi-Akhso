<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'pf-form page-profil';
$pdo = getDB();
$pageTitle = 'Pendaftaran Berhasil';

$no = trim($_GET['no'] ?? '');
$stmt = $pdo->prepare("SELECT r.*, p.name AS program_name FROM ppdb_registrations r LEFT JOIN programs p ON p.id = r.program_id WHERE registration_number = ? LIMIT 1");
$stmt->execute([$no]);
$reg = $stmt->fetch();

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>
<?php
$heroEyebrow = 'PPDB';
$heroTitle = 'Pendaftaran Berhasil';
$heroText = 'Terima kasih, data pendaftaran Anda telah kami terima.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['PPDB', BASE_URL . 'ppdb.php'], ['Berhasil', null]];
include __DIR__ . '/includes/page-hero.php';
?>

<section>
  <div class="container" style="max-width:700px;">
    <?php if (!$reg): ?>
      <div class="empty-state"><i class="fa-solid fa-circle-exclamation"></i><p>Data pendaftaran tidak ditemukan.</p><a href="ppdb.php" class="btn btn-primary">Kembali ke PPDB</a></div>
    <?php else: ?>
      <div class="form-card text-center reveal">
        <i class="fa-solid fa-circle-check" style="font-size:3.2rem;color:#12795b;margin-bottom:16px;"></i>
        <h2>Formulir Berhasil Dikirim!</h2>
        <p>Simpan nomor pendaftaran Anda untuk mengecek status seleksi.</p>
        <div style="background:var(--bg-soft);border-radius:12px;padding:22px;margin:22px 0;">
          <span style="font-size:.85rem;color:var(--ink-500);">Nomor Pendaftaran</span>
          <div style="font-size:1.8rem;font-weight:800;color:var(--navy-800);letter-spacing:.05em;"><?= e($reg['registration_number']) ?></div>
        </div>
        <table class="detail-table">
          <tr><td class="dt-label">Nama</td><td class="dt-value"><?= e($reg['full_name']) ?></td></tr>
          <tr><td class="dt-label">Jurusan</td><td class="dt-value"><?= e($reg['program_name'] ?? '-') ?></td></tr>
          <tr><td class="dt-label">Status</td><td class="dt-value"><span class="status-badge status-menunggu">Menunggu</span></td></tr>
        </table>
        <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
          <a href="cek-status.php" class="btn btn-outline-navy">Cek Status Pendaftaran</a>
          <a href="<?= BASE_URL ?>index.php" class="btn btn-primary">Kembali ke Beranda</a>
        </div>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

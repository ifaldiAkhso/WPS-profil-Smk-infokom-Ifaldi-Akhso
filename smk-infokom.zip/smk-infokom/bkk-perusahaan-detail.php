<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-info';
$pdo = getDB();
ensureBkkTables($pdo);

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM partner_companies WHERE id = ? AND is_partner = 1");
$stmt->execute([$id]);
$mitra = $stmt->fetch();
if (!$mitra || trim((string)$mitra['name']) === '') {
    setFlash('error', 'Data perusahaan mitra tidak ditemukan.');
    redirect(BASE_URL . 'bkk-perusahaan.php');
}
$pageTitle = $mitra['name'];

$jobsStmt = $pdo->prepare("SELECT * FROM job_vacancies WHERE company_id = ? AND status = 'aktif' AND (deadline IS NULL OR deadline >= CURDATE()) ORDER BY created_at DESC");
$jobsStmt->execute([$id]);
$jobs = $jobsStmt->fetchAll();

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'Perusahaan Mitra';
$heroTitle   = $mitra['name'];
$heroText    = 'Perusahaan Mitra BKK SMK INFOKOM BOGOR';
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['BKK', BASE_URL . 'bkk.php'], ['Perusahaan Mitra', BASE_URL . 'bkk-perusahaan.php'], [$mitra['name'], null]];
$heroCompact = true;
$heroImage   = file_exists(BASE_PATH . '/assets/images/bkk-hero.jpg') ? 'assets/images/bkk-hero.jpg' : 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';

// Website: tambahkan https:// bila belum ada, hanya izinkan http/https
$siteUrl = trim((string)($mitra['website'] ?? ''));
if ($siteUrl !== '' && !preg_match('~^https?://~i', $siteUrl)) $siteUrl = 'https://' . $siteUrl;
if ($siteUrl !== '' && !preg_match('~^https?://[^\s]+$~i', $siteUrl)) $siteUrl = '';
$siteLabel = $siteUrl !== '' ? preg_replace('~^https?://(www\.)?~i', '', rtrim($siteUrl, '/')) : '';

// Inisial untuk perusahaan yang belum punya logo
$initials = '';
foreach (preg_split('/\s+/', trim($mitra['name'])) as $w) {
    if ($w !== '' && mb_strlen($initials) < 2) $initials .= mb_strtoupper(mb_substr($w, 0, 1));
}
?>
<section class="profile-section">
  <div class="container">
    <?php
      $mapUrl = trim((string)($mitra['location'] ?? '')) !== ''
        ? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode(trim($mitra['location'] . ' ' . $mitra['name']))
        : '';
    ?>
    <div class="mitra-detail reveal">
      <div class="mitra-logo">
        <?php if (uploadExists($mitra['logo'])): ?>
          <img src="<?= uploadUrl($mitra['logo']) ?>" alt="<?= e($mitra['name']) ?>">
        <?php else: ?>
          <div class="mitra-initials"><?= e($initials ?: 'M') ?></div>
        <?php endif; ?>
      </div>
      <span class="mitra-badge"><i class="fa-solid fa-circle-check"></i> Mitra Terverifikasi</span>
      <h2 class="mitra-name"><?= e($mitra['name']) ?></h2>
      <div class="mitra-info">
        <?php if ($mapUrl !== ''): ?>
          <a class="mitra-info-item" href="<?= e($mapUrl) ?>" target="_blank" rel="noopener noreferrer">
            <span class="mitra-info-icon"><i class="fa-solid fa-location-dot"></i></span>
            <span class="mitra-info-text"><small>Lokasi</small><strong><?= e($mitra['location']) ?></strong></span>
            <i class="fa-solid fa-arrow-up-right-from-square mitra-info-go"></i>
          </a>
        <?php else: ?>
          <div class="mitra-info-item">
            <span class="mitra-info-icon"><i class="fa-solid fa-location-dot"></i></span>
            <span class="mitra-info-text"><small>Lokasi</small><strong>-</strong></span>
          </div>
        <?php endif; ?>
        <?php if ($siteUrl !== ''): ?>
          <a class="mitra-info-item" href="<?= e($siteUrl) ?>" target="_blank" rel="noopener noreferrer">
            <span class="mitra-info-icon"><i class="fa-solid fa-globe"></i></span>
            <span class="mitra-info-text"><small>Website</small><strong><?= e($siteLabel) ?></strong></span>
            <i class="fa-solid fa-arrow-up-right-from-square mitra-info-go"></i>
          </a>
        <?php else: ?>
          <div class="mitra-info-item">
            <span class="mitra-info-icon"><i class="fa-solid fa-globe"></i></span>
            <span class="mitra-info-text"><small>Website</small><strong>-</strong></span>
          </div>
        <?php endif; ?>
        <?php if (trim((string)($mitra['field'] ?? '')) !== ''): ?>
          <div class="mitra-info-item" style="grid-column:1/-1;">
            <span class="mitra-info-icon"><i class="fa-solid fa-briefcase"></i></span>
            <span class="mitra-info-text"><small>Bidang Usaha</small><strong><?= e($mitra['field']) ?></strong></span>
          </div>
        <?php endif; ?>
      </div>
      <?php if (trim((string)($mitra['description'] ?? '')) !== ''): ?>
        <div class="mitra-about">
          <small>Tentang Perusahaan</small>
          <p><?= e($mitra['description']) ?></p>
        </div>
      <?php endif; ?>
    </div>

    <?php if (count($jobs) > 0): ?>
      <div class="profile-heading reveal">
        <div class="article-kicker"><span></span> Lowongan <span></span></div>
        <h2>Lowongan Aktif dari <?= e($mitra['name']) ?></h2>
      </div>
      <div class="bkk-job-grid">
        <?php foreach ($jobs as $jv): ?>
          <div class="bkk-job-card reveal">
            <div class="bkk-job-body">
              <div class="bkk-job-top">
                <div>
                  <h3><?= e(jobTitle($jv)) ?></h3>
                  <span class="bkk-job-company"><?= e($mitra['name']) ?></span>
                </div>
              </div>
              <ul class="bkk-job-meta">
                <?php if (!empty($jv['location'])): ?><li><i class="fa-solid fa-location-dot"></i> <?= e($jv['location']) ?></li><?php endif; ?>
                <?php if (!empty($jv['deadline'])): ?><li><i class="fa-solid fa-hourglass-half"></i> Batas: <?= tanggalIndo($jv['deadline']) ?></li><?php endif; ?>
              </ul>
              <div class="bkk-job-actions">
                <a href="<?= BASE_URL ?>bkk-lowongan-detail.php?id=<?= (int)$jv['id'] ?>" class="btn btn-outline-navy btn-sm">Detail</a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <div class="profile-back reveal">
      <a href="<?= BASE_URL ?>bkk-perusahaan.php" class="btn btn-outline-navy btn-sm"><i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar Perusahaan Mitra</a>
    </div>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

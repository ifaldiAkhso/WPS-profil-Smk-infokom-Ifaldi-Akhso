<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'pf-info';
$pdo = getDB();
ensureNewsColumns($pdo);

$slug = trim($_GET['slug'] ?? '');
$stmt = $pdo->prepare("SELECT n.*, c.name AS category_name FROM news n LEFT JOIN news_categories c ON c.id=n.category_id WHERE n.slug = ? AND n.status='published' LIMIT 1");
$stmt->execute([$slug]);
$news = $stmt->fetch();

if (!$news) {
    http_response_code(404);
    $pageTitle = 'Berita Tidak Ditemukan';
    include __DIR__ . '/includes/header.php';
    include __DIR__ . '/includes/navbar.php';
    echo '<section><div class="container empty-state"><i class="fa-solid fa-circle-exclamation"></i><p>Berita tidak ditemukan.</p><a href="berita.php" class="btn btn-primary">Kembali ke Berita</a></div></section>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

// tambah views (best-effort)
$pdo->prepare("UPDATE news SET views = views + 1 WHERE id = ?")->execute([$news['id']]);

$galleryStmt = $pdo->prepare("SELECT * FROM news_gallery WHERE news_id = ?");
$galleryStmt->execute([$news['id']]);
$newsGallery = $galleryStmt->fetchAll();

$relatedStmt = $pdo->prepare("SELECT n.*, c.name AS category_name FROM news n LEFT JOIN news_categories c ON c.id = n.category_id WHERE n.category_id <=> ? AND n.id != ? AND n.status='published' ORDER BY n.published_at DESC LIMIT 3");
$relatedStmt->execute([$news['category_id'], $news['id']]);
$related = $relatedStmt->fetchAll();

$srcUrl  = safeUrl($news['source_url'] ?? '');
$srcName = trim((string)($news['source_name'] ?? '')) !== '' ? trim($news['source_name']) : urlHost($srcUrl);
$shareUrl = (isset($_SERVER['HTTP_HOST']) ? ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] : '') . BASE_URL . 'detail-berita.php?slug=' . urlencode($news['slug']);

$pageTitle = $news['title'];
$pageDescription = newsExcerpt($news, 160);
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>
<?php
$heroEyebrow = 'Informasi';
$heroTitle = $news['title'];
$heroText = '';
$heroCompact = true;
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['Berita', BASE_URL . 'berita.php'], [$news['title'], null]];
include __DIR__ . '/includes/page-hero.php';
?>

<section>
  <div class="container news-article-wrap">
    <article class="news-article">
      <img src="<?= uploadUrl($news['thumbnail'], 'assets/images/news-placeholder.jpg') ?>" alt="<?= e($news['title']) ?>" class="news-article-cover">
      <div class="news-meta news-article-meta">
        <span><i class="fa-regular fa-calendar"></i> <?= tanggalIndo($news['published_at']) ?></span>
        <span><i class="fa-regular fa-folder"></i> <?= e($news['category_name'] ?? 'Umum') ?></span>
        <span><i class="fa-regular fa-eye"></i> <?= (int)$news['views'] ?> dilihat</span>
      </div>
      <div class="news-content">
        <?= formatNewsContent($news['content']) ?>
      </div>

      <?php if ($srcUrl !== ''): ?>
        <a href="<?= e($srcUrl) ?>" target="_blank" rel="noopener noreferrer" class="source-link">
          <span class="source-link-ico"><i class="fa-solid fa-link"></i></span>
          <span class="source-link-text"><small>Sumber berita</small><strong><?= e($srcName) ?></strong><em><?= e($srcUrl) ?></em></span>
          <span class="source-link-go"><i class="fa-solid fa-arrow-up-right-from-square"></i></span>
        </a>
      <?php endif; ?>

      <?php if (count($newsGallery) > 0): ?>
        <h3 class="news-gallery-title">Galeri Foto</h3>
        <div class="gallery-grid news-gallery">
          <?php foreach ($newsGallery as $g): ?>
            <div class="gallery-item news-photo"><img src="<?= uploadUrl($g['image']) ?>" alt="Foto <?= e($news['title']) ?>" loading="lazy"></div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <div class="news-article-actions">
        <a href="berita.php" class="btn btn-outline-navy"><i class="fa-solid fa-arrow-left"></i> Kembali ke Berita</a>
        <a href="https://wa.me/?text=<?= urlencode($news['title'] . ' ' . $shareUrl) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary"><i class="fa-brands fa-whatsapp"></i> Bagikan</a>
      </div>
    </article>
  </div>
</section>

<?php if (count($related) > 0): ?>
<section class="section-alt news-related">
  <div class="container">
    <div class="section-head reveal"><h2>Berita Terkait</h2></div>
    <div class="nc-grid nc-grid-related">
      <?php foreach ($related as $n): include __DIR__ . '/includes/news-card.php'; endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>

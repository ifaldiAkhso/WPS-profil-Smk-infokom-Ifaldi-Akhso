<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-info no-footer';
$pdo = getDB();
$pageTitle = 'Pengumuman';
ensureAnnouncementImageColumn($pdo);
$items = $pdo->query("SELECT * FROM announcements WHERE is_active = 1 ORDER BY created_at DESC LIMIT 60")->fetchAll();
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
$heroEyebrow = 'Informasi';
$heroTitle = 'Pengumuman';
$heroText = 'Informasi resmi terbaru dari SMK INFOKOM BOGOR.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['Pengumuman', null]];
include __DIR__ . '/includes/page-hero.php';
?>
<section>
  <div class="container">
    <?php if (count($items) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-bullhorn"></i><p>Belum ada pengumuman.</p></div>
    <?php else: ?>
      <div class="notice-list">
        <?php foreach ($items as $a): ?>
          <?php $hasImg = uploadExists($a['image'] ?? null) && @getimagesize(BASE_PATH . '/assets/uploads/' . ltrim((string)$a['image'], '/')) !== false;  // tanpa file gambar nyata: tampil ikon, bukan "No Image" ?>
          <article class="notice-card reveal<?= $hasImg ? ' has-image' : '' ?>"<?= $hasImg ? ' style="--ar:' . round(imageRatio($a['image']), 4) . '"' : '' ?>>
            <?php if ($hasImg): ?>
              <figure class="notice-photo"><img src="<?= uploadUrl($a['image']) ?>" alt="<?= e($a['title']) ?>" loading="lazy" data-lightbox></figure>
            <?php else: ?>
              <div class="notice-ico"><i class="fa-solid fa-bullhorn"></i></div>
            <?php endif; ?>
            <div class="notice-body">
              <time><i class="fa-regular fa-calendar"></i> <?= e(tanggalIndo($a['created_at'])) ?></time>
              <h3><?= e($a['title']) ?></h3>
              <?php $txt = trim((string)$a['content']); if ($txt !== ''): ?>
                <div class="notice-text<?= mb_strlen($txt) > 220 ? ' is-clamp' : '' ?>">
                  <?php foreach (preg_split('/\R{2,}/', $txt) as $para): if (trim($para) === '') continue; ?>
                    <p><?= nl2br(e(trim($para))) ?></p>
                  <?php endforeach; ?>
                </div>
                <?php if (mb_strlen($txt) > 220): ?><button type="button" class="notice-more" data-more>Selengkapnya <i class="fa-solid fa-chevron-down"></i></button><?php endif; ?>
              <?php endif; ?>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>
<script>
document.querySelectorAll('[data-more]').forEach(function(b){
  b.addEventListener('click',function(){
    var t=b.previousElementSibling,open=t.classList.toggle('is-clamp');
    b.innerHTML=open?'Selengkapnya <i class="fa-solid fa-chevron-down"></i>':'Tutup <i class="fa-solid fa-chevron-up"></i>';
  });
});
</script>
<?php $backHref = BASE_URL . 'index.php'; $backLabel = 'Kembali ke Beranda'; include __DIR__ . '/includes/back-button.php'; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>

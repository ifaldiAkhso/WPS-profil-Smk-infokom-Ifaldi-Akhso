<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-info';
$pdo = getDB();
$pageTitle = 'Persyaratan Program Magang ke Jepang';
ensureJepangTables($pdo);

[$items] = splitJepangRequirements(jepangRequirements($pdo, true));   // Tahapan Program sudah dihapus dari halaman publik
$jp = jepangProfile($pdo);
$jpSourceUrl  = safeUrl($jp['source_url'] ?? '');
$jpSourceName = trim((string)($jp['source_name'] ?? '')) !== '' ? trim($jp['source_name']) : urlHost($jpSourceUrl);
$grouped = [];
foreach ($items as $it) {
    $grouped[$it['tag'] ?: 'Persyaratan Umum'][] = $it;
}

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'Program Magang';
$heroTitle   = 'Persyaratan Program Magang ke Jepang';
$heroText    = 'Persyaratan, dokumen, dan ketentuan yang perlu diketahui calon peserta.';
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['Program Magang ke Jepang', BASE_URL . 'program-jepang.php'], ['Persyaratan', null]];
$heroImage   = file_exists(BASE_PATH . '/assets/images/program-jepang-hero.jpg') ? 'assets/images/program-jepang-hero.jpg' : 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';
?>
<section class="profile-section">
  <div class="container">

    <div class="profile-heading reveal">
      <div class="article-kicker"><span></span> Persyaratan <span></span></div>
      <h2>Persyaratan Peserta</h2>
      <p>Pastikan kamu memenuhi seluruh persyaratan berikut sebelum mengikuti program.</p>
    </div>

    <?php if (count($grouped) === 0): ?>
      <div class="empty-state modern-empty" style="margin-top:26px;"><i class="fa-solid fa-clipboard-check"></i><p>Persyaratan belum diinformasikan oleh admin.</p></div>
    <?php else: ?>
      <div class="jp-req-groups">
        <?php foreach ($grouped as $tag => $rows): ?>
          <div class="faq-item reveal" style="border-radius:16px;">
            <div class="faq-question"><span><i class="fa-solid fa-list-check"></i> <?= e($tag) ?></span> <i class="fa-solid fa-chevron-down"></i></div>
            <div class="faq-answer">
              <ul class="jp-req-list">
                <?php foreach ($rows as $r): ?>
                  <li>
                    <i class="fa-solid fa-circle-check"></i>
                    <div>
                      <strong><?= e($r['title']) ?></strong>
                      <?php if (trim((string)$r['content']) !== ''): ?><span><?= nl2br(e($r['content'])) ?></span><?php endif; ?>
                    </div>
                  </li>
                <?php endforeach; ?>
              </ul>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <?php if ($jpSourceUrl !== ''): ?>
        <a href="<?= e($jpSourceUrl) ?>" target="_blank" rel="noopener noreferrer" class="source-link reveal" style="margin-top:28px;">
          <span class="source-link-ico"><i class="fa-solid fa-link"></i></span>
          <span class="source-link-text"><small>Sumber informasi</small><strong><?= e($jpSourceName) ?></strong><em><?= e($jpSourceUrl) ?></em></span>
          <span class="source-link-go"><i class="fa-solid fa-arrow-up-right-from-square"></i></span>
        </a>
      <?php endif; ?>
    <?php endif; ?>

  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

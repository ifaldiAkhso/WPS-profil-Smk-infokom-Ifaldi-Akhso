<?php
require_once __DIR__ . '/includes/functions.php';
$pdo = getDB();
ensureKabarSekolahColumn($pdo);

$pageTitle = 'Beranda';
$bodyClass = 'page-home';
$profile = schoolProfile();
$kabarVideoIds = youtubeIdsFromText($profile['kabar_video_url'] ?? '', 10);

$banners = $pdo->query("SELECT * FROM banners WHERE is_active = 1 ORDER BY sort_order ASC, id ASC")->fetchAll();
$statistics = schoolStatistics();
$programs = $pdo->query("SELECT * FROM programs WHERE is_active = 1 ORDER BY sort_order ASC LIMIT 4")->fetchAll();
$latestNews = $pdo->query("SELECT n.*, c.name AS category_name FROM news n LEFT JOIN news_categories c ON c.id = n.category_id WHERE n.status='published' ORDER BY n.published_at DESC LIMIT 4")->fetchAll();
$galleryPublicSql = galleryPublicSql($pdo);   // foto Program Jepang tidak ikut tampil di galeri
$latestGallery = $pdo->query("SELECT * FROM gallery WHERE $galleryPublicSql ORDER BY created_at DESC, id DESC LIMIT 6")->fetchAll();

$latestAnnouncement = $pdo->query("SELECT * FROM announcements WHERE is_active=1 ORDER BY created_at DESC LIMIT 1")->fetch();
ensureAgendaColumns($pdo);
$latestAgenda = $pdo->query("SELECT * FROM agendas WHERE event_date >= CURDATE() OR event_date IS NULL OR status = 'akan_datang' ORDER BY (event_date IS NULL) ASC, event_date ASC, id DESC LIMIT 1")->fetch()
    ?: $pdo->query("SELECT * FROM agendas ORDER BY event_date DESC LIMIT 1")->fetch();
$latestAchievement = $pdo->query("SELECT * FROM achievements ORDER BY created_at DESC LIMIT 1")->fetch();
$latestGalleryItem = $pdo->query("SELECT * FROM gallery WHERE $galleryPublicSql ORDER BY created_at DESC, id DESC LIMIT 1")->fetch();

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>

<!-- ============ HERO TERBELAH ============ -->
<section class="hero-slider" style="padding:0;">
  <?php
  $heroSlides = count($banners) > 0 ? $banners : [['image' => null, 'title' => '', 'subtitle' => '', '_fb' => true]];
  foreach ($heroSlides as $i => $b):
    $img = !empty($b['_fb']) ? BASE_URL . 'assets/images/hero-placeholder.jpg' : uploadUrl($b['image'], 'assets/images/hero-placeholder.jpg');
  ?>
    <div class="hero-slide <?= $i === 0 ? 'active' : '' ?>" style="background-image:url('<?= $img ?>')">
      <div class="container">
        <div class="hero-content">
          <span class="eyebrow-line">Selamat datang di</span>
          <h1><?= e($b['title'] !== '' ? $b['title'] : 'SMK Unggulan Berbasis Teknologi & Informasi') ?></h1>
          <?php if (trim((string)($b['subtitle'] ?? '')) !== ''): ?><p class="hero-desc"><?= e(trim((string)$b['subtitle'])) ?></p><?php endif; ?>
          <div class="hero-actions">
            <a href="<?= BASE_URL ?>ppdb.php" class="btn btn-gold">Daftar PPDB</a>
            <a href="<?= BASE_URL ?>profil.php" class="btn btn-outline">Kenali sekolah kami</a>
          </div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if (count($banners) > 1): ?>
    <button class="slider-arrow prev" aria-label="Sebelumnya"><i class="fa-solid fa-chevron-left"></i></button>
    <button class="slider-arrow next" aria-label="Berikutnya"><i class="fa-solid fa-chevron-right"></i></button>
    <div class="slider-controls" id="sliderDots"></div>
  <?php endif; ?>
</section>

<!-- ============ ANGKA SEKOLAH ============ -->
<section class="numbers">
  <div class="container numbers-row">
    <?php foreach ($statistics as $s): ?>
      <div class="stat-item">
        <div class="stat-number" data-target="<?= (int)$s['value'] ?>" data-suffix="<?= e($s['suffix']) ?>">0</div>
        <div class="stat-label"><?= e($s['label']) ?></div>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ============ INFO TERKINI: judul tetap + daftar ============ -->
<section class="sec">
  <div class="container feed">
    <div class="feed-title"><h2>Info terkini</h2><p>Pengumuman, agenda, dan pencapaian terbaru.</p></div>
    <div class="feed-list">
      <?php
      $feed = [
        ['Pengumuman','fa-bullhorn','pengumuman.php',$latestAnnouncement['title'] ?? null,$latestAnnouncement['created_at'] ?? null],
        ['Agenda','fa-calendar-days','agenda.php',$latestAgenda['title'] ?? null,$latestAgenda['event_date'] ?? null],
        ['Prestasi','fa-trophy','prestasi.php',$latestAchievement['title'] ?? null,$latestAchievement['created_at'] ?? null],
        ['Galeri','fa-images','galeri.php',($latestGalleryItem ? (trim((string)($latestGalleryItem['title'] ?? '')) !== '' ? $latestGalleryItem['title'] : 'Dokumentasi kegiatan terbaru') : null),$latestGalleryItem['created_at'] ?? null],
      ];
      foreach ($feed as $f): ?>
        <a class="feed-row" href="<?= BASE_URL . $f[2] ?>">
          <i class="fa-solid <?= $f[1] ?>"></i>
          <div><small><?= $f[0] ?></small><strong><?= e(trim((string)($f[3] ?? '')) !== '' ? $f[3] : 'Belum ada data') ?></strong></div>
          <time><?= $f[4] ? tanggalIndo($f[4]) : '' ?></time>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php
$welcomeMsg  = trim(preg_replace('~\s+~u', ' ', (string)($profile['principal_message'] ?? '')));
if (preg_match('~^\[[^\]]*\]$~', $welcomeMsg)) $welcomeMsg = '';
$welcomeName = trim((string)($profile['principal_name'] ?? ''));
if (preg_match('~^\[[^\]]*\]$~', $welcomeName)) $welcomeName = '';
?>
<!-- ============ SAMBUTAN: kartu teks menimpa foto ============ -->
<section class="hw">
  <div class="container">
    <article class="hw2">
      <figure class="hw2-photo">
        <img src="<?= uploadUrl($profile['principal_photo'] ?? null, 'assets/images/principal-placeholder.jpg') ?>" alt="<?= e($welcomeName !== '' ? $welcomeName : 'Kepala Sekolah') ?>" loading="lazy">
        <figcaption><strong><?= e($welcomeName !== '' ? $welcomeName : 'Kepala Sekolah') ?></strong><span>Kepala SMK INFOKOM BOGOR</span></figcaption>
      </figure>
      <div class="hw2-card">
        <span class="hw2-q" aria-hidden="true">“</span>
        <h2>Selamat datang di SMK INFOKOM BOGOR</h2>
        <p><?= $welcomeMsg !== '' ? e(cutSentence($welcomeMsg, 420)) : 'Kami menyambut Anda di website resmi SMK INFOKOM BOGOR. Bersama-sama kita wujudkan lulusan yang kompeten, berkarakter, dan siap bersaing di dunia kerja.' ?></p>
        <a href="<?= BASE_URL ?>sambutan.php" class="btn btn-primary">Baca selengkapnya <i class="fa-solid fa-arrow-right"></i></a>
      </div>
    </article>
  </div>
</section>

<!-- ============ MENGENAL SEKOLAH ============ -->
<section class="abt">
  <div class="container abt-grid">
    <figure class="abt-media">
      <img src="<?= BASE_URL ?>assets/images/sejarah.jpg" alt="Gedung SMK INFOKOM BOGOR">
      <figcaption><i class="fa-solid fa-location-dot"></i> Sejak 2005 · Kota Bogor</figcaption>
    </figure>
    <div class="abt-text">
      <h2>Mengenal SMK INFOKOM BOGOR</h2>
      <p><?= nl2br(e((string)($profile['short_description'] ?? ''))) ?></p>
      <ul class="about-list">
        <li><i class="fa-solid fa-chalkboard-user"></i><b>Guru profesional</b><span>Kompeten di bidangnya</span></li>
        <li><i class="fa-solid fa-computer"></i><b>Fasilitas praktik</b><span>Setara dunia kerja</span></li>
        <li><i class="fa-solid fa-code"></i><b>Kurikulum industri</b><span>Mengikuti teknologi</span></li>
      </ul>
      <a href="<?= BASE_URL ?>profil.php" class="btn btn-primary">Selengkapnya <i class="fa-solid fa-arrow-right"></i></a>
    </div>
  </div>
</section>

<!-- ============ PROGRAM: panel melebar ============ -->
<section class="sec">
  <div class="container">
    <div class="sec-head"><h2>Program keahlian</h2><a class="sec-link" href="<?= BASE_URL ?>akademik.php">Semua program <i class="fa-solid fa-arrow-right"></i></a></div>
    <?php if (count($programs) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-layer-group"></i><p>Program keahlian belum tersedia.</p></div>
    <?php else: ?>
      <div class="accordion">
        <?php foreach ($programs as $k => $p): ?>
          <a class="acc-panel<?= $k === 0 ? ' is-open' : '' ?>" href="akademik.php#<?= e($p['slug']) ?>">
            <img src="<?= uploadUrl($p['image'], 'assets/images/program-placeholder.jpg') ?>" alt="" loading="lazy">
            <div class="acc-text"><h3><?= e($p['name']) ?></h3><p><?= e(cutSentence(strip_tags($p['description'] ?? ''), 150)) ?></p></div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>


<!-- ============ BERITA TERBARU ============ -->
<section class="sec">
  <div class="container">
    <div class="sec-center">
      <span class="sec-pill">Informasi</span>
      <h2>Berita Terbaru</h2>
      <span class="sec-line"></span>
      <p>Ikuti perkembangan dan kegiatan terbaru SMK INFOKOM Kota Bogor.</p>
    </div>
    <?php if (count($latestNews) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-newspaper"></i><p>Belum ada berita.</p></div>
    <?php else: ?>
      <div class="nc-grid">
        <?php foreach (array_slice($latestNews, 0, 3) as $n): include __DIR__ . '/includes/news-card.php'; endforeach; ?>
      </div>
      <div class="sec-more"><a class="btn btn-dark" href="<?= BASE_URL ?>berita.php">Lihat Semua Berita</a></div>
    <?php endif; ?>
  </div>
</section>

<!-- ============ GALERI: jalur geser ============ -->
<section class="sec">
  <div class="container"><div class="sec-head"><h2>Galeri kegiatan</h2><a class="sec-link" href="<?= BASE_URL ?>galeri.php">Semua galeri <i class="fa-solid fa-arrow-right"></i></a></div></div>
  <?php if (count($latestGallery) === 0): ?>
    <div class="container"><div class="empty-state"><i class="fa-solid fa-images"></i><p>Belum ada dokumentasi kegiatan.</p></div></div>
  <?php else: ?>
    <div class="strip">
      <?php foreach ($latestGallery as $g): ?>
        <a href="<?= BASE_URL ?>galeri.php"><img src="<?= uploadUrl($g['image'], 'assets/images/gallery-placeholder.jpg') ?>" alt="<?= e($g['title'] ?? 'Galeri') ?>" loading="lazy"></a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>


<?php if ($kabarVideoIds): ?>
<!-- ============ KABAR SEKOLAH (video geser) ============ -->
<section class="kabar">
  <div class="container">
    <div class="sec-head"><h2>Kabar Sekolah</h2>
      <?php if (count($kabarVideoIds) > 1): ?>
      <div class="kabar-nav"><button type="button" id="kbPrev" aria-label="Video sebelumnya"><i class="fa-solid fa-chevron-left"></i></button><button type="button" id="kbNext" aria-label="Video berikutnya"><i class="fa-solid fa-chevron-right"></i></button></div>
      <?php endif; ?>
    </div>
  </div>
  <div class="kabar-strip" id="kabarStrip">
    <?php foreach ($kabarVideoIds as $vid): ?>
      <div class="kabar-item"><iframe src="https://www.youtube-nocookie.com/embed/<?= e($vid) ?>" title="Kabar Sekolah SMK INFOKOM BOGOR" loading="lazy"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></div>
    <?php endforeach; ?>
  </div>
</section>
<script>
(function(){var s=document.getElementById('kabarStrip');if(!s)return;
function go(d){s.scrollBy({left:d*(s.querySelector('.kabar-item').offsetWidth+16),behavior:'smooth'});}
var p=document.getElementById('kbPrev'),n=document.getElementById('kbNext');
if(p)p.addEventListener('click',function(){go(-1);});if(n)n.addEventListener('click',function(){go(1);});})();
</script>
<?php endif; ?>

<!-- ============ PPDB: pita penuh ============ -->
<section class="ppdb-band">
  <div class="container"><div class="ppdb-card">
    <div><h2>PPDB dibuka. Mulai langkahmu di sini.</h2><p>Daftar online dalam beberapa menit dan pantau statusnya kapan saja.</p></div>
    <a href="ppdb.php" class="btn btn-gold">Daftar sekarang <i class="fa-solid fa-arrow-right"></i></a>
  </div></div>
</section>


<?php include __DIR__ . '/includes/footer.php'; ?>

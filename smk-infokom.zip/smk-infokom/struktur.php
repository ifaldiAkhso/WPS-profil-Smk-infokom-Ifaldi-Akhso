<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-school no-tabs';
$pdo = getDB();
$pageTitle = 'Struktur Organisasi';
$activeProfile = 'struktur.php';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

ensureOrgGroupColumn($pdo);

// Kelompokkan anggota per Bidang. Bidang "Pimpinan" selalu tampil pertama; bidang lain menurut
// kemunculan pertamanya di data (MIN id), lalu nama — cukup sederhana tanpa perlu Urutan manual.
$allMembers = $pdo->query("
    SELECT o.*
    FROM organization_structure o
    JOIN (SELECT group_name, MIN(id) AS first_id FROM organization_structure GROUP BY group_name) g ON g.group_name = o.group_name
    ORDER BY (o.group_name = '" . ORG_TOP_GROUP . "') DESC, g.first_id ASC, o.name ASC
")->fetchAll();
$groups = [];
foreach ($allMembers as $m) {
    $groups[$m['group_name']][] = $m;
}
?>
<?php
$heroEyebrow = 'Profil Sekolah';
$heroTitle = 'Struktur Organisasi';
$heroText = 'Susunan organisasi yang mendukung pengelolaan sekolah dan proses pembelajaran, tersusun per bidang.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Struktur Organisasi', null]];
include __DIR__ . '/includes/page-hero.php';
?>

<section class="profile-section">
  <div class="container">
    <?php include __DIR__ . '/includes/profile-nav.php'; ?>

    <?php if (!$groups): ?>
      <div class="empty-state modern-empty"><i class="fa-solid fa-sitemap"></i><p>Data struktur organisasi belum tersedia.</p></div>
    <?php else: ?>
      <?php foreach ($groups as $groupName => $members): ?>
        <?php $isTop = $groupName === ORG_TOP_GROUP; ?>
        <div class="org-bidang-block reveal" style="<?= $isTop ? '' : 'margin-top:46px;' ?>">
          <div class="org-bidang-heading">
            <span class="org-bidang-pill<?= $isTop ? ' is-top' : '' ?>"><i class="fa-solid <?= $isTop ? 'fa-crown' : 'fa-diagram-project' ?>"></i> <?= e($groupName) ?></span>
          </div>
          <div class="staff-grid-modern org-staff-grid">
            <?php foreach ($members as $m): ?>
              <article class="staff-card-modern org-staff-card<?= $isTop ? ' is-lead' : '' ?>">
                <div class="staff-card-top">
                  <div class="staff-avatar-modern">
                    <img src="<?= uploadUrl($m['photo'] ?? null, 'assets/images/avatar-placeholder.jpg') ?>" alt="<?= e($m['name']) ?>">
                  </div>
                </div>
                <div class="staff-card-body-modern">
                  <h2><?= e($m['name']) ?></h2>
                  <p class="staff-position"><?= e($m['position']) ?></p>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

    <a href="<?= BASE_URL ?>sambutan.php" class="btn btn-outline-navy profile-back"><i class="fa-solid fa-arrow-left"></i> Kembali ke Sambutan Kepala Sekolah</a>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'pf-form page-profil';
$pdo = getDB();
$pageTitle = 'PPDB Online';
ensurePpdbInfoImageColumn($pdo);

$settings = $pdo->query("SELECT * FROM ppdb_settings ORDER BY id DESC LIMIT 1")->fetch();

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>
<?php
$heroEyebrow = 'PPDB';
$heroTitle = 'PPDB Online';
$heroText = 'Penerimaan Peserta Didik Baru SMK INFOKOM BOGOR. Daftar secara online dengan mudah.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['PPDB', null]];
$heroImage = 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';
?>

<section>
  <div class="container">
    <div class="ppdb-hero reveal">
      <div>
        <span class="eyebrow" style="color:var(--gold-500);">Tahun Ajaran <?= e($settings['academic_year'] ?? '-') ?></span>
        <h2 style="color:#fff;">Penerimaan Peserta Didik Baru</h2>
        <p>Bergabunglah bersama SMK INFOKOM BOGOR dan wujudkan masa depan yang kompeten, kreatif, dan siap kerja.</p>
        <?php if (empty($settings['is_open'])): ?>
          <p style="color:#ffe08a;font-weight:700;"><i class="fa-solid fa-circle-exclamation"></i> Pendaftaran saat ini ditutup.</p>
        <?php else: ?>
          <a href="<?= BASE_URL ?>ppdb-daftar.php" class="btn btn-gold">Daftar Sekarang</a>
        <?php endif; ?>
      </div>
      <div>
        <p style="color:#dde5f7;"><strong>Periode Pendaftaran:</strong><br>
        <?= $settings['start_date'] ? tanggalIndo($settings['start_date']) : '-' ?> s/d <?= $settings['end_date'] ? tanggalIndo($settings['end_date']) : '-' ?></p>
        <a href="cek-status.php" class="btn btn-outline">Cek Status Pendaftaran</a>
      </div>
    </div>
  </div>
</section>

<section class="section-alt">
  <div class="container">
    <div class="section-head reveal"><span class="eyebrow">Informasi</span><h2>Persyaratan Pendaftaran</h2></div>
    <?php if (!empty($settings['info_image'])): ?>
      <div class="reveal" style="max-width:820px;margin:0 auto;border-radius:var(--radius-lg);overflow:hidden;box-shadow:var(--shadow-md);">
        <img src="<?= uploadUrl($settings['info_image']) ?>" alt="Informasi PPDB <?= e($settings['academic_year'] ?? '') ?>" style="width:100%;display:block;">
      </div>
    <?php else: ?>
      <?php
      $reqLines = array_values(array_filter(array_map('trim', preg_split('/\R/u', (string)($settings['requirements'] ?? ''))), fn($l) => $l !== ''));
      $reqLines = array_map(fn($l) => preg_replace('/^\s*(?:\d+[\.\)]|[-•*])\s*/u', '', $l), $reqLines);
      if (count($reqLines) === 0) $reqLines = ['[ISI PERSYARATAN PENDAFTARAN PPDB]'];
      ?>
      <div class="req-wrap reveal">
        <table class="req-table">
          <thead><tr><th>No</th><th>Persyaratan</th></tr></thead>
          <tbody>
          <?php foreach ($reqLines as $i => $line): ?>
            <tr><td class="req-no"><?= $i + 1 ?></td><td><?= e($line) ?></td></tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</section>

<section>
  <div class="container">
    <div class="section-head reveal"><span class="eyebrow">Panduan</span><h2>Alur Pendaftaran</h2></div>
    <div class="flow-steps reveal">
      <div class="flow-step"><div class="flow-num">1</div><p>Klik "Daftar Sekarang" dan isi formulir pendaftaran online</p></div>
      <div class="flow-step"><div class="flow-num">2</div><p>Verifikasi data oleh panitia PPDB</p></div>
      <div class="flow-step"><div class="flow-num">3</div><p>Pengumuman hasil seleksi</p></div>
      <div class="flow-step"><div class="flow-num">4</div><p>Daftar ulang peserta didik baru</p></div>
    </div>
  </div>
</section>

<?php $faqs = ppdbFaqs($pdo, true); ?>
<section class="faq2">
  <div class="container">
    <div class="faq2-grid">
      <div class="faq2-intro">
        <h2>Pertanyaan seputar PPDB</h2>
        <p>Jawaban untuk hal-hal yang paling sering ditanyakan calon peserta didik dan orang tua. Belum ketemu? Tanyakan langsung ke panitia.</p>
        <a href="<?= BASE_URL ?>kontak.php" class="btn btn-primary">Hubungi Panitia</a>
      </div>
      <div class="faq2-list">
        <?php if (count($faqs) === 0): ?>
          <p class="faq2-empty">Belum ada pertanyaan yang ditampilkan.</p>
        <?php endif; ?>
        <?php foreach ($faqs as $f): ?>
          <details class="faq2-row">
            <summary><?= e($f['question']) ?></summary>
            <div class="faq2-ans"><?= e(trim((string)$f['answer']) !== '' ? $f['answer'] : 'Jawaban belum diisi.') ?></div>
          </details>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

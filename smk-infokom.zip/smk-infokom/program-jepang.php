<?php
require_once __DIR__ . '/includes/functions.php';
$pdo = getDB();
$pageTitle = 'Program Kerja ke Jepang';
ensureJepangTables($pdo);

// Catatan: jangan pakai nama $profile — header.php memakainya untuk profil sekolah.
$jp = jepangProfile($pdo);
[$persyaratan] = splitJepangRequirements(jepangRequirements($pdo, true));   // bagian Tahapan Program sudah dihapus dari halaman publik
$jpAbout   = cleanPlaceholder($jp['about'] ?? '');
$jpPurpose = cleanPlaceholder($jp['purpose'] ?? '');
$jpTarget  = cleanPlaceholder($jp['target_participants'] ?? '');
$jpStatus  = cleanPlaceholder($jp['status'] ?? '');
$jpSourceUrl  = safeUrl($jp['source_url'] ?? '');
$jpSourceName = trim((string)($jp['source_name'] ?? '')) !== '' ? trim($jp['source_name']) : urlHost($jpSourceUrl);
$jpVideoIds = youtubeIdsFromText($jp['video_url'] ?? '');
$jepangGalleryCatId = ensureJepangGalleryCategory($pdo);
$stmtJpg = $pdo->prepare("SELECT * FROM gallery WHERE category_id = ? ORDER BY created_at DESC, id DESC LIMIT 24");
$stmtJpg->execute([$jepangGalleryCatId]);
$jepangPhotos = $stmtJpg->fetchAll();

// Ajakan mengikuti sosial media (diutamakan Instagram, jika belum ada pakai sosial media lain yang tersedia).
$jepangSocial = $pdo->query("SELECT * FROM social_media WHERE url != '' AND url != '#' ORDER BY (LOWER(platform) LIKE '%instagram%') DESC, sort_order ASC LIMIT 1")->fetch() ?: null;

$bodyClass = 'page-profil pf-info pf-jepang no-tabs';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'Informasi';
$heroTitle   = 'Program Magang ke Jepang';
$heroText    = 'Program persiapan dan penyaluran kerja ke Jepang bagi siswa dan lulusan SMK INFOKOM BOGOR.';
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['Program Magang ke Jepang', null]];
$heroImage = null;
include __DIR__ . '/includes/page-hero.php';
?>
<section class="profile-section">
  <div class="container">

    <div class="profile-tabs-wrap">
      <nav class="profile-tabs profile-tabs-auto profile-tabs-plain" aria-label="Navigasi Program Magang">
        <a href="#tentang-program" class="active"><span>Tentang Program</span></a>
        <a href="#persyaratan"><span>Persyaratan</span></a>
        <a href="#dokumentasi"><span>Dokumentasi</span></a>
      </nav>
    </div>

    <!-- ====== Tentang Program ====== -->
    <div class="profile-heading reveal" id="tentang-program">
      <div class="article-kicker"><span></span> Informasi <span></span></div>
      <h2>Tentang Program Kerja ke Jepang</h2>
      <?php if ($jpAbout !== ''): ?><p><?= nl2br(e($jpAbout)) ?></p><?php else: ?><p>Informasi program magang ke Jepang akan segera diperbarui oleh sekolah.</p><?php endif; ?>
    </div>

    <?php if ($jepangSocial): ?>
      <a href="<?= e($jepangSocial['url']) ?>" target="_blank" rel="noopener" class="jp-social-cta reveal">
        <span class="jp-social-cta-icon"><i class="<?= e($jepangSocial['icon'] ?: 'fa-brands fa-instagram') ?>"></i></span>
        <span class="jp-social-cta-text">
          <strong>Ikuti Update Program Magang</strong>
          <small>Info kuota, seleksi, dan keberangkatan terbaru di <?= e($jepangSocial['platform']) ?></small>
        </span>
        <span class="jp-social-cta-arrow"><i class="fa-solid fa-arrow-up-right-from-square"></i></span>
      </a>
    <?php endif; ?>

    <div class="school-facts">
      <div class="school-fact">
        <div class="school-fact-icon"><i class="fa-solid fa-bullseye"></i></div>
        <div><small>Tujuan Program</small><strong><?= e($jpPurpose !== '' ? $jpPurpose : 'Belum diinformasikan') ?></strong></div>
      </div>
      <div class="school-fact">
        <div class="school-fact-icon"><i class="fa-solid fa-users"></i></div>
        <div><small>Target Peserta</small><strong><?= e($jpTarget !== '' ? $jpTarget : 'Belum diinformasikan') ?></strong></div>
      </div>
      <div class="school-fact">
        <div class="school-fact-icon"><i class="fa-solid fa-hourglass-half"></i></div>
        <div><small>Durasi</small><strong><?= e(trim((string)($jp['duration'] ?? '')) !== '' ? $jp['duration'] : 'Belum ditentukan') ?></strong></div>
      </div>
      <div class="school-fact">
        <div class="school-fact-icon"><i class="fa-solid fa-signal"></i></div>
        <div><small>Status Program</small><strong><?= e($jpStatus !== '' ? $jpStatus : 'Belum diinformasikan') ?></strong></div>
      </div>
    </div>

    <?php if (trim((string)($jp['important_info'] ?? '')) !== ''): ?>
      <div class="ks-rule-highlight reveal" style="margin-top:24px;">
        <i class="fa-solid fa-circle-exclamation"></i>
        <p><?= nl2br(e($jp['important_info'])) ?></p>
      </div>
    <?php endif; ?>

    <?php if ($jpSourceUrl !== ''): ?>
      <a href="<?= e($jpSourceUrl) ?>" target="_blank" rel="noopener noreferrer" class="source-link reveal">
        <span class="source-link-ico"><i class="fa-solid fa-link"></i></span>
        <span class="source-link-text">
          <small>Sumber informasi</small>
          <strong><?= e($jpSourceName) ?></strong>
          <em><?= e($jpSourceUrl) ?></em>
        </span>
        <span class="source-link-go"><i class="fa-solid fa-arrow-up-right-from-square"></i></span>
      </a>
    <?php endif; ?>

    <!-- ====== Persyaratan ====== -->
    <div class="profile-heading reveal" id="persyaratan" style="margin-top:50px;">
      <div class="article-kicker"><span></span> Persyaratan <span></span></div>
      <h2>Syarat Mengikuti Program</h2>
    </div>
    <?php if (count($persyaratan) === 0): ?>
      <div class="empty-state modern-empty" style="margin-top:22px;"><i class="fa-solid fa-clipboard-check"></i><p>Persyaratan belum diinformasikan oleh admin.</p></div>
    <?php else: ?>
      <div class="academic-info-grid">
        <?php foreach ($persyaratan as $it): ?>
          <article class="vm-modern-card academic-info-card reveal">
            <div class="vm-card-mark"><i class="<?= e($it['icon'] ?: 'fa-solid fa-circle-check') ?>"></i></div>
            <h2><?= e($it['title']) ?></h2>
            <p class="vm-lead"><?= nl2br(e(trim((string)($it['content'] ?? '')) !== '' ? $it['content'] : 'Belum diisi.')) ?></p>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <!-- ====== Dokumentasi Siswa Magang ====== -->
    <div class="profile-heading reveal" id="dokumentasi" style="margin-top:50px;">
      <div class="article-kicker"><span></span> Dokumentasi <span></span></div>
      <h2>Siswa yang Sudah Berangkat Magang ke Jepang</h2>
      <p>Dokumentasi perjalanan dan kegiatan siswa peserta Program Magang ke Jepang.</p>
    </div>
    <?php if (count($jepangPhotos) === 0): ?>
      <div class="empty-state modern-empty" style="margin-top:22px;"><i class="fa-solid fa-camera-retro"></i><p>Dokumentasi foto belum diunggah oleh admin.</p></div>
    <?php else: ?>
      <div class="jp-photo-grid">
        <?php foreach ($jepangPhotos as $g): ?>
          <figure class="jp-photo-card reveal">
            <img src="<?= uploadUrl($g['image']) ?>" alt="<?= e($g['title'] ?: 'Siswa magang ke Jepang') ?>" loading="lazy">
            <?php if (!empty($g['title'])): ?><figcaption><?= e($g['title']) ?></figcaption><?php endif; ?>
          </figure>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if (count($jpVideoIds) > 0): ?>
      <div class="jp-video-head reveal"><i class="fa-brands fa-youtube"></i><h3>Video Dokumentasi</h3></div>
      <div class="jp-video-grid<?= count($jpVideoIds) === 1 ? ' jp-video-single' : '' ?>">
        <?php foreach ($jpVideoIds as $vid): ?>
          <div class="jp-video reveal">
            <iframe src="https://www.youtube-nocookie.com/embed/<?= e($vid) ?>" title="Video dokumentasi magang ke Jepang" loading="lazy"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

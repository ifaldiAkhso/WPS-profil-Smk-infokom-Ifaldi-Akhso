<?php
require_once __DIR__ . '/includes/functions.php';
$pdo = getDB();
$pageTitle = 'Praktik Kerja Lapangan (PKL)';

// Teks pengantar PKL bisa diubah admin (Admin > Akademik > PKL). Bila kosong dipakai teks bawaan di bawah.
$sections = academicSections($pdo, true);
$pklIntro = '';
foreach ($sections as $sec) {
    if ((string)($sec['section_key'] ?? '') === 'pkl') { $pklIntro = trim((string)($sec['content'] ?? '')); break; }
}

// Mitra industri (dikelola di Admin > Perusahaan Mitra) — ditampilkan otomatis pada bagian Kerja Sama Industri
$partners = [];
$partnerTotal = 0;
if (ensureBkkTables($pdo)) {
    $partnerTotal = (int)$pdo->query("SELECT COUNT(*) FROM partner_companies WHERE is_partner = 1")->fetchColumn();
    $partners = $pdo->query("SELECT * FROM partner_companies WHERE is_partner = 1 ORDER BY name ASC LIMIT 12")->fetchAll();
}

$bodyClass = 'page-profil pf-info no-tabs';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'Informasi';
$heroTitle   = 'Praktik Kerja Lapangan (PKL)';
$heroText    = 'Belajar langsung di dunia usaha dan dunia industri untuk membangun kompetensi, etos kerja, dan kesiapan karier lulusan.';
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['PKL', null]];
$heroImage   = 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';

// Konten PKL dikelola admin di Admin > PKL (tambah / ubah / hapus / urutkan / sembunyikan).
$aboutItems = pklItems($pdo, 'tentang');
$goals      = pklItems($pdo, 'tujuan');
$coop       = pklItems($pdo, 'kerjasama');
$stages     = pklItems($pdo, 'tahapan');
?>
<section class="profile-section pkl-page">
  <div class="container">
    <div class="profile-tabs-wrap">
      <nav class="profile-tabs profile-tabs-auto profile-tabs-plain" aria-label="Navigasi PKL">
        <a href="#tentang-pkl" class="active"><span>Tentang PKL</span></a>
        <a href="#kerja-sama-industri"><span>Kerja Sama Industri</span></a>
        <a href="#tahapan-pkl"><span>Tahapan</span></a>
      </nav>
    </div>

    <!-- ====== Tentang PKL ====== -->
    <div class="profile-heading reveal" id="tentang-pkl">
      <div class="article-kicker"><span></span> Tentang PKL <span></span></div>
      <h2>Praktik Kerja Lapangan SMK INFOKOM BOGOR</h2>
    </div>
    <div class="pkl-about reveal">
      <div class="pkl-about-text">
        <p class="pkl-lead"><?= $pklIntro !== '' ? nl2br(e($pklIntro)) : 'Praktik Kerja Lapangan (PKL) adalah bagian penting dari pendidikan vokasi di SMK INFOKOM BOGOR. Melalui PKL, siswa belajar langsung di dunia usaha dan dunia industri (DUDI) sesuai kompetensi keahlian masing-masing.' ?></p>
        <?php foreach ($aboutItems as $ab): ?>
          <p><?= nl2br(e($ab['content'])) ?></p>
        <?php endforeach; ?>
      </div>
      <?php if (count($goals) > 0): ?>
      <div class="pkl-goals">
        <?php foreach ($goals as $g): ?>
          <div class="pkl-goal">
            <span class="pkl-goal-ico"><i class="<?= e($g['icon'] ?: 'fa-solid fa-circle-info') ?>"></i></span>
            <div><h3><?= e($g['title']) ?></h3><p><?= e($g['content']) ?></p></div>
          </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- ====== Kerja Sama Industri ====== -->
    <div class="profile-heading reveal" id="kerja-sama-industri" style="margin-top:56px;">
      <div class="article-kicker"><span></span> Kerja Sama Industri <span></span></div>
      <h2>Kerja Sama dengan Dunia Usaha &amp; Dunia Industri</h2>
      <p>SMK INFOKOM BOGOR menjalin kemitraan berkelanjutan dengan perusahaan dan instansi agar pembelajaran tetap relevan dengan kebutuhan industri.</p>
    </div>
    <?php if (count($coop) > 0): ?>
    <div class="academic-info-grid pkl-coop-grid">
      <?php foreach ($coop as $c): ?>
        <article class="vm-modern-card academic-info-card reveal">
          <div class="vm-card-mark"><i class="<?= e($c['icon'] ?: 'fa-solid fa-handshake') ?>"></i></div>
          <h2><?= e($c['title']) ?></h2>
          <p class="vm-lead"><?= nl2br(e($c['content'])) ?></p>
        </article>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="pkl-partners reveal">
      <div class="pkl-partners-head">
        <div>
          <h3>Mitra Industri</h3>
          <p><?= $partnerTotal > 0 ? 'Sebagian perusahaan dan instansi yang bekerja sama dengan sekolah.' : 'Daftar mitra industri akan segera ditampilkan di sini.' ?></p>
        </div>
        <a href="<?= BASE_URL ?>bkk-perusahaan.php" class="btn btn-outline-navy btn-sm">Lihat Semua Mitra<?= $partnerTotal > 0 ? ' (' . $partnerTotal . ')' : '' ?></a>
      </div>
      <?php if (count($partners) > 0): ?>
        <div class="pkl-partner-grid">
          <?php foreach ($partners as $c): ?>
            <a href="<?= BASE_URL ?>bkk-perusahaan-detail.php?id=<?= (int)$c['id'] ?>" class="pkl-partner">
              <?php if (uploadExists($c['logo'])): ?><img src="<?= uploadUrl($c['logo']) ?>" alt="<?= e($c['name']) ?>" loading="lazy"><?php endif; ?>
              <span><?= e($c['name']) ?></span>
              <?php if (!empty($c['field'])): ?><small><?= e($c['field']) ?></small><?php endif; ?>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- ====== Tahapan ====== -->
    <div class="profile-heading reveal" id="tahapan-pkl" style="margin-top:56px;">
      <div class="article-kicker"><span></span> Tahapan <span></span></div>
      <h2>Tahapan Pelaksanaan PKL</h2>
      <p>Alur PKL dari persiapan sampai siswa memperoleh sertifikat, berjalan berurutan dan didampingi sekolah maupun industri.</p>
    </div>
    <?php if (count($stages) === 0): ?>
      <div class="empty-state modern-empty"><i class="fa-solid fa-timeline"></i><p>Tahapan PKL belum diisi.</p></div>
    <?php else: ?>
    <ol class="pkl-steps">
      <?php foreach ($stages as $i => $st): ?>
        <li class="pkl-step reveal">
          <span class="pkl-step-num"><?= $i + 1 ?></span>
          <div class="pkl-step-card">
            <div class="pkl-step-ico"><i class="<?= e($st['icon'] ?: 'fa-solid fa-route') ?>"></i></div>
            <div>
              <h3><?= e($st['title']) ?></h3>
              <p><?= nl2br(e($st['content'])) ?></p>
            </div>
          </div>
        </li>
      <?php endforeach; ?>
    </ol>
    <?php endif; ?>

    <div class="cta-banner reveal" style="margin-top:56px;display:flex;align-items:center;justify-content:space-between;gap:20px;flex-wrap:wrap;">
      <div>
        <h3>Siapkan kompetensi untuk dunia kerja</h3>
        <p>Pelajari program keahlian dan peluang karier lulusan SMK INFOKOM BOGOR.</p>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <a href="<?= BASE_URL ?>akademik.php#program-keahlian" class="btn btn-gold">Program Keahlian</a>
        <a href="<?= BASE_URL ?>bkk.php" class="btn btn-outline">Bursa Kerja Khusus</a>
      </div>
    </div>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

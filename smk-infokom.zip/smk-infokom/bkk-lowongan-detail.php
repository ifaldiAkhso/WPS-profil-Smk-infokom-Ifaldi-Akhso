<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-info';
$pdo = getDB();
ensureBkkTables($pdo);

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT jv.*, jv.company_name AS company_name_free, c.name AS partner_name, c.logo AS company_logo, c.field AS company_field, c.location AS company_location, c.website AS company_website, p.name AS program_name
                        FROM job_vacancies jv
                        LEFT JOIN partner_companies c ON c.id = jv.company_id
                        LEFT JOIN programs p ON p.id = jv.program_id
                        WHERE jv.id = ?");
$stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) {
    setFlash('error', 'Lowongan kerja tidak ditemukan.');
    redirect(BASE_URL . 'bkk-lowongan.php');
}
$isOpen = $item['status'] === 'aktif' && (empty($item['deadline']) || $item['deadline'] >= date('Y-m-d'));
$jobCompany = jobCompanyName($item);
$jobName    = jobTitle($item);
$jobLoc     = jobLocation($item);
$pageTitle = $jobName;

/* Foto: poster mengikuti bentuk aslinya (potret/lanskap); tanpa poster dipakai logo kecil */
$hasPoster  = jobHasImage($item);
$photoRatio = $hasPoster ? imageRatio($item['image']) : 1.0;
$hasPhoto   = false;   // detail TIDAK menampilkan gambar (poster hanya di kartu daftar); semula: jobHasImage($item) — hanya poster lowongan; tanpa poster tidak ada kotak gambar (logo Mitra tidak dipakai)
$gridClass  = !$hasPhoto ? 'is-none' : ($photoRatio > 1.15 ? 'is-landscape' : 'is-portrait');

/* Ubah URL di dalam teks persyaratan menjadi tautan yang bisa diklik (tanda baca di ujung tidak ikut) */
function reqLinkify(string $escaped): string
{
    return preg_replace_callback('~https?://[^\s<]+~i', function ($m) {
        $url = rtrim($m[0], '.,;:!?)');
        $tail = substr($m[0], strlen($url));
        return '<a href="' . $url . '" target="_blank" rel="noopener">' . $url . '</a>' . $tail;
    }, $escaped);
}

/* Persyaratan: satu poin per baris (tanda - atau nomor di depan dibuang) */
$reqLines = [];
foreach (preg_split('/\R+/', (string)($item['requirements'] ?? '')) as $line) {
    $line = trim((string)preg_replace('/^\s*(?:[-•*·]|\d+[.)])\s*/u', '', trim($line)));
    if ($line !== '') $reqLines[] = $line;
}

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'Lowongan Kerja';
$heroTitle   = $jobName;
$heroText    = trim($jobCompany . ($jobLoc !== '' ? ($jobCompany !== '' ? ' — ' : '') . $jobLoc : ''));
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['BKK', BASE_URL . 'bkk.php'], ['Lowongan Kerja', BASE_URL . 'bkk-lowongan.php'], [$jobName, null]];
$heroCompact = true;
$heroImage   = file_exists(BASE_PATH . '/assets/images/bkk-hero.jpg') ? 'assets/images/bkk-hero.jpg' : 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';
?>
<section class="profile-section">
  <div class="container">
    <div class="profile-story-grid bkk-detail-grid <?= $gridClass ?> reveal">
      <?php if ($hasPhoto): ?>
      <div class="profile-photo-card bkk-detail-photo<?= $hasPoster ? ' is-poster' : '' ?>" style="--ar:<?= round($photoRatio, 4) ?>">
        <img src="<?= jobImageUrl($item) ?>" alt="<?= e($jobCompany !== '' ? $jobCompany : $jobName) ?>"<?= $hasPoster ? ' data-lightbox' : '' ?> onerror="var g=this.closest('.bkk-detail-grid');this.closest('.bkk-detail-photo').remove();g.classList.remove('is-portrait','is-landscape');g.classList.add('is-none');">
      </div>
      <?php endif; ?>
      <article class="profile-article-card">
        <div class="article-kicker"><span></span> Lowongan Kerja <span></span></div>
        <h2><?= e($jobName) ?></h2>
        <div class="bkk-job-badges" style="margin-bottom:14px;">
          <span class="bkk-badge <?= $isOpen ? 'bkk-badge-aktif' : 'bkk-badge-ditutup' ?>"><?= $isOpen ? 'Aktif' : 'Ditutup' ?></span>
          <?php if (!empty($item['program_name'])): ?><span class="bkk-badge bkk-badge-jurusan"><?= e($item['program_name']) ?></span><?php endif; ?>
        </div>

        <div class="article-copy">
          <?php $desc = trim((string)($item['description'] ?? '')); if ($desc !== ''): ?>
            <h4 style="font-size:1rem;color:var(--modern-navy);margin-bottom:8px;">Deskripsi Pekerjaan</h4>
            <?php foreach (preg_split('/\R{2,}/', $desc) as $para): if (trim($para) === '') continue; ?>
              <p><?= nl2br(e(trim($para))) ?></p>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>

        <div class="bkk-req">
          <h4><i class="fa-solid fa-clipboard-check"></i> Persyaratan</h4>
          <?php if ($reqLines): ?>
            <ul>
              <?php foreach ($reqLines as $rl): ?><li><i class="fa-solid fa-circle-check"></i><span><?= reqLinkify(e($rl)) ?></span></li><?php endforeach; ?>
            </ul>
          <?php else: ?>
            <p class="bkk-req-empty">Persyaratan belum diisi. Silakan hubungi BKK sekolah untuk informasi lengkap.</p>
          <?php endif; ?>
        </div>

        <div class="school-facts">
          <div class="school-fact">
            <div class="school-fact-icon"><i class="fa-solid fa-building"></i></div>
            <div><small>Perusahaan</small><strong><?= e($jobCompany !== '' ? $jobCompany : '-') ?></strong></div>
          </div>
          <div class="school-fact">
            <div class="school-fact-icon"><i class="fa-solid fa-location-dot"></i></div>
            <div><small>Lokasi</small><strong><?= e($jobLoc !== '' ? $jobLoc : 'Belum dicantumkan') ?></strong></div>
          </div>
          <div class="school-fact">
            <div class="school-fact-icon"><i class="fa-solid fa-layer-group"></i></div>
            <div><small>Jurusan Sesuai</small><strong><?= e($item['program_name'] ?: 'Semua Jurusan') ?></strong></div>
          </div>
          <div class="school-fact">
            <div class="school-fact-icon"><i class="fa-solid fa-hourglass-half"></i></div>
            <div><small>Batas Pendaftaran</small><strong><?= !empty($item['deadline']) ? tanggalIndo($item['deadline']) : 'Tidak ditentukan' ?></strong></div>
          </div>
        </div>

        <?php if ($isOpen && !empty($item['registration_link'])): ?>
          <a href="<?= e($item['registration_link']) ?>" target="_blank" rel="noopener" class="btn btn-gold" style="margin-top:22px;">Daftar Sekarang <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
        <?php elseif (!$isOpen): ?>
          <div class="ks-rule-highlight" style="margin-top:22px;"><i class="fa-solid fa-circle-info"></i><p>Lowongan ini sudah ditutup / melewati batas pendaftaran.</p></div>
        <?php endif; ?>
      </article>
    </div>

    <div class="profile-back reveal">
      <a href="<?= BASE_URL ?>bkk-lowongan.php" class="btn btn-outline-navy btn-sm"><i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar Lowongan</a>
    </div>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

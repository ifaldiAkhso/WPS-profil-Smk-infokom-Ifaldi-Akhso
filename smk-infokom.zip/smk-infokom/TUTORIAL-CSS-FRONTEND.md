# Tutorial Mengubah CSS Frontend — SMK INFOKOM BOGOR

## Yang berubah (baca dulu)

| Sebelum | Sekarang |
|---|---|
| 5 file: `style.css`, `modern.css`, `theme.css`, `profil.css`, `final.css` + 2 blok `<style>` di PHP | **1 file: `assets/css/frontend.css`** |
| Banyak aturan ganda yang saling menimpa (v2, v3, v9, v15, …) | Aturan ganda pada selector yang sama **sudah dihapus**. Tiap properti hanya ada 1 kali = nilai terbaru |
| Warna tersebar | Variabel warna & ukuran terkumpul di blok `:root` paling atas file |

- `includes/header.php` sekarang hanya memuat `frontend.css`.
- CSS yang dulu ada di `sambutan.php` dan `bkk-perusahaan-detail.php` dipindah ke BAGIAN 6 di `frontend.css`.
- Admin tetap terpisah: `assets/css/admin.css`.
- Tampilan **tidak berubah**. Saya mengujinya di browser: 1.682 selector dibandingkan sebelum/sesudah, di lebar desktop dan HP, hasilnya identik.

Susunan isi `frontend.css` (Ctrl+F untuk melompat):

| Cari teks | Isi |
|---|---|
| `:root{` | **warna, huruf, radius, bayangan** (ubah di sini dulu) |
| `BAGIAN 1` | fondasi: reset, tombol dasar, navbar dasar, hero, kartu, galeri, footer, modul Kesiswaan/BKK/Magang |
| `BAGIAN 2` | layout Beranda & Profil |
| `BAGIAN 3` | tema: tombol, kartu, banner halaman dalam, formulir, footer, navbar, dropdown, menu mobile |
| `BAGIAN 4` | halaman dalam: Sejarah, Visi & Misi, Sambutan, Akademik, Berita, Galeri, Prestasi, PPDB |
| `BAGIAN 5` | penyempurnaan: kartu berita, FAQ, kartu Mitra, filter pencarian, Program Jepang |
| `BAGIAN 6` | Sambutan Kepala Sekolah & detail Perusahaan Mitra |

> Catatan jujur: satu elemen kadang masih punya **dua aturan dengan selector berbeda**, misalnya `.hero-slide::before` (umum) dan `.page-home .hero-slide::before` (khusus beranda). Itu bukan duplikat, melainkan aturan umum + aturan khusus halaman. Cara menanganinya ada di bagian 4.

---

## 1. Mengubah WARNA

### A. Variabel di `:root` (paling atas file)

| Peran | Variabel | Nilai sekarang |
|---|---|---|
| Biru utama | `--navy-600`, `--modern-navy-3` | `#2b59ff` |
| Biru terang | `--blue-500` | `#4f7bff` |
| Biru tua | `--navy-700`, `--navy-800` | `#1b3fa8`, `#12296b` |
| Tinta / gelap | `--navy-900`, `--ink-900`, `--modern-navy` | `#0a1230` |
| Kuning aksen | `--gold-500`, `--modern-gold` | `#ffcf33` |
| Latar lembut | `--bg-soft`, `--modern-paper` | `#f1f4ff`, `#fafbff` |
| Garis tipis | `--line`, `--modern-line` | `#e1e6f5` |

Di BAGIAN 3 (cari `--ink:#0a1230`) ada variabel pendek yang dipakai hampir semua halaman: `--ink`, `--blue`, `--amber`, `--sky`, `--paper`, `--hair`, `--mut`. **Ubah keduanya bersamaan** (mis. biru utama = `--navy-600` dan `--blue`).

### B. Warna yang masih ditulis langsung

Gunakan **Ctrl+H** (Ganti) di `frontend.css`:

| Hex | Peran |
|---|---|
| `#2b59ff` | biru utama |
| `#12296b` | biru tua (gradasi banner & kartu Visi) |
| `#1b3fa8` | biru gelap |
| `#4f7bff` | biru terang |
| `#0a1230` | tinta |
| `#060c26` | tinta paling gelap (hero) |
| `#ffcf33` | kuning |
| `#e8eeff`, `#eaf0ff`, `#eef2ff` | biru sangat muda |

Contoh biru → hijau: ganti `#2b59ff`→`#0e9f6e`, `#12296b`→`#0a4d3a`, `#1b3fa8`→`#0b7a56`, `#4f7bff`→`#34c38f`, tiga biru muda→`#e8f7f1`, `#060c26`→`#04201a`. Simpan, lalu Ctrl+F5.

### C. Warna per bagian

| Bagian | Cari teks | Catatan |
|---|---|---|
| Banner halaman dalam | `linear-gradient(120deg,#060c26` | gradasi 3 warna |
| Overlay foto hero beranda | `.page-home .hero-slide::before` | 3 nilai `rgba` |
| Footer | `.site-footer{position:relative` | `background:var(--ink)` |
| Visi & Misi | `VISI & MISI: semua biru` | |
| Warna program keahlian | `AKADEMIK: warna tiap program` | `--acc`: RPL `#e0392b`, TKJ `#7c5cff`, DKV `#f57c00`, PSPT `#1fa75a` |
| Kartu Mitra | `.mitra-card-badge` | badge `#e8eefc`/`#2347b8` |
| Detail Mitra | `.mitra-badge` (BAGIAN 6) | |

---

## 2. Mengubah TAMPILAN

- **Navbar**: cari `.nav-wrap{height:72px` → tinggi 72px. Jika diubah, samakan `margin-bottom:-73px` pada `.page-home .site-header,.page-profil .site-header` (tinggi + 1). Kaca transparan: `background:rgba(255,255,255,.25)` (di atas hero) dan `.88` (setelah scroll).
- **Navbar hilang saat scroll**: diatur `assets/js/script.js` (kelas `nav-hidden`), bukan CSS.
- **Dropdown**: cari `.dropdown-nav{background:#fff` (versi polos, tanpa animasi).
- **Tombol**: cari `.btn,.page-home .btn,.page-profil .btn{` — border `2px`, bayangan `var(--pop)`. Datar: `box-shadow:none` dan hapus `.btn:hover{transform...}`.
- **Kartu**: cari `.news-card,.program-card,.info-card` — border tebal + hover naik. Halaman Profil memakai kartu lembut (`border:1px solid var(--hair)`).
- **Banner halaman dalam**: cari `padding:92px 0 34px` untuk tinggi banner.
- **Huruf**: `--ff-heading` (Sora) dan `--ff-body` (Inter) di `:root`. Font dimuat di `includes/header.php` (link Google Fonts).
- **Kartu berita**: cari `.nc-grid{display:grid` (4 kolom), rasio `.nc-media` `4/5`.
- **Kartu Mitra**: cari `.mitra-grid{` (3 kolom), logo `.mitra-card-logo` rasio `16/9`.
- **FAQ PPDB**: cari `.faq2`.
- **Filter & pencarian**: cari `label.search-select select`.
- **Animasi**: cari `.reveal` (muncul saat scroll, `.3s`); `body{animation:none !important}` mematikan fade halaman; transisi link `.12s` sengaja singkat.

---

## 3. Mengubah sesuatu yang "tidak berubah"

1. Klik kanan elemen → **Inspect**. Lihat selector yang **tidak dicoret**; itu yang aktif.
2. Di `frontend.css` tekan Ctrl+F, ketik nama kelas. Biasanya ada 1–3 hasil: aturan umum, aturan khusus halaman (`.page-home …`, `.page-profil …`, `body.pf-school …`), dan versi mobile di dalam `@media`.
3. Ubah yang sama dengan yang tidak dicoret di Inspect.
4. Kalau ada `!important`, pertahankan.

## 4. Menambah perubahan baru

Tulis di **paling bawah `frontend.css`** (BAGIAN 6), lalu beri komentar:

```css
/* [Okt 2026] Band angka beranda jadi hijau */
.page-home .numbers{background:#0e9f6e;}
```

Jangan membuat file CSS baru, supaya tetap satu tempat.

## 5. Catatan

- Cache: `?v=<filemtime>` di `header.php` otomatis menyegarkan; kalau masih lama, Ctrl+F5.
- Selalu cek tampilan HP (DevTools → ikon ponsel) karena setiap bagian punya `@media`.
- Cadangkan `frontend.css` sebelum mengubah banyak.
- `CATATAN-PERBAIKAN.md` adalah riwayat lama; nama file CSS di dalamnya (style/theme/final) sekarang semuanya ada di `frontend.css`.

---

## 6. Pembaruan Okt 2026 (baca ini dulu, menggantikan bagian lama yang bertentangan)

Yang paling sering diubah kini ada di **BAGIAN 7** (paling bawah `frontend.css`), semuanya berupa variabel:

| Mau ubah | Cari | Variabel |
|---|---|---|
| Kecepatan/jarak animasi | `7.1` | `--anim-fast`, `--anim-base`, `--anim-slow`, `--reveal-distance`, `--reveal-stagger` |
| Dropdown navbar (lebar, jarak, warna, kolom ikon) | `7.2` | `--dd-width`, `--dd-gap`, `--dd-icon-w`, `--dd-hover-bg`, dst |
| Tab tanpa ikon | `7.3` | class `profile-tabs-plain` pada `<nav>` |
| Kartu Pengumuman + gambar | `7.5` | `--notice-photo-w` |
| Poster Lowongan BKK | `7.6` | |

- Dropdown hanya ada di 7.2. Aturan lama (v9/v10/v13/v15) sudah dihapus.
- Animasi smooth aktif. Blok "klik instan" lama dihapus. Matikan semua animasi: set `--anim-*` ke `0s`.
- Kelas `no-anim` tidak dipakai lagi.
- Hapus ikon tab: hapus tag `<i>` di tab, tambahkan `profile-tabs-plain` pada `<nav>`.

### Admin
- Tanda kuning "Belum di website": ubah daftarnya di `admin/includes/frontend-status.php`.
- Lowongan BKK: Mitra opsional, bisa unggah gambar. Judul Kunjungan Industri opsional (teks bawaan: `visitTitle()` di `includes/functions.php`). Pengumuman bisa diberi gambar.
- Migrasi database berjalan otomatis; versi manual: `database/migrasi-okt-2026.sql`.

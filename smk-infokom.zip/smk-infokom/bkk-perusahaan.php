<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-info no-footer';
$pdo = getDB();
$pageTitle = 'Perusahaan Mitra';
ensureBkkTables($pdo);

$search = trim($_GET['q'] ?? '');
$field  = trim($_GET['bidang'] ?? '');

$fields = array_values(array_filter(array_column(
    $pdo->query("SELECT DISTINCT field FROM partner_companies WHERE is_partner = 1 AND field IS NOT NULL AND field <> '' ORDER BY field ASC")->fetchAll(),
    'field'
)));

$where = ['is_partner = 1', "TRIM(name) <> ''"];
$params = [];
if ($search !== '') { $where[] = "(name LIKE ? OR field LIKE ?)"; $like = likeParam($search); array_push($params, $like, $like); }
if ($field !== '')  { $where[] = "field = ?"; $params[] = $field; }
$whereSql = 'WHERE ' . implode(' AND ', $where);

$stmt = $pdo->prepare("SELECT * FROM partner_companies $whereSql ORDER BY name ASC");
$stmt->execute($params);
$list = $stmt->fetchAll();

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'BKK';
$heroTitle   = 'Perusahaan Mitra';
$heroText    = 'Perusahaan yang bekerja sama dengan SMK INFOKOM BOGOR dalam penyaluran kerja lulusan.';
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['BKK', BASE_URL . 'bkk.php'], ['Perusahaan Mitra', null]];
$heroImage   = file_exists(BASE_PATH . '/assets/images/bkk-hero.jpg') ? 'assets/images/bkk-hero.jpg' : 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';
?>
<section class="profile-section">
  <div class="container">

    <div class="profile-heading reveal">
      <div class="article-kicker"><span></span> Perusahaan Mitra <span></span></div>
      <h2>Perusahaan Mitra (<?= count($list) ?>)</h2>
      <p>Daftar perusahaan mitra resmi BKK SMK INFOKOM BOGOR.</p>
    </div>

    <?php
    $fbSearch = $search; $fbPlaceholder = 'Cari nama perusahaan atau bidang usaha...'; $fbNoun = 'perusahaan'; $fbTotal = count($list);
    $fbSelects = count($fields) > 0 ? [['name' => 'bidang', 'label' => 'Bidang Usaha', 'all' => 'Semua Bidang', 'options' => array_combine($fields, $fields), 'value' => $field]] : [];
    include __DIR__ . '/includes/filter-bar.php';
    ?>

    <?php if (count($list) === 0): ?>
      <div class="empty-state modern-empty" style="margin-top:26px;"><i class="fa-solid fa-handshake"></i><p>Belum ada data perusahaan mitra sesuai pencarian/filter.</p></div>
    <?php else: ?>
      <div class="mitra-grid">
        <?php foreach ($list as $c):
          $ini = '';
          foreach (preg_split('/\s+/', trim($c['name'])) as $w) { if ($w !== '' && mb_strlen($ini) < 2) $ini .= mb_strtoupper(mb_substr($w, 0, 1)); }
        ?>
          <a href="<?= BASE_URL ?>bkk-perusahaan-detail.php?id=<?= (int)$c['id'] ?>" class="mitra-card reveal">
            <div class="mitra-card-logo">
              <?php if (uploadExists($c['logo'])): ?>
                <img src="<?= uploadUrl($c['logo']) ?>" alt="<?= e($c['name']) ?>" loading="lazy">
              <?php else: ?>
                <span class="mitra-card-initials"><?= e($ini ?: 'M') ?></span>
              <?php endif; ?>
            </div>
            <span class="mitra-card-badge"><i class="fa-solid fa-circle-check"></i> Mitra Terverifikasi</span>
            <h3><?= e($c['name']) ?></h3>
            <?php if (!empty($c['field'])): ?><span class="mitra-card-field"><?= e($c['field']) ?></span><?php endif; ?>
            <?php if (!empty($c['location'])): ?><span class="mitra-card-loc"><i class="fa-solid fa-location-dot"></i> <?= e($c['location']) ?></span><?php endif; ?>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </div>
</section>
<?php $backHref = BASE_URL . 'pkl.php'; $backLabel = 'Kembali ke PKL'; include __DIR__ . '/includes/back-button.php'; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'pf-form page-profil';
$pdo = getDB();
$pageTitle = 'Formulir Pendaftaran PPDB';
ensurePpdbInfoImageColumn($pdo);
ensurePpdbFormPdfColumn($pdo);

$settings = $pdo->query("SELECT * FROM ppdb_settings ORDER BY id DESC LIMIT 1")->fetch();
$programs = activePrograms();

$errors = [];
$old = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        $errors[] = 'Sesi form telah kedaluwarsa, silakan coba kirim ulang.';
    } else {
        $old = $_POST;
        $len = function ($v) { return function_exists('mb_strlen') ? mb_strlen($v, 'UTF-8') : strlen($v); };
        $labels = [
            'full_name' => 'Nama lengkap', 'nik' => 'NIK', 'birth_place' => 'Tempat lahir', 'birth_date' => 'Tanggal lahir',
            'gender' => 'Jenis kelamin', 'address' => 'Alamat', 'phone' => 'Nomor HP', 'parent_name' => 'Nama orang tua/wali',
            'previous_school' => 'Asal sekolah', 'program_id' => 'Pilihan jurusan',
        ];
        foreach ($labels as $field => $label) {
            if (trim((string)($_POST[$field] ?? '')) === '') {
                $errors[] = $label . ' wajib diisi.';
            }
        }
        // Batas panjang sesuai kolom database
        $maxLen = ['full_name' => 150, 'nisn' => 20, 'birth_place' => 100, 'religion' => 30, 'phone' => 20,
                   'email' => 100, 'parent_name' => 150, 'parent_phone' => 20, 'previous_school' => 150];
        foreach ($maxLen as $field => $max) {
            if ($len(trim((string)($_POST[$field] ?? ''))) > $max) {
                $errors[] = ($labels[$field] ?? ucfirst(str_replace('_', ' ', $field))) . ' terlalu panjang (maksimal ' . $max . ' karakter).';
            }
        }
        if (!empty($_POST['nik']) && !preg_match('/^\d{16}$/', trim($_POST['nik']))) {
            $errors[] = 'NIK harus terdiri dari 16 digit angka.';
        }
        if (!empty($_POST['nisn']) && !preg_match('/^\d{1,20}$/', trim($_POST['nisn']))) {
            $errors[] = 'NISN hanya boleh berisi angka.';
        }
        if (!empty($_POST['email']) && !filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Format email tidak valid.';
        }
        if (!in_array($_POST['gender'] ?? '', ['Laki-laki', 'Perempuan'], true)) {
            $errors[] = 'Jenis kelamin tidak valid.';
        }
        $bd = DateTime::createFromFormat('Y-m-d', (string)($_POST['birth_date'] ?? ''));
        if (!$bd || $bd->format('Y-m-d') !== ($_POST['birth_date'] ?? '') || $bd > new DateTime('today')) {
            $errors[] = 'Tanggal lahir tidak valid.';
        }
        $validProgram = false;
        foreach ($programs as $p) {
            if ((int)$p['id'] === (int)($_POST['program_id'] ?? 0)) { $validProgram = true; break; }
        }
        if (!$validProgram) {
            $errors[] = 'Pilihan jurusan tidak valid.';
        }
        if (empty($settings['is_open'])) {
            $errors[] = 'Pendaftaran PPDB saat ini sedang ditutup.';
        }

        if (empty($errors)) {
            $sql = "INSERT INTO ppdb_registrations
                (registration_number, full_name, nik, nisn, birth_place, birth_date, gender, religion, address, phone, email, parent_name, parent_phone, previous_school, program_id, academic_year, status)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'Menunggu')";
            $saved = false;
            for ($try = 0; $try < 3 && !$saved; $try++) {
                try {
                    $regNumber = generateRegistrationNumber($pdo);
                    $pdo->prepare($sql)->execute([
                        $regNumber,
                        trim($_POST['full_name']),
                        trim($_POST['nik']),
                        trim($_POST['nisn'] ?? ''),
                        trim($_POST['birth_place']),
                        $_POST['birth_date'],
                        $_POST['gender'],
                        trim($_POST['religion'] ?? ''),
                        trim($_POST['address']),
                        trim($_POST['phone']),
                        trim($_POST['email'] ?? ''),
                        trim($_POST['parent_name']),
                        trim($_POST['parent_phone'] ?? ''),
                        trim($_POST['previous_school']),
                        (int)$_POST['program_id'],
                        $settings['academic_year'] ?? date('Y') . '/' . (date('Y') + 1),
                    ]);
                    $saved = true;
                } catch (Throwable $e) {
                    error_log('[PPDB daftar] ' . $e->getMessage());
                    // 23000 = nomor pendaftaran bentrok (jarang) -> coba lagi dengan nomor baru
                    if ($e instanceof PDOException && $e->getCode() === '23000' && $try < 2) continue;
                    break;
                }
            }
            if ($saved) {
                redirect('ppdb-sukses.php?no=' . urlencode($regNumber));
            }
            $errors[] = 'Maaf, data belum berhasil disimpan karena kendala pada server. Silakan coba lagi beberapa saat, atau hubungi panitia PPDB bila masalah berlanjut.';
        }
    }
}

$pdfBlock = '';
$pdfUrl = null;
if (!empty($settings['form_pdf'])) {
    $pdfUrl = uploadUrl($settings['form_pdf']);
} elseif (is_file(BASE_PATH . '/assets/downloads/formulir-ppdb-smk-infokom.pdf')) {
    // PDF bawaan (dipakai bila admin belum mengunggah PDF sendiri)
    $pdfUrl = BASE_URL . 'assets/downloads/formulir-ppdb-smk-infokom.pdf';
}
if ($pdfUrl) {
    $pdfLabel = trim($settings['form_pdf_label'] ?? '') ?: 'Unduh Formulir / Panduan PPDB (PDF)';
    ob_start(); ?>
      <div class="ppdb-pdf-download" style="margin-top:16px;text-align:center;">
        <a href="<?= e($pdfUrl) ?>" class="btn btn-outline-navy" target="_blank" rel="noopener" download>
          <i class="fa-solid fa-file-pdf"></i> <?= e($pdfLabel) ?>
        </a>
      </div>
    <?php $pdfBlock = ob_get_clean();
}

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'PPDB';
$heroTitle = 'Formulir Pendaftaran';
$heroText = 'Lengkapi data berikut untuk mendaftar sebagai calon peserta didik baru SMK INFOKOM BOGOR.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['PPDB', BASE_URL . 'ppdb.php'], ['Pendaftaran', null]];
$heroImage = 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';
?>

<section class="section-alt" id="form-ppdb">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">Tahun Ajaran <?= e($settings['academic_year'] ?? '-') ?></span>
      <h2>Formulir Pendaftaran PPDB</h2>
    </div>

    <?php if (!empty($errors)): ?>
      <div class="form-alert form-alert-error" data-toast="error" data-title="Pendaftaran belum berhasil" data-message="<?= e($errors[0]) ?>">
        <span class="form-alert-ico"><i class="fa-solid fa-triangle-exclamation"></i></span>
        <div><strong>Periksa kembali data Anda</strong>
        <ul>
          <?php foreach ($errors as $err): ?><li class="form-error"><?= e($err) ?></li><?php endforeach; ?>
        </ul></div>
      </div>
    <?php endif; ?>

    <?php if (!empty($settings['is_open'])): ?>
    <form method="post" class="form-card reveal" style="max-width:900px;margin:0 auto;">
      <?= csrfField() ?>
      <fieldset>
        <legend>Data Pribadi</legend>
        <div class="form-grid">
          <div class="form-group full">
            <label>Nama Lengkap <span class="req">*</span></label>
            <input type="text" name="full_name" maxlength="150" class="form-control" required value="<?= e($old['full_name'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label>NIK <span class="req">*</span></label>
            <input type="text" name="nik" maxlength="16" class="form-control" required value="<?= e($old['nik'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label>NISN</label>
            <input type="text" name="nisn" maxlength="20" class="form-control" value="<?= e($old['nisn'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label>Tempat Lahir <span class="req">*</span></label>
            <input type="text" name="birth_place" maxlength="100" class="form-control" required value="<?= e($old['birth_place'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label>Tanggal Lahir <span class="req">*</span></label>
            <input type="date" name="birth_date" class="form-control" required value="<?= e($old['birth_date'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label>Jenis Kelamin <span class="req">*</span></label>
            <select name="gender" class="form-control" required>
              <option value="">Pilih</option>
              <option value="Laki-laki" <?= (($old['gender'] ?? '') === 'Laki-laki') ? 'selected' : '' ?>>Laki-laki</option>
              <option value="Perempuan" <?= (($old['gender'] ?? '') === 'Perempuan') ? 'selected' : '' ?>>Perempuan</option>
            </select>
          </div>
          <div class="form-group">
            <label>Agama</label>
            <input type="text" name="religion" maxlength="30" class="form-control" value="<?= e($old['religion'] ?? '') ?>">
          </div>
          <div class="form-group full">
            <label>Alamat <span class="req">*</span></label>
            <textarea name="address" class="form-control" required><?= e($old['address'] ?? '') ?></textarea>
          </div>
          <div class="form-group">
            <label>Nomor HP <span class="req">*</span></label>
            <input type="text" name="phone" maxlength="20" class="form-control" required value="<?= e($old['phone'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" maxlength="100" class="form-control" value="<?= e($old['email'] ?? '') ?>">
          </div>
        </div>
      </fieldset>

      <fieldset>
        <legend>Data Orang Tua / Wali</legend>
        <div class="form-grid">
          <div class="form-group">
            <label>Nama Orang Tua/Wali <span class="req">*</span></label>
            <input type="text" name="parent_name" maxlength="150" class="form-control" required value="<?= e($old['parent_name'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label>Nomor HP Orang Tua</label>
            <input type="text" name="parent_phone" maxlength="20" class="form-control" value="<?= e($old['parent_phone'] ?? '') ?>">
          </div>
        </div>
      </fieldset>

      <fieldset>
        <legend>Data Sekolah & Jurusan</legend>
        <div class="form-grid">
          <div class="form-group">
            <label>Asal Sekolah <span class="req">*</span></label>
            <input type="text" name="previous_school" maxlength="150" class="form-control" required value="<?= e($old['previous_school'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label>Pilihan Jurusan <span class="req">*</span></label>
            <select name="program_id" class="form-control" required>
              <option value="">Pilih Jurusan</option>
              <?php foreach ($programs as $p): ?>
                <option value="<?= (int)$p['id'] ?>" <?= (int)($old['program_id'] ?? 0) === (int)$p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
      </fieldset>

      <button type="submit" class="btn btn-primary btn-block">Kirim Formulir Pendaftaran</button>
      <?= $pdfBlock ?>
    </form>
    <?php else: ?>
      <div class="empty-state reveal">
        <i class="fa-solid fa-circle-exclamation"></i>
        <p>Pendaftaran PPDB saat ini sedang ditutup.</p>
        <?= $pdfBlock ?>
      </div>
    <?php endif; ?>

    <div class="profile-back reveal" style="max-width:900px;margin:22px auto 0;">
      <a href="<?= BASE_URL ?>ppdb.php" class="btn btn-outline-navy btn-sm"><i class="fa-solid fa-arrow-left"></i> Kembali ke Informasi PPDB</a>
    </div>
  </div>
</section>
<script src="<?= BASE_URL ?>assets/js/script.js"></script>
<script>if(!window.siteJsReady){document.documentElement.classList.remove('js');}</script>
</body>
</html>

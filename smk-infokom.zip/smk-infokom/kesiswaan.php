<?php
require_once __DIR__ . '/includes/functions.php';
$pdo = getDB();
$pageTitle = 'Kesiswaan';
ensureKesiswaanTables($pdo);

$totalEkskul = (int)$pdo->query("SELECT COUNT(*) FROM extracurriculars WHERE is_active = 1")->fetchColumn();
$totalAturan = (int)$pdo->query("SELECT COUNT(*) FROM student_rules WHERE is_active = 1")->fetchColumn();

$featuredEkskul = activeExtracurriculars($pdo, 6);
$introRule = $pdo->query("SELECT * FROM student_rules WHERE is_active = 1 AND category = 'Pengantar' ORDER BY sort_order ASC LIMIT 1")->fetch();

$bodyClass = 'page-profil pf-akademik no-footer no-tabs';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'Akademik';
$heroTitle   = 'Kesiswaan';
$heroText    = 'Ekstrakurikuler dan tata tertib yang membentuk karakter, bakat, dan kedisiplinan siswa SMK INFOKOM BOGOR.';
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Akademik', BASE_URL . 'akademik.php'], ['Kesiswaan', null]];
$heroImage   = file_exists(BASE_PATH . '/assets/images/kesiswaan-hero.jpg') ? 'assets/images/kesiswaan-hero.jpg' : 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';
?>
<section class="profile-section">
  <div class="container">

    <div class="profile-tabs-wrap">
      <nav class="profile-tabs profile-tabs-auto" aria-label="Navigasi Kesiswaan">
        <a href="#ekstrakurikuler" class="active"><i class="fa-solid fa-person-running"></i><span>Ekstrakurikuler</span></a>
        <a href="#tata-tertib"><i class="fa-solid fa-scale-balanced"></i><span>Tata Tertib</span></a>
      </nav>
    </div>

    <div class="profile-heading reveal">
      <div class="article-kicker"><span></span> Ringkasan <span></span></div>
      <h2>Kehidupan Siswa di SMK INFOKOM BOGOR</h2>
      <p>Wadah pengembangan bakat, minat, dan karakter siswa melalui ekstrakurikuler serta aturan yang menjaga kenyamanan bersama.</p>
    </div>

    <div class="ks-info-grid" style="grid-template-columns:repeat(2,minmax(0,1fr));max-width:560px;">
      <a href="#ekstrakurikuler" class="ks-info-card reveal">
        <div class="ks-info-icon"><i class="fa-solid fa-person-running"></i></div>
        <strong><?= $totalEkskul ?></strong>
        <span>Ekstrakurikuler Aktif</span>
      </a>
      <a href="<?= BASE_URL ?>kesiswaan-tata-tertib.php" class="ks-info-card reveal">
        <div class="ks-info-icon"><i class="fa-solid fa-scale-balanced"></i></div>
        <strong><?= $totalAturan ?></strong>
        <span>Poin Tata Tertib</span>
      </a>
    </div>

    <!-- ====== Ekstrakurikuler ====== -->
    <div class="ks-section-row" id="ekstrakurikuler" style="scroll-margin-top:96px;">
      <div class="profile-heading reveal">
        <div class="article-kicker"><span></span> Ekstrakurikuler <span></span></div>
        <h2>Ekstrakurikuler Unggulan</h2>
      </div>
      <a href="<?= BASE_URL ?>kesiswaan-ekstrakurikuler.php" class="ks-see-all">Lihat semua <i class="fa-solid fa-arrow-right"></i></a>
    </div>
    <?php if (count($featuredEkskul) === 0): ?>
      <div class="empty-state modern-empty" style="margin-top:22px;"><i class="fa-solid fa-person-running"></i><p>Data ekstrakurikuler belum tersedia.</p></div>
    <?php else: ?>
      <div class="ks-ekskul-grid">
        <?php foreach ($featuredEkskul as $ek): ?>
          <div class="ks-ekskul-card reveal">
            <div class="ks-ekskul-media">
              <img src="<?= uploadUrl($ek['photo'], 'assets/images/program-placeholder.jpg') ?>" alt="<?= e($ek['name']) ?>">
              <span class="ks-ekskul-status aktif">Aktif</span>
              <?php if (!empty($ek['category'])): ?><span class="ks-ekskul-cat"><?= e($ek['category']) ?></span><?php endif; ?>
            </div>
            <div class="ks-ekskul-body">
              <h3><?= e($ek['name']) ?></h3>
              <ul class="ks-ekskul-facts">
                <li><i class="fa-solid fa-clock"></i><div><small>Jadwal</small><strong><?= e($ek['schedule'] ?: 'Belum diinformasikan') ?></strong></div></li>
                <li><i class="fa-solid fa-user-tie"></i><div><small>Pembina</small><strong><?= e($ek['supervisor'] ?: 'Belum diinformasikan') ?></strong></div></li>
              </ul>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <!-- ====== Tata Tertib (showcase modern, gaya seperti Program Keahlian) ====== -->
    <div class="profile-story-grid program-story reveal" id="tata-tertib" style="margin-top:56px;scroll-margin-top:96px;">
      <div class="profile-photo-card">
        <img src="<?= uploadUrl(null, 'assets/images/image.png') ?>" alt="Tata Tertib Siswa">
        <div class="photo-caption"><i class="fa-solid fa-scale-balanced"></i><span>Tata Tertib</span></div>
      </div>
      <article class="profile-article-card">
        <div class="article-kicker"><span></span> Tata Tertib <span></span></div>
        <h2>Disiplin &amp; Kenyamanan Bersama</h2>
        <div class="article-copy">
          <?php if ($introRule && trim((string)$introRule['content']) !== ''): ?>
            <p><?= nl2br(e(trim($introRule['content']))) ?></p>
          <?php else: ?>
            <p>Tata tertib sekolah disusun untuk menjaga kedisiplinan, keamanan, dan kenyamanan bersama seluruh warga sekolah. Informasi lengkap mengenai hak, kewajiban, ketentuan, dan sanksi dapat dibaca pada halaman Tata Tertib.</p>
          <?php endif; ?>
        </div>
        <a href="<?= BASE_URL ?>kesiswaan-tata-tertib.php" class="btn btn-gold" style="align-self:flex-start;margin-top:6px;">Baca Selengkapnya <i class="fa-solid fa-arrow-right"></i></a>
      </article>
    </div>

    <!-- ====== CTA ====== -->
    <div class="cta-banner reveal" style="margin-top:50px;display:flex;align-items:center;justify-content:space-between;gap:20px;flex-wrap:wrap;">
      <div>
        <h3>Ingin bergabung dengan ekstrakurikuler pilihan?</h3>
        <p>Lihat daftar lengkap ekstrakurikuler dan mulai kembangkan bakatmu di SMK INFOKOM BOGOR.</p>
      </div>
      <a href="<?= BASE_URL ?>kesiswaan-ekstrakurikuler.php" class="btn btn-gold">Lihat Ekstrakurikuler</a>
    </div>

  </div>
</section>
<?php $backHref = BASE_URL . 'akademik.php#program-keahlian'; $backLabel = 'Kembali ke Program Keahlian'; include __DIR__ . '/includes/back-button.php'; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>

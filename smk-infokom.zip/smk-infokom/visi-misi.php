<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-school no-tabs';
$profile = schoolProfile();
$pageTitle = 'Visi & Misi';
$activeProfile = 'visi-misi.php';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$missionLines = preg_split('/\R+/', trim((string)($profile['mission'] ?? '')));
$missionLines = array_values(array_filter(array_map('trim', $missionLines)));
$vision = trim((string)($profile['vision'] ?? ''));
$excellence = trim((string)($profile['excellence'] ?? ''));
?>
<?php
$heroEyebrow = 'Profil Sekolah';
$heroTitle = 'Visi & Misi';
$heroText = 'Landasan, arah, dan komitmen SMK INFOKOM BOGOR dalam menyiapkan generasi unggul.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Visi & Misi', null]];
include __DIR__ . '/includes/page-hero.php';
?>

<section class="profile-section">
  <div class="container">
    <?php include __DIR__ . '/includes/profile-nav.php'; ?>

    <div class="vm-modern-grid reveal">
      <article class="vm-modern-card vm-modern-vision">
        <div class="vm-card-mark"><i class="fa-solid fa-eye"></i></div>
        <div class="article-kicker"><span></span> Arah Sekolah <span></span></div>
        <h2>Visi</h2>
        <p class="vm-lead"><?= nl2br(e($vision !== '' ? $vision : 'Visi sekolah belum diisi.')) ?></p>
        <div class="vm-card-line"></div>
        <p class="vm-note">Visi menjadi pijakan utama dalam pengembangan pembelajaran, karakter, dan budaya sekolah.</p>
      </article>

      <article class="vm-modern-card vm-modern-mission">
        <div class="vm-card-mark"><i class="fa-solid fa-bullseye"></i></div>
        <div class="article-kicker"><span></span> Langkah Strategis <span></span></div>
        <h2>Misi</h2>
        <?php if ($missionLines): ?>
          <ol class="mission-list-modern">
            <?php foreach ($missionLines as $index => $mission): ?>
              <li><span><?= str_pad((string)($index + 1), 2, '0', STR_PAD_LEFT) ?></span><p><?= e($mission) ?></p></li>
            <?php endforeach; ?>
          </ol>
        <?php else: ?>
          <p class="vm-note">Misi sekolah belum diisi. Admin dapat mengubahnya melalui Dashboard Admin > Profil Sekolah.</p>
        <?php endif; ?>
      </article>
    </div>

    <article class="excellence-modern reveal">
      <div class="excellence-icon"><i class="fa-solid fa-star"></i></div>
      <div>
        <div class="article-kicker article-kicker-light"><span></span> Nilai Unggulan <span></span></div>
        <h2>Keunggulan Sekolah</h2>
        <p><?= nl2br(e($excellence !== '' ? $excellence : 'Informasi keunggulan sekolah belum diisi.')) ?></p>
      </div>
    </article>

    <a href="<?= BASE_URL ?>sejarah.php" class="btn btn-outline-navy profile-back"><i class="fa-solid fa-arrow-left"></i> Kembali ke Sejarah Sekolah</a>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

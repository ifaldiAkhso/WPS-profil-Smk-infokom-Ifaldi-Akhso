<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-info no-footer';
$pdo = getDB();
$pageTitle = 'Prestasi';
ensureAchievementColumns($pdo);

$level = trim($_GET['tingkat'] ?? '');
$sql = "SELECT * FROM achievements";
$params = [];
if ($level !== '') { $sql .= " WHERE level = ?"; $params[] = $level; }
$sql .= " ORDER BY year DESC, created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$achievements = $stmt->fetchAll();

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>
<?php
$heroEyebrow = 'Prestasi';
$heroTitle = 'Prestasi';
$heroText = 'Capaian membanggakan siswa dan sekolah di berbagai tingkat.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Prestasi', null]];
include __DIR__ . '/includes/page-hero.php';
?>

<section>
  <div class="container">
    <form method="get" class="gallery-filter reveal">
      <button type="submit" name="tingkat" value="" class="<?= $level === '' ? 'active' : '' ?>">Semua</button>
      <button type="submit" name="tingkat" value="Kabupaten/Kota" class="<?= $level === 'Kabupaten/Kota' ? 'active' : '' ?>">Kabupaten/Kota</button>
      <button type="submit" name="tingkat" value="Provinsi" class="<?= $level === 'Provinsi' ? 'active' : '' ?>">Provinsi</button>
      <button type="submit" name="tingkat" value="Nasional" class="<?= $level === 'Nasional' ? 'active' : '' ?>">Nasional</button>
      <button type="submit" name="tingkat" value="Internasional" class="<?= $level === 'Internasional' ? 'active' : '' ?>">Internasional</button>
    </form>

    <?php if (count($achievements) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-trophy"></i><p>Belum ada data prestasi.</p></div>
    <?php else: ?>
      <div class="achieve-grid">
        <?php foreach ($achievements as $a): ?>
          <div class="achieve-card reveal">
            <div class="achieve-media"><img src="<?= uploadUrl($a['image'], 'assets/images/achievement-placeholder.jpg') ?>" alt="<?= e($a['title']) ?>"></div>
            <div>
              <span class="achieve-level"><?= e($a['level']) ?></span>
              <h4 style="font-size:.95rem;margin-bottom:4px;"><?= e($a['title']) ?></h4>
              <span style="font-size:.8rem;color:var(--ink-500);"><?= e((string)$a['year']) ?></span>
              <?php $aUrl = safeUrl($a['source_url'] ?? ''); ?>
              <?php if ($aUrl !== ''): ?>
                <a href="<?= e($aUrl) ?>" target="_blank" rel="noopener noreferrer" class="achieve-source" title="<?= e($aUrl) ?>">
                  <i class="fa-solid fa-link"></i> Sumber: <?= e(trim((string)($a['source_name'] ?? '')) !== '' ? $a['source_name'] : urlHost($aUrl)) ?> <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </a>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php $backHref = BASE_URL . 'index.php'; $backLabel = 'Kembali ke Beranda'; include __DIR__ . '/includes/back-button.php'; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/functions.php';
redirect('sejarah.php');

<?php
/**
 * Panel pencarian & filter seragam untuk semua halaman publik (Berita, Galeri, Lowongan, Perusahaan Mitra, Ekstrakurikuler).
 *
 * Variabel yang dibaca:
 *   $fbAction       URL tujuan form (kosong = halaman ini)
 *   $fbSearch       kata kunci saat ini
 *   $fbPlaceholder  placeholder kolom cari
 *   $fbSelects      [['name'=>'kategori','label'=>'Kategori','all'=>'Semua Kategori','options'=>[nilai=>label,...],'value'=>nilai terpilih], ...]
 *   $fbTotal        (opsional) jumlah hasil untuk ditampilkan
 *   $fbNoun         (opsional) kata benda hasil, mis. "berita"
 */
$fbAction      = $fbAction ?? '';
$fbSearch      = trim((string)($fbSearch ?? ''));
$fbPlaceholder = $fbPlaceholder ?? 'Cari...';
$fbSelects     = $fbSelects ?? [];
$fbNoun        = $fbNoun ?? 'hasil';

// Chip filter aktif: tiap chip punya tautan untuk menghapus filter itu saja (halaman kembali ke 1)
$fbBase = $_GET;
unset($fbBase['page']);
$fbUrlWithout = function (string $key) use ($fbBase, $fbAction): string {
    $q = $fbBase;
    unset($q[$key]);
    $q = array_filter($q, fn($v) => $v !== '' && $v !== '0' && $v !== 0);
    return ($fbAction !== '' ? $fbAction : strtok((string)($_SERVER['REQUEST_URI'] ?? ''), '?')) . ($q ? '?' . http_build_query($q) : '');
};
$fbChips = [];
if ($fbSearch !== '') $fbChips[] = ['label' => '“' . safeCut($fbSearch, 28) . '”', 'url' => $fbUrlWithout('q'), 'icon' => 'fa-magnifying-glass'];
foreach ($fbSelects as $sel) {
    $val = (string)($sel['value'] ?? '');
    if ($val !== '' && $val !== '0' && isset($sel['options'][$val])) {
        $fbChips[] = ['label' => (string)$sel['options'][$val], 'url' => $fbUrlWithout($sel['name']), 'icon' => 'fa-filter'];
    }
}
$fbResetUrl = $fbAction !== '' ? $fbAction : strtok((string)($_SERVER['REQUEST_URI'] ?? ''), '?');
?>
<form method="get" action="<?= e($fbAction) ?>" class="search-panel reveal" role="search">
  <div class="search-panel-main">
    <label class="search-field">
      <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
      <input type="search" name="q" value="<?= e($fbSearch) ?>" placeholder="<?= e($fbPlaceholder) ?>" aria-label="<?= e($fbPlaceholder) ?>" autocomplete="off" maxlength="80">
      <?php if ($fbSearch !== ''): ?><a href="<?= e($fbUrlWithout('q')) ?>" class="search-clear" aria-label="Hapus kata kunci" title="Hapus kata kunci"><i class="fa-solid fa-xmark"></i></a><?php endif; ?>
    </label>
    <button class="btn btn-primary search-submit" type="submit"><span>Cari</span></button>
  </div>

  <?php if (count($fbSelects) > 0): ?>
  <div class="search-panel-filters">
    <?php foreach ($fbSelects as $sel): ?>
      <label class="search-select">
        <span><?= e($sel['label']) ?></span>
        <select name="<?= e($sel['name']) ?>" onchange="this.form.submit()" aria-label="<?= e($sel['label']) ?>">
          <option value=""><?= e($sel['all'] ?? 'Semua') ?></option>
          <?php foreach ($sel['options'] as $val => $label): ?>
            <option value="<?= e((string)$val) ?>" <?= (string)($sel['value'] ?? '') === (string)$val ? 'selected' : '' ?>><?= e((string)$label) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if (count($fbChips) > 0 || isset($fbTotal)): ?>
  <div class="search-panel-meta">
    <?php if (isset($fbTotal)): ?><span class="search-count"><strong><?= (int)$fbTotal ?></strong> <?= e($fbNoun) ?> ditemukan</span><?php endif; ?>
    <?php foreach ($fbChips as $chip): ?>
      <a href="<?= e($chip['url']) ?>" class="search-chip" title="Hapus filter"><i class="fa-solid <?= e($chip['icon']) ?>"></i> <?= e($chip['label']) ?> <i class="fa-solid fa-xmark chip-x"></i></a>
    <?php endforeach; ?>
    <?php if (count($fbChips) > 0): ?><a href="<?= e($fbResetUrl) ?>" class="search-reset">Reset semua</a><?php endif; ?>
  </div>
  <?php endif; ?>
</form>

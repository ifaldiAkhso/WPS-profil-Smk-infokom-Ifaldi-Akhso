<?php
/**
 * Hero seragam untuk semua halaman dalam (Profil, Akademik, Berita, Galeri, dst).
 * Variabel yang dibaca (semua opsional kecuali $heroTitle):
 *   $heroEyebrow  teks kecil di atas judul
 *   $heroTitle    judul halaman
 *   $heroText     deskripsi singkat
 *   $heroCrumbs   [[label, url|null], ...]  (item pertama diberi ikon rumah)
 *   $heroCompact  true untuk judul panjang (mis. judul berita)
 *   $heroImage    path gambar latar (kosong/null = latar gradien tanpa foto)
 */
$heroImage   = null; // semua banner halaman dalam: tanpa foto
$heroCrumbs  = $heroCrumbs ?? [['Beranda', BASE_URL . 'index.php']];
// Deskripsi banner: rapikan spasi/baris baru, buang placeholder "[ISI ... ADMIN]" dan batasi panjangnya agar tidak meluber
$heroText    = trim(preg_replace('~\s+~u', ' ', (string)($heroText ?? '')));
if (preg_match('~^\[[^\]]*\]$~', $heroText)) $heroText = '';
$heroText    = mb_or_cut($heroText, 190);
$heroCompact = !empty($heroCompact);
$heroHasImage = !empty($heroImage);
$heroVariant = $heroVariant ?? null;
if (false):
  $phImg = $heroImage ?: 'assets/images/profile-hero-building.jpg';
?>
<section class="ph">
  <div class="container ph-grid">
    <div class="ph-text">
      <nav class="ph-crumb" aria-label="Breadcrumb">
        <?php foreach ($heroCrumbs as $i => $crumb): ?>
          <?php if ($i > 0): ?><span aria-hidden="true">/</span><?php endif; ?>
          <?php if (!empty($crumb[1])): ?><a href="<?= e($crumb[1]) ?>"><?= e($crumb[0]) ?></a><?php else: ?><span aria-current="page"><?= e($crumb[0]) ?></span><?php endif; ?>
        <?php endforeach; ?>
      </nav>
      <h1><?= e($heroTitle ?? '') ?></h1>
      <?php if ($heroText !== ''): ?><p><?= e($heroText) ?></p><?php endif; ?>
    </div>
  </div>
</section>
<?php return; endif; ?>
<section class="profile-hero<?= $heroCompact ? ' profile-hero-compact' : '' ?><?= !$heroHasImage ? ' profile-hero-no-image' : '' ?>">
  <?php if ($heroHasImage): ?>
  <div
    class="profile-hero-bg"
    style="background-image:url('<?= e(BASE_URL . $heroImage) ?>');"
    aria-hidden="true"></div>
  <?php endif; ?>
  <div class="profile-hero-shape profile-hero-shape-left" aria-hidden="true"></div>
  <div class="profile-hero-shape profile-hero-shape-right" aria-hidden="true"></div>
  <div class="container profile-hero-inner reveal">
    <?php if (!empty($heroEyebrow)): ?><span class="profile-hero-eyebrow"><?= e($heroEyebrow) ?></span><?php endif; ?>
    <h1><?= e($heroTitle ?? '') ?></h1>
    <?php if ($heroText !== ''): ?><p class="profile-hero-desc"><?= e($heroText) ?></p><?php endif; ?>
    <div class="breadcrumb profile-breadcrumb">
      <?php foreach ($heroCrumbs as $i => $crumb): ?>
        <?php if ($i > 0): ?><span>/</span><?php endif; ?>
        <?php if (!empty($crumb[1])): ?>
          <a href="<?= e($crumb[1]) ?>"><?php if ($i === 0): ?><i class="fa-solid fa-house"></i> <?php endif; ?><?= e($crumb[0]) ?></a>
        <?php else: ?>
          <span><?= e($crumb[0]) ?></span>
        <?php endif; ?>
      <?php endforeach; ?>
    </div>
  </div>
</section>

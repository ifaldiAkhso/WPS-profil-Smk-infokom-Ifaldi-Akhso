<?php $profile = $profile ?? schoolProfile(); ?>
<footer class="site-footer">
  <div class="container footer-grid">
    <div class="footer-col footer-about">
      <div class="brand footer-brand">
        <img src="<?= uploadUrl($profile['logo'] ?? null, 'assets/images/logo-smk-infokom.png') ?>" alt="Logo" class="brand-logo">
        <span class="brand-text">SMK INFOKOM<br><small>BOGOR</small></span>
      </div>
      <p><?= e($profile['short_description'] ?? '') ?></p>
    </div>

    <div class="footer-col">
      <h4>Navigasi</h4>
      <ul>
        <li><a href="<?= BASE_URL ?>index.php">Beranda</a></li>
        <li><a href="<?= BASE_URL ?>profil.php">Profil</a></li>
        <li><a href="<?= BASE_URL ?>akademik.php">Akademik</a></li>
        <li><a href="<?= BASE_URL ?>berita.php">Informasi</a></li>
      </ul>
    </div>

    <div class="footer-col">
      <h4>Layanan</h4>
      <ul>
        <li><a href="<?= BASE_URL ?>galeri.php">Galeri</a></li>
        <li><a href="<?= BASE_URL ?>ppdb.php">PPDB Online</a></li>
        <li><a href="<?= BASE_URL ?>cek-status.php">Cek Status PPDB</a></li>
        <li><a href="<?= BASE_URL ?>kontak.php">Kontak</a></li>
      </ul>
    </div>

    <div class="footer-col">
      <h4>Kontak</h4>
      <ul class="footer-contact">
        <li><i class="fa-solid fa-location-dot"></i> <?= e($profile['address'] ?? '[ALAMAT SEKOLAH]') ?></li>
        <li><i class="fa-solid fa-phone"></i> <?= e($profile['phone'] ?? '[NOMOR TELEPON]') ?></li>
        <li><i class="fa-solid fa-envelope"></i> <?= e($profile['email'] ?? '[EMAIL SEKOLAH]') ?></li>
      </ul>
    </div>

    <div class="footer-col">
      <h4>Sosial Media</h4>
      <div class="footer-social">
        <?php foreach (getDB()->query('SELECT * FROM social_media ORDER BY sort_order') as $sm): ?>
          <a href="<?= e($sm['url']) ?>" target="_blank" rel="noopener" aria-label="<?= e($sm['platform']) ?>"><i class="<?= e($sm['icon']) ?>"></i></a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <div class="footer-bottom">
    <div class="container">
      &copy; <?= date('Y') ?> SMK INFOKOM BOGOR. Seluruh hak cipta dilindungi.
    </div>
  </div>
</footer>

<script src="<?= BASE_URL ?>assets/js/script.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/script.js') ?>"></script>
<script src="<?= BASE_URL ?>assets/js/toast.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/toast.js') ?>"></script>
<script>if(!window.siteJsReady){document.documentElement.classList.remove('js');}</script>
</body>
</html>

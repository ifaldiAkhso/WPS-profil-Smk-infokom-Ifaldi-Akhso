<?php
// Variabel opsional yang bisa di-set sebelum include ini: $pageTitle, $pageDescription
$profile = schoolProfile();
$siteTitle = $pageTitle ?? 'SMK INFOKOM BOGOR';
$siteDesc = $pageDescription ?? ($profile['short_description'] ?? 'Website resmi SMK INFOKOM BOGOR');
?><!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<script>document.documentElement.classList.add('js');</script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<title><?= e($siteTitle) ?> | SMK INFOKOM BOGOR</title>
<meta name="description" content="<?= e($siteDesc) ?>">
<meta name="keywords" content="SMK Infokom Bogor, SMK Bogor, sekolah kejuruan bogor, PPDB SMK Infokom">
<meta property="og:title" content="<?= e($siteTitle) ?> | SMK INFOKOM BOGOR">
<meta property="og:description" content="<?= e($siteDesc) ?>">
<meta property="og:type" content="website">
<link rel="icon" type="image/png" href="<?= BASE_URL ?>assets/images/logo-smk-infokom.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700;12..96,800&family=Figtree:wght@400;500;600;700&family=Sora:wght@500;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/frontend.css?v=<?= (int)@filemtime(__DIR__ . '/../assets/css/frontend.css') ?>">
</head>
<body class="<?= isset($bodyClass) ? e($bodyClass) : '' ?>">
<?php $flash = getFlash(); ?>
<?php if ($flash): ?>
<div class="toast toast-<?= e($flash['type']) ?>" id="flashToast"><?= e($flash['message']) ?></div>
<?php endif; ?>


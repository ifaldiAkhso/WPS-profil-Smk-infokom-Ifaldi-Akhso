<?php
// Membutuhkan variabel $activeProfile berisi nama file aktif
$profileMenu = [
    'sejarah.php'    => ['label' => 'Sejarah Sekolah',         'icon' => 'fa-clock-rotate-left'],
    'visi-misi.php'  => ['label' => 'Visi & Misi',             'icon' => 'fa-bullseye'],
    'sambutan.php'   => ['label' => 'Sambutan Kepala Sekolah', 'icon' => 'fa-comment-dots'],
    'struktur.php'   => ['label' => 'Struktur Organisasi',     'icon' => 'fa-sitemap'],
    'fasilitas.php'  => ['label' => 'Fasilitas Sekolah',       'icon' => 'fa-building'],
];
?>
<aside class="profile-sidebar reveal">
  <div class="profile-sidebar-head"><i class="fa-solid fa-folder-open"></i> Menu Profil</div>
  <nav>
    <?php foreach ($profileMenu as $file => $item): ?>
      <a href="<?= BASE_URL . $file ?>" class="<?= $activeProfile === $file ? 'active' : '' ?>">
        <i class="fa-solid <?= e($item['icon']) ?>"></i> <?= e($item['label']) ?>
      </a>
    <?php endforeach; ?>
  </nav>
</aside>

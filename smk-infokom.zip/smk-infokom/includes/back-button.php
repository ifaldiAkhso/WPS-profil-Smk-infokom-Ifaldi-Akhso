<?php /* Tombol kembali seragam. Set $backHref dan $backLabel sebelum include. */ ?>
<div class="back-wrap"><a href="<?= e($backHref ?? (BASE_URL . 'index.php')) ?>" class="btn btn-outline-navy profile-back"><i class="fa-solid fa-arrow-left"></i> <?= e($backLabel ?? 'Kembali') ?></a></div>

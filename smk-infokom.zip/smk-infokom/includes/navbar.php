<?php
$currentPage = basename($_SERVER['SCRIPT_NAME']);
$navItems = [
    'index.php' => ['label' => 'Beranda', 'link' => 'index.php', 'icon' => 'fa-house'],
    'profil.php' => [
        'label' => 'Profil',
        'link' => 'profil.php',
        'icon' => 'fa-building-columns',
        'children' => [
            'sejarah.php'    => ['label' => 'Sejarah Sekolah',         'icon' => 'fa-clock-rotate-left'],
            'visi-misi.php'  => ['label' => 'Visi & Misi',             'icon' => 'fa-bullseye'],
            'sambutan.php'   => ['label' => 'Sambutan Kepala Sekolah', 'icon' => 'fa-user-tie'],
            'struktur.php'   => ['label' => 'Struktur Organisasi',     'icon' => 'fa-sitemap'],
            'fasilitas.php'  => ['label' => 'Fasilitas Sekolah',       'icon' => 'fa-school'],
        ],
    ],
    /* Akademik: HANYA 4 menu ini (permintaan final) — jangan tambah item lain di sini. */
    'akademik.php' => [
        'label' => 'Akademik',
        'link' => 'akademik.php',
        'icon' => 'fa-graduation-cap',
        'children' => [
            'akademik.php#program-keahlian' => ['label' => 'Program Keahlian',    'icon' => 'fa-layer-group'],
            'akademik.php#info-kurikulum'   => ['label' => 'Kurikulum',           'icon' => 'fa-book-open'],
            'akademik.php#info-kalender'    => ['label' => 'Kalender Pendidikan', 'icon' => 'fa-calendar-check'],
            'kesiswaan.php'                 => ['label' => 'Kesiswaan',           'icon' => 'fa-people-group'],
        ],
    ],
    /* Informasi: Berita, PKL, BKK, Magang, dan Galeri (Galeri dipindah ke sini, tidak lagi menu sendiri). */
    'informasi' => [
        'label' => 'Informasi',
        'link' => 'berita.php',
        'icon' => 'fa-circle-info',
        'children' => [
            'berita.php'         => ['label' => 'Berita', 'icon' => 'fa-newspaper'],
            'kunjungan-industri.php' => ['label' => 'Kunjungan Industri', 'icon' => 'fa-industry'],
            'pkl.php'            => ['label' => 'PKL',    'icon' => 'fa-briefcase'],
            'bkk.php'            => ['label' => 'BKK',    'icon' => 'fa-handshake'],
            'program-jepang.php' => ['label' => 'Magang', 'icon' => 'fa-plane-departure'],
            'galeri.php'         => ['label' => 'Galeri', 'icon' => 'fa-images'],
        ],
    ],
    'guru-staff.php' => ['label' => 'Guru & Staff', 'link' => 'guru-staff.php', 'icon' => 'fa-chalkboard-user'],
    'ppdb.php' => ['label' => 'PPDB', 'link' => 'ppdb.php', 'icon' => 'fa-clipboard-list'],
    'kontak.php' => ['label' => 'Kontak', 'link' => 'kontak.php', 'icon' => 'fa-phone'],
];
$profilSub    = ['sejarah.php','visi-misi.php','sambutan.php','struktur.php','fasilitas.php'];
$ppdbSub      = ['cek-status.php','ppdb-sukses.php','ppdb-daftar.php'];
$akademikSub  = ['kesiswaan.php','kesiswaan-ekstrakurikuler.php','kesiswaan-tata-tertib.php'];
$informasiSub = ['detail-berita.php','pkl.php','bkk.php','bkk-lowongan.php','bkk-lowongan-detail.php','bkk-perusahaan.php','bkk-perusahaan-detail.php',
    'program-jepang.php','jepang-persyaratan.php','galeri.php','pengumuman.php','agenda.php','prestasi.php','kunjungan-industri.php','kunjungan-industri-detail.php'];
if (in_array($currentPage, $profilSub, true)) $currentPage = 'profil.php';
if (in_array($currentPage, $ppdbSub, true)) $currentPage = 'ppdb.php';
if (in_array($currentPage, $akademikSub, true)) $currentPage = 'akademik.php';
if ($currentPage === 'berita.php' || in_array($currentPage, $informasiSub, true)) $currentPage = 'informasi';
?>
<header class="site-header" id="siteHeader">
  <div class="container nav-wrap">
    <a href="<?= BASE_URL ?>index.php" class="brand">
      <img src="<?= uploadUrl($profile['logo'] ?? null, 'assets/images/logo-smk-infokom.png') ?>" alt="Logo SMK INFOKOM BOGOR" class="brand-logo">
      <span class="brand-text">SMK INFOKOM<br><small>BOGOR</small></span>
    </a>

    <nav class="main-nav" id="mainNav">
      <ul>
        <?php foreach ($navItems as $key => $item): ?>
          <?php $hasChildren = !empty($item['children']); ?>
          <li class="<?= $hasChildren ? 'has-dropdown' : '' ?>">
            <a href="<?= BASE_URL . $item['link'] ?>" class="<?= $currentPage === $key ? 'active' : '' ?>">
              <?php if (!empty($item['icon'])): ?><i class="fa-solid <?= e($item['icon']) ?> nav-ico"></i><?php endif; ?>
              <?= e($item['label']) ?>
              <?php if ($hasChildren): ?><i class="fa-solid fa-chevron-down nav-caret"></i><?php endif; ?>
            </a>
            <?php if ($hasChildren): ?>
              <ul class="dropdown-nav">
                <?php foreach ($item['children'] as $childLink => $child): ?>
                  <li><a href="<?= BASE_URL . $childLink ?>"><?php if (!empty($child['icon'])): ?><i class="fa-solid <?= e($child['icon']) ?>"></i><?php endif; ?> <?= e($child['label']) ?></a></li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    </nav>

    <div class="nav-actions">
      <button class="hamburger" id="hamburgerBtn" aria-label="Buka menu" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
</header>

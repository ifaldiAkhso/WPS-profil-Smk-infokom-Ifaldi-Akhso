<?php
$profileMenu = [
    'sejarah.php'   => ['label' => 'Sejarah Sekolah',        'icon' => 'fa-clock-rotate-left'],
    'visi-misi.php' => ['label' => 'Visi & Misi',            'icon' => 'fa-eye'],
    'sambutan.php'  => ['label' => 'Sambutan Kepala Sekolah','icon' => 'fa-user-tie'],
    'struktur.php'  => ['label' => 'Struktur Organisasi',    'icon' => 'fa-sitemap'],
    'fasilitas.php' => ['label' => 'Fasilitas Sekolah',      'icon' => 'fa-building-columns'],
];
?>
<div class="profile-tabs-wrap">
  <nav class="profile-tabs" aria-label="Navigasi Profil Sekolah">
    <?php foreach ($profileMenu as $file => $item): ?>
      <a href="<?= BASE_URL . $file ?>" class="<?= ($activeProfile ?? '') === $file ? 'active' : '' ?>">
        <i class="fa-solid <?= e($item['icon']) ?>"></i>
        <span><?= e($item['label']) ?></span>
      </a>
    <?php endforeach; ?>
  </nav>
</div>

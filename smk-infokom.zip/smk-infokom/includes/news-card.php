<?php
/* Kartu berita seragam (Beranda & halaman Berita). Butuh variabel $n (baris berita + category_name). */
$ncThumb  = uploadUrl($n['thumbnail'] ?? null, 'assets/images/news-placeholder.jpg');
$ncUrl    = BASE_URL . 'detail-berita.php?slug=' . urlencode($n['slug']);
$ncSrc    = safeUrl($n['source_url'] ?? '');
$ncExc    = trim((string)newsExcerpt($n, 170));
$ncExcKey = mb_strtolower(rtrim($ncExc, '.… '));
$ncHost   = $ncSrc !== '' ? preg_replace('~^www\.~i', '', (string)parse_url($ncSrc, PHP_URL_HOST)) : '';
?>
<article class="nc reveal">
  <a class="nc-media" href="<?= e($ncUrl) ?>" tabindex="-1" aria-hidden="true">
    <img src="<?= $ncThumb ?>" alt="" loading="lazy">
  </a>
  <div class="nc-body">
    <span class="nc-chip"><?= e($n['category_name'] ?? 'Umum') ?></span>
    <h3><a class="nc-title" href="<?= e($ncUrl) ?>"><?= e($n['title']) ?></a></h3>
    <div class="nc-meta"><span><i class="fa-regular fa-calendar"></i> <?= tanggalIndo($n['published_at']) ?></span><span class="nc-dot">&bull;</span><span>Administrator</span></div>
    <?php if ($ncExc !== '' && $ncExcKey !== mb_strtolower(trim((string)$n['title']))): ?><p class="nc-excerpt"><?= e($ncExc) ?></p><?php endif; ?>
    <?php if ($ncSrc !== ''): ?><a href="<?= e($ncSrc) ?>" target="_blank" rel="noopener noreferrer" class="nc-source"><i class="fa-solid fa-link"></i> <?= e($ncHost !== '' ? $ncHost : 'Sumber') ?></a><?php endif; ?>
  </div>
</article>

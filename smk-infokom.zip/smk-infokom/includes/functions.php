<?php
/**
 * Kumpulan fungsi helper untuk website publik & admin
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

/** Sanitasi output agar aman dari XSS */
function e(?string $string): string
{
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/** Buat slug dari string */
function slugify(string $text): string
{
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = trim($text, '-');
    $text = iconv('utf-8', 'ascii//TRANSLIT', $text) ?: $text;
    $text = strtolower($text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    return $text ?: 'item-' . time();
}

/** Format tanggal Indonesia */
function tanggalIndo(?string $date, bool $withTime = false): string
{
    if (!$date) return '-';
    $bulan = ['', 'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    $ts = strtotime($date);
    $result = date('j', $ts) . ' ' . $bulan[(int)date('n', $ts)] . ' ' . date('Y', $ts);
    if ($withTime) {
        $result .= ', ' . date('H:i', $ts) . ' WIB';
    }
    return $result;
}

/** Redirect helper */
function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

/** Ambil satu baris profil sekolah (di-cache dalam request) */
function schoolProfile(): array
{
    static $profile = null;
    if ($profile === null) {
        $pdo = getDB();
        ensureHistoryImageColumn($pdo);
        $stmt = $pdo->query('SELECT * FROM school_profile ORDER BY id LIMIT 1');
        $profile = $stmt->fetch() ?: [];
    }
    return $profile;
}

/** Ambil statistik sekolah */
function schoolStatistics(): array
{
    return getDB()->query('SELECT * FROM school_statistics ORDER BY sort_order ASC, id ASC')->fetchAll();
}

/** Ambil semua program keahlian aktif */
function activePrograms(): array
{
    return getDB()->query("SELECT * FROM programs WHERE is_active = 1 ORDER BY sort_order ASC")->fetchAll();
}

/** Generate nomor pendaftaran PPDB unik: PPDB-YYYY-XXXXX */
function generateRegistrationNumber(PDO $pdo): string
{
    $year = date('Y');
    do {
        $number = 'PPDB-' . $year . '-' . str_pad((string)random_int(1, 99999), 5, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM ppdb_registrations WHERE registration_number = ?');
        $stmt->execute([$number]);
    } while ($stmt->fetchColumn() > 0);
    return $number;
}

/** CSRF Token */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrfField(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrfToken()) . '">';
}

function verifyCsrf(): bool
{
    $token = $_POST['csrf_token'] ?? '';
    return !empty($token) && hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

/** Pesan error upload yang mudah dipahami (bukan sekadar kode angka) */
function uploadErrorMessage(int $code): string
{
    switch ($code) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return 'Ukuran file melebihi batas server. Kecilkan ukuran foto (disarankan di bawah 10MB) atau naikkan upload_max_filesize di php.ini, lalu coba lagi.';
        case UPLOAD_ERR_PARTIAL:
            return 'File hanya terunggah sebagian. Silakan coba lagi.';
        case UPLOAD_ERR_NO_TMP_DIR:
            return 'Folder sementara upload di server tidak ditemukan (periksa upload_tmp_dir di php.ini).';
        case UPLOAD_ERR_CANT_WRITE:
            return 'Server gagal menulis file ke disk. Periksa izin folder.';
        case UPLOAD_ERR_EXTENSION:
            return 'Upload dihentikan oleh ekstensi PHP di server.';
        default:
            return 'Upload gagal (kode error: ' . $code . ').';
    }
}

/** Deteksi MIME gambar; tetap berfungsi walau ekstensi fileinfo PHP tidak aktif */
function detectImageMime(string $path): ?string
{
    if (function_exists('finfo_open')) {
        $f = finfo_open(FILEINFO_MIME_TYPE);
        if ($f) {
            $mime = finfo_file($f, $path);
            finfo_close($f);
            if ($mime) return $mime;
        }
    }
    if (function_exists('mime_content_type')) {
        $mime = mime_content_type($path);
        if ($mime) return $mime;
    }
    $info = @getimagesize($path);
    return $info['mime'] ?? null;
}

/**
 * Perkecil & kompres gambar (GD). Batas unggah 10 MB (UPLOAD_MAX_SIZE); hasil simpan diusahakan <= 400 KB (UPLOAD_TARGET_SIZE).
 * Cara: sisi terpanjang dibatasi $maxSide, lalu kualitas diturunkan bertahap (JPEG/WebP) dan, bila masih besar
 * (mis. PNG), dimensi diperkecil bertahap sampai ukuran file <= target. Gagal = biarkan file asli.
 */
function optimizeUploadedImage(string $path, string $mime, int $maxSide = 1600): void
{
    if (!function_exists('imagecreatetruecolor')) return;
    $target = defined('UPLOAD_TARGET_SIZE') ? (int)UPLOAD_TARGET_SIZE : 400 * 1024;
    try {
        $info = @getimagesize($path);
        if (!$info) return;
        [$w, $h] = $info;
        if ($w <= 0 || $h <= 0) return;
        $loaders = ['image/jpeg' => 'imagecreatefromjpeg', 'image/png' => 'imagecreatefrompng', 'image/webp' => 'imagecreatefromwebp'];
        $fn = $loaders[$mime] ?? null;
        if (!$fn || !function_exists($fn)) return;
        $needResize = max($w, $h) > $maxSide;
        if (!$needResize && filesize($path) <= $target) return;   // sudah cukup kecil
        $src = @$fn($path);
        if (!$src) return;
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $exif = @exif_read_data($path);
            $orient = $exif['Orientation'] ?? 1;
            $angle = [3 => 180, 6 => -90, 8 => 90][$orient] ?? 0;
            if ($angle) { $rot = imagerotate($src, $angle, 0); if ($rot) { imagedestroy($src); $src = $rot; } }
        }
        $w = imagesx($src); $h = imagesy($src);

        $tmp = $path . '.opt';
        $best = null;                                   // hasil terkecil yang pernah dibuat
        $side = min($maxSide, max($w, $h));
        for ($round = 0; $round < 8; $round++) {
            $ratio = max($w, $h) > $side ? $side / max($w, $h) : 1;
            $nw = max(1, (int)round($w * $ratio));
            $nh = max(1, (int)round($h * $ratio));
            $dst = imagecreatetruecolor($nw, $nh);
            if ($mime !== 'image/jpeg') {
                imagealphablending($dst, false);
                imagesavealpha($dst, true);
                imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127));
            }
            imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
            // PNG: kompresi lossless, ukuran hanya turun dengan memperkecil dimensi; JPEG/WebP: turunkan kualitas dulu
            $qualities = $mime === 'image/png' ? [9] : [80, 70, 60, 50];
            foreach ($qualities as $q) {
                $ok = false;
                if ($mime === 'image/jpeg') $ok = imagejpeg($dst, $tmp, $q);
                elseif ($mime === 'image/png') $ok = imagepng($dst, $tmp, $q);
                elseif (function_exists('imagewebp')) $ok = imagewebp($dst, $tmp, $q);
                if (!$ok || !is_file($tmp)) break;
                clearstatcache(true, $tmp);
                $size = filesize($tmp);
                if ($best === null || $size < $best) { $best = $size; @copy($tmp, $path . '.best'); }
                if ($size <= $target) break 2;
            }
            imagedestroy($dst);
            $side = (int)floor($side * 0.82);            // coba lagi dengan dimensi lebih kecil
            if ($side < 480) break;
        }
        if (isset($dst) && $dst) @imagedestroy($dst);
        imagedestroy($src);
        @unlink($tmp);
        if (is_file($path . '.best') && filesize($path . '.best') > 0 && filesize($path . '.best') < filesize($path)) {
            @rename($path . '.best', $path);
        } else {
            @unlink($path . '.best');
        }
    } catch (Throwable $e) {
        error_log('[optimizeUploadedImage] ' . $e->getMessage());
    }
}

/** Validasi + simpan satu file upload ($file = elemen $_FILES). Return ['ok'=>bool,'file'=>path|null,'message'=>...] */
function storeUploadedImage(array $file, string $subFolder): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return ['ok' => true, 'file' => null];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'message' => uploadErrorMessage((int)$file['error'])];
    }
    if ($file['size'] > UPLOAD_MAX_SIZE) {
        return ['ok' => false, 'message' => 'Ukuran file maksimal ' . (int)(UPLOAD_MAX_SIZE / 1048576) . 'MB.'];
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, UPLOAD_ALLOWED_EXT, true)) {
        return ['ok' => false, 'message' => 'Ekstensi file tidak diizinkan. Gunakan JPG/PNG/WEBP (foto HEIC dari iPhone harap diubah ke JPG dulu).'];
    }
    $mime = detectImageMime($file['tmp_name']);
    $allowedMime = ['image/jpeg', 'image/png', 'image/webp'];
    if (!in_array($mime, $allowedMime, true)) {
        return ['ok' => false, 'message' => 'File bukan gambar yang valid.'];
    }
    // Ekstensi disamakan dengan isi file sebenarnya
    $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime];
    $newName = bin2hex(random_bytes(12)) . '.' . $ext;
    $destDir = BASE_PATH . '/assets/uploads/' . $subFolder . '/';
    if (!is_dir($destDir) && !@mkdir($destDir, 0755, true) && !is_dir($destDir)) {
        return ['ok' => false, 'message' => 'Folder upload assets/uploads/' . $subFolder . ' tidak dapat dibuat. Periksa izin folder (chmod 755/775).'];
    }
    if (!is_writable($destDir)) {
        return ['ok' => false, 'message' => 'Folder assets/uploads/' . $subFolder . ' tidak dapat ditulis oleh server. Periksa izin folder (chmod 755/775).'];
    }
    if (!move_uploaded_file($file['tmp_name'], $destDir . $newName)) {
        return ['ok' => false, 'message' => 'Gagal menyimpan file ke server.'];
    }
    // File hasil upload di beberapa hosting berizin 0600 (hanya PHP yang bisa baca) sehingga browser menerima 403
    // dan gambar tampil rusak (hanya teks alt). Pastikan file bisa dibaca web server.
    @chmod($destDir . $newName, 0644);
    optimizeUploadedImage($destDir . $newName, $mime);
    @chmod($destDir . $newName, 0644);
    return ['ok' => true, 'file' => $subFolder . '/' . $newName];
}

/** Upload gambar dengan validasi ketat. Return ['ok'=>bool, 'file'=>path relatif|null, 'message'=>...] */
function handleImageUpload(string $inputName, string $subFolder): ?array
{
    if (empty($_FILES[$inputName]) || is_array($_FILES[$inputName]['error'])) {
        return ['ok' => true, 'file' => null];
    }
    return storeUploadedImage($_FILES[$inputName], $subFolder);
}

/** Hapus file upload lama (aman: hanya di dalam assets/uploads, path ".." ditolak). */
function deleteUploadedFile(?string $relPath): void
{
    $relPath = trim((string)$relPath);
    if ($relPath === '' || str_contains($relPath, '..')) return;
    $abs = BASE_PATH . '/assets/uploads/' . ltrim($relPath, '/');
    if (is_file($abs)) @unlink($abs);
}

/** Upload BANYAK gambar sekaligus (input name="xxx[]" multiple). Return ['files'=>[...], 'errors'=>[...]] */
function handleMultiImageUpload(string $inputName, string $subFolder): array
{
    $result = ['files' => [], 'errors' => []];
    if (empty($_FILES[$inputName]) || !is_array($_FILES[$inputName]['error'])) {
        return $result;
    }
    $f = $_FILES[$inputName];
    foreach ($f['error'] as $i => $err) {
        if ($err === UPLOAD_ERR_NO_FILE) continue;
        $one = storeUploadedImage([
            'name' => $f['name'][$i], 'type' => $f['type'][$i], 'tmp_name' => $f['tmp_name'][$i],
            'error' => $err, 'size' => $f['size'][$i],
        ], $subFolder);
        if ($one['ok'] && !empty($one['file'])) $result['files'][] = $one['file'];
        elseif (!$one['ok']) $result['errors'][] = $f['name'][$i] . ': ' . $one['message'];
    }
    return $result;
}

/**
 * URL publik file upload.
 * - Path di database selalu RELATIF (mis. "berita/abc.jpg"), jadi aman dipindah ke server/folder lain.
 * - Ditambah ?v=<waktu ubah file> agar browser/CDN tidak memakai cache lama saat file diganti atau dipindah.
 * - Bila file gambarnya tidak ada di disk (mis. folder assets/uploads belum ikut disalin), tampilkan placeholder, bukan gambar rusak.
 */
function uploadUrl(?string $path, string $placeholder = 'assets/images/placeholder.png'): string
{
    if (!$path) return BASE_URL . $placeholder;
    $rel = 'assets/uploads/' . ltrim($path, '/');
    $abs = BASE_PATH . '/' . $rel;
    if (is_file($abs)) {
        // Perbaiki otomatis file lama yang izinnya terlalu ketat (tidak bisa dibaca web server)
        if (!(@fileperms($abs) & 0004)) @chmod($abs, 0644);
        return BASE_URL . $rel . '?v=' . (int)@filemtime($abs);
    }
    $isImage = in_array(strtolower(pathinfo($path, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'webp', 'gif'], true);
    return BASE_URL . ($isImage ? $placeholder : $rel);
}

/** Apakah berkas unggahan benar-benar ada di server? (nama di database saja tidak cukup) */
function uploadExists(?string $path): bool
{
    return $path !== null && $path !== '' && is_file(BASE_PATH . '/assets/uploads/' . ltrim($path, '/'));
}

/** Rasio lebar/tinggi gambar, dibatasi 7:10 sampai 16:9: gambar mengikuti bentuk aslinya, poster yang sangat tinggi dipotong dari bawah agar kartu tetap rapi. */
function imageRatio(?string $path, string $placeholder = 'assets/images/placeholder.png'): float
{
    $rel = $path ? 'assets/uploads/' . ltrim($path, '/') : $placeholder;
    $abs = __DIR__ . '/../' . $rel;
    $ratio = 0.75;
    if (is_file($abs)) {
        $sz = @getimagesize($abs);
        if ($sz && !empty($sz[0]) && !empty($sz[1])) $ratio = $sz[0] / $sz[1];
    }
    return max(0.7, min(1.7778, $ratio));
}

/** Teks placeholder bawaan seperti "[ISI ... OLEH ADMIN]" dianggap kosong agar tidak tampil di halaman publik. */
function cleanPlaceholder(?string $text): string
{
    $text = trim((string)$text);
    return preg_match('~^\[[^\]]*\]$~u', $text) ? '' : $text;
}

/** Validasi URL sumber/tautan: hanya http/https. Kembalikan '' bila tidak valid. */
function safeUrl(?string $url): string
{
    $url = trim((string)$url);
    if ($url === '') return '';
    if (!preg_match('~^[a-z][a-z0-9+.-]*://~i', $url)) $url = 'https://' . $url;   // "detik.com/x" -> https://detik.com/x
    if (!preg_match('~^https?://~i', $url) || filter_var($url, FILTER_VALIDATE_URL) === false) return '';
    return $url;
}

/** Nama domain ringkas dari URL (tanpa www.) untuk label tautan */
function urlHost(?string $url): string
{
    $host = parse_url((string)$url, PHP_URL_HOST) ?: '';
    return preg_replace('~^www\.~i', '', $host);
}

/** Rapikan isi berita: buang tag/atribut berbahaya (script, onclick, javascript:), pertahankan format dasar. */
function sanitizeRichText(string $html): string
{
    $allowed = '<p><br><b><strong><i><em><u><ul><ol><li><a><h2><h3><h4><blockquote><img><span><div><table><thead><tbody><tr><th><td>';
    $html = strip_tags($html, $allowed);
    $html = preg_replace('~\son[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)~i', '', $html);
    $html = preg_replace('~\s(href|src)\s*=\s*(["\'])\s*(javascript|data|vbscript):[^"\']*\2~i', ' $1="#"', $html);
    $html = preg_replace('~\sstyle\s*=\s*("[^"]*"|\'[^\']*\')~i', '', $html);
    return $html;
}

/** Ubah teks berita menjadi HTML rapi: URL biasa otomatis jadi tautan yang bisa diklik, baris baru jadi paragraf. */
function formatNewsContent(?string $content): string
{
    $content = trim((string)$content);
    if ($content === '') return '';
    $hasHtml = $content !== strip_tags($content);
    if ($hasHtml) {
        $html = sanitizeRichText($content);
        // HTML tanpa tag blok (p/br/ul/div/h2-4): baris baru tetap dijadikan paragraf agar tidak menyatu
        if (!preg_match('~<(p|br|ul|ol|div|h[2-4]|blockquote|table)\b~i', $html)) {
            $html = '<p>' . preg_replace('~\R{2,}~', '</p><p>', trim($html)) . '</p>';
            $html = preg_replace('~\R~', '<br>', $html);
        }
    } else {
        $html = '<p>' . nl2br(e($content)) . '</p>';
        $html = preg_replace('~(<br\s*/?>\s*(\r?\n)?\s*){2,}~i', '</p><p>', $html);
    }
    // autolink: hanya URL yang berada di luar tag/atribut (di antara > ... <)
    $html = preg_replace_callback('~(<a\b[^>]*>.*?</a>)|(<[^>]+>)|(https?://[^\s<>"\']+)~is', function ($m) {
        if (!empty($m[1]) || !empty($m[2])) return $m[0];
        $url = rtrim($m[3], '.,;:!?)');
        $tail = substr($m[3], strlen($url));
        return '<a href="' . e($url) . '" target="_blank" rel="noopener noreferrer">' . e($url) . '</a>' . $tail;
    }, $html);
    // semua tautan dibuka di tab baru dengan rel aman
    $html = preg_replace_callback('~<a\b([^>]*)>~i', function ($m) {
        $attrs = preg_replace('~\s(target|rel)\s*=\s*("[^"]*"|\'[^\']*\')~i', '', $m[1]);
        return '<a' . $attrs . ' target="_blank" rel="noopener noreferrer">';
    }, $html);
    return $html;
}

/** Ringkasan berita: pakai excerpt bila ada, kalau kosong ambil dari isi berita. */
function newsExcerpt(array $n, int $max = 140): string
{
    $ex = trim((string)($n['excerpt'] ?? ''));
    if ($ex === '') $ex = trim(preg_replace('~\s+~', ' ', strip_tags((string)($n['content'] ?? ''))));
    return cutSentence($ex, $max);
}

/**
 * Judul kunjungan industri bersifat OPSIONAL.
 * Bila kosong, yang dipakai hanya nama perusahaan; bila itu juga kosong, tidak ada judul (tidak ada nama otomatis).
 */
function visitTitle(array $v): string
{
    $title = trim((string)($v['title'] ?? ''));
    if ($title !== '') return $title;
    $company = trim((string)($v['company'] ?? ''));
    return $company;
}

/** Tabel Kunjungan Industri dibuat otomatis bila belum ada. */
function ensureIndustryVisits(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;
    try {
        if ($pdo->query("SHOW TABLES LIKE 'industry_visits'")->fetchColumn() === false) {
            $pdo->exec("CREATE TABLE industry_visits (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(200) DEFAULT NULL,
                company VARCHAR(200) DEFAULT NULL,
                location VARCHAR(200) DEFAULT NULL,
                visit_date DATE DEFAULT NULL,
                participants VARCHAR(200) DEFAULT NULL,
                description TEXT,
                image VARCHAR(255) DEFAULT NULL,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        } else {
            // Database lama: judul sebelumnya wajib (NOT NULL). Sekarang opsional.
            $titleCol = $pdo->query("SHOW COLUMNS FROM industry_visits LIKE 'title'")->fetch();
            if ($titleCol && strtoupper((string)$titleCol['Null']) === 'NO') {
                $pdo->exec("ALTER TABLE industry_visits MODIFY title VARCHAR(200) DEFAULT NULL");
            }
        }
        return $ready = true;
    } catch (Throwable $e) {
        error_log('[industry_visits] ' . $e->getMessage());
        return $ready = false;
    }
}

/** Potong teks di akhir kalimat/kata terdekat — tanpa tanda "..." sehingga teks selalu terbaca utuh */
function cutSentence(string $text, int $max): string
{
    $text = trim((string)preg_replace('~\s+~u', ' ', $text));
    if (mb_strlen($text) <= $max) return $text;
    $part = mb_substr($text, 0, $max);
    if (preg_match('~^(.*[.!?])\s~us', $part . ' ', $m) && mb_strlen($m[1]) >= $max * 0.4) return $m[1];
    $sp = mb_strrpos($part, ' ');
    return $sp !== false ? rtrim(mb_substr($part, 0, $sp), ',;: ') : $part;
}

/** Potong teks + "…" bila terpotong */
function mb_or_cut(string $text, int $max): string
{
    $text = trim($text);
    $cut = safeCut($text, $max);
    return $cut === $text ? $text : rtrim($cut) . '…';
}

/** Pastikan kolom tautan sumber tersedia di tabel news (migrasi otomatis untuk instalasi lama). */
function ensureNewsColumns(PDO $pdo): void
{
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        $has = fn(string $c) => $pdo->query("SHOW COLUMNS FROM news LIKE '$c'")->fetch();
        if (!$has('source_url'))  $pdo->exec("ALTER TABLE news ADD COLUMN source_url VARCHAR(500) DEFAULT NULL AFTER content");
        if (!$has('source_name')) $pdo->exec("ALTER TABLE news ADD COLUMN source_name VARCHAR(150) DEFAULT NULL AFTER source_url");
    } catch (Throwable $e) {
        error_log('[news_columns] ' . $e->getMessage());
    }
}

/** Pastikan kolom tautan sumber tersedia di tabel achievements (migrasi otomatis untuk instalasi lama). */
function ensureAchievementColumns(PDO $pdo): void
{
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        $has = fn(string $c) => $pdo->query("SHOW COLUMNS FROM achievements LIKE '$c'")->fetch();
        if (!$has('source_url'))  $pdo->exec("ALTER TABLE achievements ADD COLUMN source_url VARCHAR(500) DEFAULT NULL AFTER description");
        if (!$has('source_name')) $pdo->exec("ALTER TABLE achievements ADD COLUMN source_name VARCHAR(150) DEFAULT NULL AFTER source_url");
    } catch (Throwable $e) {
        error_log('[achievement_columns] ' . $e->getMessage());
    }
}

/** ID video YouTube (11 karakter) dari berbagai bentuk link (watch, youtu.be, embed, shorts, live). Kosong bila tidak valid. */
function youtubeId(?string $url): string
{
    $url = trim((string)$url);
    if ($url === '') return '';
    if (preg_match('~^[A-Za-z0-9_-]{11}$~', $url)) return $url;
    if (preg_match('~(?:youtu\.be/|youtube(?:-nocookie)?\.com/(?:watch\?(?:[^#]*&)?v=|embed/|shorts/|live/|v/))([A-Za-z0-9_-]{11})~i', $url, $m)) return $m[1];
    return '';
}

/** Daftar ID video YouTube dari teks (satu link per baris). Maksimal $max video, duplikat dibuang. */
function youtubeIdsFromText(?string $raw, int $max = 6): array
{
    $ids = [];
    foreach (preg_split('~[\r\n,\s]+~', trim((string)$raw)) as $part) {
        $id = youtubeId($part);
        if ($id !== '' && !in_array($id, $ids, true)) $ids[] = $id;
        if (count($ids) >= $max) break;
    }
    return $ids;
}

/** Pecah isi "Tanggal | Kegiatan" per baris jadi tabel [ [kiri, kanan], ... ]. Kosong bila format tidak konsisten. */
function parseTableLines(?string $text): array
{
    $text = trim((string)$text);
    if ($text === '' || strpos($text, '|') === false) return [];
    $rows = [];
    foreach (preg_split('~\R+~', $text) as $line) {
        $line = trim($line);
        if ($line === '') continue;
        $parts = array_map('trim', explode('|', $line, 2));
        if (count($parts) < 2 || $parts[0] === '' || $parts[1] === '') return [];   // format tidak konsisten, gagalkan semua
        $rows[] = $parts;
    }
    return $rows;
}

/** Flash message sederhana via session */
function setFlash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/** Pastikan kolom info_image tersedia di tabel ppdb_settings (migrasi otomatis untuk instalasi lama) */
function ensurePpdbInfoImageColumn(PDO $pdo): void
{
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        $col = $pdo->query("SHOW COLUMNS FROM ppdb_settings LIKE 'info_image'")->fetch();
        if (!$col) {
            $pdo->exec("ALTER TABLE ppdb_settings ADD COLUMN info_image VARCHAR(255) DEFAULT NULL AFTER requirements");
        }
    } catch (Throwable $e) {
        // Diamkan: bila gagal (misal hak akses terbatas), fitur teks tetap berfungsi normal.
    }
}

/** Agenda: tanggal tidak wajib + status "Akan Datang" (migrasi otomatis untuk instalasi lama). */
function ensureAgendaColumns(PDO $pdo): void
{
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        $col = $pdo->query("SHOW COLUMNS FROM agendas LIKE 'event_date'")->fetch();
        if ($col && strtoupper((string)$col['Null']) === 'NO') {
            $pdo->exec("ALTER TABLE agendas MODIFY event_date DATE DEFAULT NULL");
        }
        if (!$pdo->query("SHOW COLUMNS FROM agendas LIKE 'status'")->fetch()) {
            $pdo->exec("ALTER TABLE agendas ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'otomatis'");
        }
    } catch (Throwable $e) {
        error_log('[agendas] ' . $e->getMessage());
    }
}

/** Lokasi lowongan: isian lowongan, bila kosong pakai lokasi Perusahaan Mitra. Hasil query harus memuat alias company_location. */
function jobLocation(array $jv): string
{
    foreach (['location', 'company_location'] as $k) {
        $v = trim((string)($jv[$k] ?? ''));
        if ($v !== '') return $v;
    }
    return '';
}

/** Pengumuman: tambah kolom gambar (migrasi otomatis untuk instalasi lama). */
function ensureAnnouncementImageColumn(PDO $pdo): void
{
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        if (!$pdo->query("SHOW COLUMNS FROM announcements LIKE 'image'")->fetch()) {
            $pdo->exec("ALTER TABLE announcements ADD COLUMN image VARCHAR(255) DEFAULT NULL AFTER content");
        }
    } catch (Throwable $e) {
        error_log('[announcements_image] ' . $e->getMessage());
    }
}

/** Pastikan kolom form_pdf & form_pdf_label tersedia di tabel ppdb_settings (migrasi otomatis untuk instalasi lama) */
function ensurePpdbFormPdfColumn(PDO $pdo): void
{
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        if (!$pdo->query("SHOW COLUMNS FROM ppdb_settings LIKE 'form_pdf'")->fetch()) {
            $pdo->exec("ALTER TABLE ppdb_settings ADD COLUMN form_pdf VARCHAR(255) DEFAULT NULL AFTER info_image");
        }
        if (!$pdo->query("SHOW COLUMNS FROM ppdb_settings LIKE 'form_pdf_label'")->fetch()) {
            $pdo->exec("ALTER TABLE ppdb_settings ADD COLUMN form_pdf_label VARCHAR(150) DEFAULT NULL AFTER form_pdf");
        }
    } catch (Throwable $e) {
        // Diamkan: bila gagal, fitur lain tetap berjalan normal.
    }
}

/** Validasi + simpan satu file PDF. Return ['ok'=>bool,'file'=>path|null,'message'=>...] */
function handlePdfUpload(string $inputName, string $subFolder, int $maxBytes = 10485760): array
{
    if (empty($_FILES[$inputName]) || is_array($_FILES[$inputName]['error'])) {
        return ['ok' => true, 'file' => null];
    }
    $file = $_FILES[$inputName];
    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['ok' => true, 'file' => null];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'message' => uploadErrorMessage((int)$file['error'])];
    }
    if ($file['size'] > $maxBytes) {
        return ['ok' => false, 'message' => 'Ukuran PDF maksimal ' . (int)($maxBytes / 1048576) . 'MB.'];
    }
    if (strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)) !== 'pdf') {
        return ['ok' => false, 'message' => 'File harus berformat PDF.'];
    }
    $mime = detectImageMime($file['tmp_name']);
    $head = @file_get_contents($file['tmp_name'], false, null, 0, 5);
    if ($mime !== 'application/pdf' || $head !== '%PDF-') {
        return ['ok' => false, 'message' => 'File bukan PDF yang valid.'];
    }
    $destDir = BASE_PATH . '/assets/uploads/' . $subFolder . '/';
    if (!is_dir($destDir) && !@mkdir($destDir, 0755, true) && !is_dir($destDir)) {
        return ['ok' => false, 'message' => 'Folder assets/uploads/' . $subFolder . ' tidak dapat dibuat. Periksa izin folder (chmod 755/775).'];
    }
    if (!is_writable($destDir)) {
        return ['ok' => false, 'message' => 'Folder assets/uploads/' . $subFolder . ' tidak dapat ditulis oleh server. Periksa izin folder (chmod 755/775).'];
    }
    $newName = bin2hex(random_bytes(12)) . '.pdf';
    if (!move_uploaded_file($file['tmp_name'], $destDir . $newName)) {
        return ['ok' => false, 'message' => 'Gagal menyimpan file ke server.'];
    }
    return ['ok' => true, 'file' => $subFolder . '/' . $newName];
}

/** Pastikan kolom history_image tersedia di tabel school_profile (migrasi otomatis untuk instalasi lama) */
function ensureHistoryImageColumn(PDO $pdo): void
{
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        $col = $pdo->query("SHOW COLUMNS FROM school_profile LIKE 'history_image'")->fetch();
        if (!$col) {
            $pdo->exec("ALTER TABLE school_profile ADD COLUMN history_image VARCHAR(255) DEFAULT NULL AFTER history");
        }
    } catch (Throwable $e) {
        // Diamkan: bila gagal (misal hak akses terbatas), foto sejarah tetap pakai gambar default.
    }
}

/** Pastikan kolom video "Kabar Sekolah" (link YouTube untuk beranda) tersedia di school_profile. */
function ensureKabarSekolahColumn(PDO $pdo): void
{
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        $col = $pdo->query("SHOW COLUMNS FROM school_profile LIKE 'kabar_video_url'")->fetch();
        if (!$col) {
            $pdo->exec("ALTER TABLE school_profile ADD COLUMN kabar_video_url TEXT DEFAULT NULL AFTER youtube");
        } elseif (stripos((string)($col['Type'] ?? ''), 'varchar') !== false) {
            $pdo->exec("ALTER TABLE school_profile MODIFY kabar_video_url TEXT DEFAULT NULL");
        }
    } catch (Throwable $e) {
        // Diamkan: bila gagal, bagian Kabar Sekolah di beranda otomatis tidak tampil.
    }
}

/** Slug unik untuk tabel tertentu (mencegah error duplikat saat nama sama) */
function uniqueSlug(PDO $pdo, string $table, string $base, int $ignoreId = 0): string
{
    if (!in_array($table, ['programs', 'news'], true)) {
        throw new InvalidArgumentException('Tabel tidak valid untuk slug.');
    }
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM `$table` WHERE slug = ? AND id <> ?");
    $slug = $base;
    $i = 2;
    while (true) {
        $stmt->execute([$slug, $ignoreId]);
        if ((int)$stmt->fetchColumn() === 0) return $slug;
        $slug = $base . '-' . $i++;
    }
}

/** Potong teks tanpa merusak karakter UTF-8 (tetap aman bila mbstring tidak aktif) */
function safeCut(string $text, int $max): string
{
    if (function_exists('mb_substr')) return mb_substr($text, 0, $max);
    return preg_match('/^.{0,' . $max . '}/us', $text, $m) ? $m[0] : substr($text, 0, $max);
}

/** Ubah exception (terutama database) menjadi pesan yang bisa dipahami admin */
function friendlyErrorMessage(Throwable $e): string
{
    if ($e instanceof PDOException) {
        $code = (int)($e->errorInfo[1] ?? 0);
        switch ($code) {
            case 1062: return 'Data gagal disimpan: sudah ada data dengan nilai yang sama (duplikat).';
            case 1406: return 'Data gagal disimpan: ada isian yang terlalu panjang. Persingkat teks lalu coba lagi.';
            case 1264:
            case 1265:
            case 1366: return 'Data gagal disimpan: ada isian dengan format/nilai yang tidak sesuai.';
            case 1451:
            case 1452: return 'Data tidak dapat diproses karena terkait dengan data lain.';
            case 1146: return 'Tabel database belum tersedia. Pastikan file database/database.sql sudah diimpor sepenuhnya.';
            case 1054: return 'Struktur database tidak sesuai dengan kode (kolom tidak ditemukan). Impor ulang database/database.sql.';
        }
        return 'Terjadi kesalahan database: ' . safeCut($e->getMessage(), 180);
    }
    return 'Terjadi kesalahan: ' . safeCut($e->getMessage(), 180);
}

/* ------------------------------------------------------------------
 * Informasi Akademik (kurikulum, kalender, PKL, ekskul, dst.)
 * Tabel dibuat otomatis bila belum ada, jadi database lama tetap jalan
 * tanpa perlu impor ulang.
 * ------------------------------------------------------------------ */
function academicDefaults(): array
{
    return [
        ['kurikulum', 'Kurikulum', 'Sekolah menerapkan Kurikulum Merdeka yang berfokus pada penguatan kompetensi keahlian dan karakter siswa.', 'fa-solid fa-book-open', 1],
        ['kalender', 'Kalender Pendidikan', 'Kalender pendidikan tahun ajaran berjalan belum diisi. Admin dapat memperbaruinya melalui Dashboard Admin > Akademik.', 'fa-solid fa-calendar-check', 2],
        ['pkl', 'Praktik Kerja Lapangan (PKL)', 'Siswa melaksanakan PKL di industri mitra sesuai kompetensi keahlian masing-masing.', 'fa-solid fa-briefcase', 3],
        ['ekstrakurikuler', 'Ekstrakurikuler', 'Daftar ekstrakurikuler belum diisi. Admin dapat memperbaruinya melalui Dashboard Admin > Akademik.', 'fa-solid fa-people-group', 4],
    ];
}

/** Pastikan tabel academic_info ada. Return false jika tidak bisa dibuat (mis. hak akses DB terbatas). */
function ensureAcademicTable(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;
    try {
        $exists = $pdo->query("SHOW TABLES LIKE 'academic_info'")->fetchColumn() !== false;
        if (!$exists) {
            $pdo->exec("CREATE TABLE academic_info (
                id INT AUTO_INCREMENT PRIMARY KEY,
                section_key VARCHAR(60) DEFAULT NULL,
                title VARCHAR(150) NOT NULL,
                content TEXT,
                icon VARCHAR(60) DEFAULT 'fa-solid fa-book-open',
                sort_order INT DEFAULT 0,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $ins = $pdo->prepare("INSERT INTO academic_info (section_key, title, content, icon, sort_order) VALUES (?,?,?,?,?)");
            foreach (academicDefaults() as $row) $ins->execute($row);
        }
        return $ready = true;
    } catch (Throwable $e) {
        error_log('[academic_info] ' . $e->getMessage());
        return $ready = false;
    }
}

/** Ambil bagian informasi akademik. $onlyActive=true untuk halaman publik. */
function academicSections(PDO $pdo, bool $onlyActive = true): array
{
    if (!ensureAcademicTable($pdo)) {
        return array_map(fn($r) => ['id' => 0, 'section_key' => $r[0], 'title' => $r[1], 'content' => $r[2], 'icon' => $r[3], 'sort_order' => $r[4], 'is_active' => 1], academicDefaults());
    }
    $sql = 'SELECT * FROM academic_info' . ($onlyActive ? ' WHERE is_active = 1' : '') . ' ORDER BY sort_order ASC, id ASC';
    return $pdo->query($sql)->fetchAll();
}

/* ------------------------------------------------------------------
 * MODUL KESISWAAN (Ekstrakurikuler, Prestasi Siswa, Tata Tertib). Tabel dibuat otomatis bila belum ada (pola yang sama
 * dengan academic_info) sehingga database lama tetap jalan tanpa
 * perlu impor ulang database/database.sql.
 * ------------------------------------------------------------------ */

/** Pastikan seluruh tabel modul Kesiswaan tersedia. */
function ensureKesiswaanTables(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;
    try {
        $exists = fn(string $t) => $pdo->query("SHOW TABLES LIKE '$t'")->fetchColumn() !== false;

        if (!$exists('extracurriculars')) {
            $pdo->exec("CREATE TABLE extracurriculars (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(150) NOT NULL,
                slug VARCHAR(170) NOT NULL UNIQUE,
                category VARCHAR(80) DEFAULT NULL,
                photo VARCHAR(255) DEFAULT NULL,
                description TEXT,
                schedule VARCHAR(150) DEFAULT NULL,
                supervisor VARCHAR(150) DEFAULT NULL,
                location VARCHAR(150) DEFAULT NULL,
                achievement_note TEXT,
                is_active TINYINT(1) DEFAULT 1,
                sort_order INT DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }

        if (!$exists('student_rules')) {
            $pdo->exec("CREATE TABLE student_rules (
                id INT AUTO_INCREMENT PRIMARY KEY,
                category VARCHAR(80) NOT NULL,
                title VARCHAR(200) NOT NULL,
                content TEXT,
                sort_order INT DEFAULT 0,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }

        return $ready = true;
    } catch (Throwable $e) {
        error_log('[kesiswaan] ' . $e->getMessage());
        return $ready = false;
    }
}

/** Kategori urutan tetap untuk halaman Tata Tertib */
function studentRuleCategories(): array
{
    return ['Pengantar','Hak Siswa','Kewajiban Siswa','Ketentuan Seragam','Ketentuan Kehadiran','Peraturan Umum','Larangan','Jenis Pelanggaran','Sanksi','Ketentuan Tambahan'];
}

/** Daftar ekstrakurikuler aktif (dipakai di beranda kesiswaan & widget lain) */
function activeExtracurriculars(PDO $pdo, int $limit = 0): array
{
    if (!ensureKesiswaanTables($pdo)) return [];
    $sql = "SELECT * FROM extracurriculars WHERE is_active = 1 ORDER BY sort_order ASC, name ASC";
    if ($limit > 0) $sql .= " LIMIT " . (int)$limit;
    return $pdo->query($sql)->fetchAll();
}

/* ------------------------------------------------------------------
 * MODUL BKK (Bursa Kerja Khusus): Profil BKK, Lowongan Kerja,
 * Perusahaan Mitra. Tabel dibuat otomatis bila belum ada (pola yang
 * sama dengan academic_info / modul Kesiswaan) sehingga database lama
 * tetap jalan tanpa perlu impor ulang.
 * ------------------------------------------------------------------ */

/** Pastikan seluruh tabel modul BKK tersedia. */
function ensureBkkTables(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;
    try {
        $exists = fn(string $t) => $pdo->query("SHOW TABLES LIKE '$t'")->fetchColumn() !== false;

        if (!$exists('bkk_settings')) {
            $pdo->exec("CREATE TABLE bkk_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                description TEXT,
                contact_phone VARCHAR(50) DEFAULT NULL,
                contact_email VARCHAR(100) DEFAULT NULL,
                contact_address VARCHAR(255) DEFAULT NULL,
                coordinator_name VARCHAR(150) DEFAULT NULL,
                coordinator_position VARCHAR(150) DEFAULT NULL,
                coordinator_photo VARCHAR(255) DEFAULT NULL,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->exec("INSERT INTO bkk_settings (description) VALUES ('[ISI DESKRIPSI SINGKAT BKK OLEH ADMIN]')");
        }

        if (!$exists('bkk_sections')) {
            $pdo->exec("CREATE TABLE bkk_sections (
                id INT AUTO_INCREMENT PRIMARY KEY,
                section_key VARCHAR(60) DEFAULT NULL,
                title VARCHAR(150) NOT NULL,
                content TEXT,
                icon VARCHAR(60) DEFAULT 'fa-solid fa-briefcase',
                sort_order INT DEFAULT 0,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $ins = $pdo->prepare("INSERT INTO bkk_sections (section_key, title, content, icon, sort_order) VALUES (?,?,?,?,?)");
            foreach (bkkSectionDefaults() as $row) $ins->execute($row);
        }

        if (!$exists('partner_companies')) {
            $pdo->exec("CREATE TABLE partner_companies (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(150) NOT NULL,
                logo VARCHAR(255) DEFAULT NULL,
                field VARCHAR(150) DEFAULT NULL,
                location VARCHAR(150) DEFAULT NULL,
                description TEXT,
                website VARCHAR(255) DEFAULT NULL,
                is_partner TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }

        if (!$exists('job_vacancies')) {
            $pdo->exec("CREATE TABLE job_vacancies (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT DEFAULT NULL,
                company_name VARCHAR(150) DEFAULT NULL,
                image VARCHAR(255) DEFAULT NULL,
                position VARCHAR(150) NOT NULL,
                program_id INT DEFAULT NULL,
                location VARCHAR(150) DEFAULT NULL,
                description TEXT,
                requirements TEXT,
                deadline DATE DEFAULT NULL,
                registration_link VARCHAR(255) DEFAULT NULL,
                status ENUM('aktif','ditutup') DEFAULT 'aktif',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES partner_companies(id) ON DELETE SET NULL,
                FOREIGN KEY (program_id) REFERENCES programs(id) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }
        ensureJobVacancyColumns($pdo);

        return $ready = true;
    } catch (Throwable $e) {
        error_log('[bkk] ' . $e->getMessage());
        return $ready = false;
    }
}

/**
 * Migrasi otomatis tabel lowongan (aman dijalankan berulang):
 *  - company_name : nama perusahaan bebas (tanpa harus terdaftar sebagai Mitra)
 *  - image        : gambar / poster lowongan
 *  - company_id   : boleh kosong (dulu wajib)
 */
function ensureJobVacancyColumns(PDO $pdo): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $has = fn(string $c) => $pdo->query("SHOW COLUMNS FROM job_vacancies LIKE '$c'")->fetch();
        if (!$has('company_name')) $pdo->exec("ALTER TABLE job_vacancies ADD COLUMN company_name VARCHAR(150) DEFAULT NULL AFTER company_id");
        if (!$has('image'))        $pdo->exec("ALTER TABLE job_vacancies ADD COLUMN image VARCHAR(255) DEFAULT NULL AFTER company_name");

        $col = $has('company_id');
        if ($col && strtoupper((string)$col['Null']) === 'NO') {
            $fks = $pdo->query("SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE
                                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'job_vacancies'
                                   AND COLUMN_NAME = 'company_id' AND REFERENCED_TABLE_NAME IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);
            foreach ($fks as $fk) $pdo->exec("ALTER TABLE job_vacancies DROP FOREIGN KEY `" . str_replace('`', '', $fk) . "`");
            $pdo->exec("ALTER TABLE job_vacancies MODIFY company_id INT(11) DEFAULT NULL");
            $pdo->exec("ALTER TABLE job_vacancies ADD CONSTRAINT job_vacancies_company_fk FOREIGN KEY (company_id) REFERENCES partner_companies(id) ON DELETE SET NULL");
        }
    } catch (Throwable $e) {
        error_log('[job_vacancies] ' . $e->getMessage());
    }
}

/** Nama perusahaan yang ditampilkan: nama bebas lebih dulu, lalu nama Mitra. Hasil query harus memuat jv.* dan company_name dari join (alias partner_name). */
function jobCompanyName(array $jv): string
{
    foreach (['company_name_free', 'partner_name', 'company_name'] as $k) {
        $v = trim((string)($jv[$k] ?? ''));
        if ($v !== '') return $v;
    }
    return '';
}

/** Judul lowongan; bila posisi dikosongkan (lowongan berupa poster saja) dipakai teks bawaan ini. */
function jobTitle(array $jv): string
{
    $t = trim((string)($jv['position'] ?? ''));
    return $t !== '' ? $t : 'Lowongan Kerja';
}

/** URL poster lowongan, atau '' bila tidak ada / berkasnya tidak ada / bukan gambar valid. Tidak pernah mengembalikan gambar bawaan. */
function jobPosterUrl(array $jv): string
{
    $p = $jv['image'] ?? null;
    if (!uploadExists($p)) return '';
    if (@getimagesize(BASE_PATH . '/assets/uploads/' . ltrim((string)$p, '/')) === false) return '';
    return uploadUrl($p);
}

/** Ada poster lowongan yang benar-benar bisa ditampilkan? Logo Mitra dan gambar bawaan tidak pernah dipakai. */
function jobHasImage(array $jv): bool
{
    return jobPosterUrl($jv) !== '';
}

/** Gambar lowongan = poster lowongan ('' bila tidak ada; parameter $placeholder tidak dipakai lagi). */
function jobImageUrl(array $jv, string $placeholder = ''): string
{
    return jobPosterUrl($jv);
}

/** Bagian default Profil BKK (dibuat sekali saat tabel bkk_sections pertama kali dibuat) */
function bkkSectionDefaults(): array
{
    return [
        ['tentang', 'Tentang BKK', 'Bursa Kerja Khusus (BKK) SMK INFOKOM BOGOR adalah unit layanan sekolah yang membantu penyaluran lulusan ke dunia kerja. Admin dapat memperbarui isi ini melalui Dashboard Admin > BKK > Profil BKK.', 'fa-solid fa-building-user', 1],
        ['tujuan', 'Tujuan BKK', 'Tujuan BKK belum diisi. Admin dapat memperbaruinya melalui Dashboard Admin > BKK > Profil BKK.', 'fa-solid fa-bullseye', 2],
        ['fungsi', 'Fungsi BKK', 'Fungsi BKK belum diisi. Admin dapat memperbaruinya melalui Dashboard Admin > BKK > Profil BKK.', 'fa-solid fa-gears', 3],
        ['layanan', 'Layanan BKK', 'Layanan BKK belum diisi. Admin dapat memperbaruinya melalui Dashboard Admin > BKK > Profil BKK.', 'fa-solid fa-handshake', 4],
    ];
}

/** Ambil pengaturan BKK (satu baris, dengan cache dalam request) */
function bkkSettings(PDO $pdo): array
{
    static $settings = null;
    if ($settings === null) {
        ensureBkkTables($pdo);
        $settings = $pdo->query('SELECT * FROM bkk_settings ORDER BY id LIMIT 1')->fetch() ?: [];
    }
    return $settings;
}

/** Ambil bagian Profil BKK. $onlyActive=true untuk halaman publik. */
function bkkSections(PDO $pdo, bool $onlyActive = true): array
{
    if (!ensureBkkTables($pdo)) return [];
    $sql = 'SELECT * FROM bkk_sections' . ($onlyActive ? ' WHERE is_active = 1' : '') . ' ORDER BY sort_order ASC, id ASC';
    return $pdo->query($sql)->fetchAll();
}

/** Perusahaan mitra aktif (dipakai untuk dropdown lowongan & tampilan publik) */
function activePartnerCompanies(PDO $pdo): array
{
    if (!ensureBkkTables($pdo)) return [];
    return $pdo->query("SELECT * FROM partner_companies WHERE is_partner = 1 ORDER BY name ASC")->fetchAll();
}

/* ------------------------------------------------------------------
 * MODUL PROGRAM KERJA LUAR NEGERI (fokus Program Kerja ke Jepang).
 * Isi modul: Profil Program, Persyaratan & Tahapan Program, serta
 * Foto Siswa Magang (memakai tabel galeri). Tabel dibuat otomatis bila
 * belum ada sehingga database lama tetap jalan tanpa impor ulang.
 * ------------------------------------------------------------------ */

/** Kategori khusus di menu Persyaratan yang dipakai untuk Tahapan Program */
const JEPANG_TAHAPAN_TAG = 'Tahapan Program';

/** Pastikan tabel modul Program Kerja Jepang tersedia. */
function ensureJepangTables(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;
    try {
        $exists = fn(string $t) => $pdo->query("SHOW TABLES LIKE '$t'")->fetchColumn() !== false;

        if (!$exists('jepang_profile')) {
            $pdo->exec("CREATE TABLE jepang_profile (
                id INT AUTO_INCREMENT PRIMARY KEY,
                about TEXT,
                purpose TEXT,
                target_participants TEXT,
                duration VARCHAR(150) DEFAULT NULL,
                status VARCHAR(255) DEFAULT NULL,
                important_info TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }
        // Kolom tautan sumber informasi (migrasi otomatis untuk instalasi lama)
        $hasCol = fn(string $c) => $pdo->query("SHOW COLUMNS FROM jepang_profile LIKE '$c'")->fetch();
        if (!$hasCol('source_url'))  $pdo->exec("ALTER TABLE jepang_profile ADD COLUMN source_url VARCHAR(500) DEFAULT NULL AFTER important_info");
        if (!$hasCol('source_name')) $pdo->exec("ALTER TABLE jepang_profile ADD COLUMN source_name VARCHAR(150) DEFAULT NULL AFTER source_url");
        // Link video YouTube dokumentasi magang (satu link per baris)
        if (!$hasCol('video_url'))   $pdo->exec("ALTER TABLE jepang_profile ADD COLUMN video_url TEXT DEFAULT NULL AFTER source_name");
        // Status Program sebelumnya VARCHAR(100) sehingga teks panjang terpotong (mis. "...yang sedang berlaku di"). Dilebarkan menjadi 255.
        $statusCol = $pdo->query("SHOW COLUMNS FROM jepang_profile LIKE 'status'")->fetch();
        if ($statusCol && stripos((string)($statusCol['Type'] ?? ''), 'varchar(100)') !== false) {
            $pdo->exec("ALTER TABLE jepang_profile MODIFY COLUMN status VARCHAR(255) DEFAULT NULL");
        }
        // Rapikan teks bawaan yang terlanjur terpotong di tengah kalimat
        $pdo->exec("UPDATE jepang_profile SET status = 'Program dan proses pendaftaran disesuaikan dengan informasi serta kerja sama yang sedang berlaku.' WHERE status = 'Program dan proses pendaftaran disesuaikan dengan informasi serta kerja sama yang sedang berlaku di'");

        // Pastikan selalu ada 1 baris profil (mencegah halaman kosong bila baris terhapus)
        if ((int)$pdo->query("SELECT COUNT(*) FROM jepang_profile")->fetchColumn() === 0) {
            $pdo->exec("INSERT INTO jepang_profile (about, purpose, target_participants, duration, status, important_info) VALUES
                ('[ISI TENTANG PROGRAM OLEH ADMIN]', '[ISI TUJUAN PROGRAM OLEH ADMIN]', '[ISI TARGET PESERTA OLEH ADMIN]', NULL, '[ISI STATUS PROGRAM OLEH ADMIN]', NULL)");
        }

        // Persyaratan & Tahapan Program (Tahapan = kategori "Tahapan Program" di dalam Persyaratan).
        if (!$exists('jepang_sections')) {
            $pdo->exec("CREATE TABLE jepang_sections (
                id INT AUTO_INCREMENT PRIMARY KEY,
                module ENUM('persyaratan') NOT NULL DEFAULT 'persyaratan',
                tag VARCHAR(80) DEFAULT NULL,
                title VARCHAR(200) NOT NULL,
                content TEXT,
                icon VARCHAR(60) DEFAULT 'fa-solid fa-circle-info',
                sort_order INT DEFAULT 0,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }
        // Migrasi instalasi lama: data Tahapan lama dipindahkan (bukan dihapus) ke Persyaratan.
        $stmt = $pdo->prepare("UPDATE jepang_sections SET module = 'persyaratan', tag = ? WHERE module = 'tahapan'");
        $stmt->execute([JEPANG_TAHAPAN_TAG]);

        return $ready = true;
    } catch (Throwable $e) {
        error_log('[jepang] ' . $e->getMessage());
        return $ready = false;
    }
}

/** Ambil Profil Program Jepang (satu baris, dengan cache dalam request) */
function jepangProfile(PDO $pdo): array
{
    static $profile = null;
    if ($profile === null) {
        ensureJepangTables($pdo);
        $profile = $pdo->query('SELECT * FROM jepang_profile ORDER BY id LIMIT 1')->fetch() ?: [];
    }
    return $profile;
}

/** Ambil Persyaratan & Tahapan (semua kategori). $onlyActive=true untuk halaman publik. */
function jepangRequirements(PDO $pdo, bool $onlyActive = true): array
{
    if (!ensureJepangTables($pdo)) return [];
    $sql = "SELECT * FROM jepang_sections WHERE module = 'persyaratan'" . ($onlyActive ? ' AND is_active = 1' : '') . ' ORDER BY sort_order ASC, id ASC';
    return $pdo->query($sql)->fetchAll();
}

/** Pisahkan hasil jepangRequirements() menjadi [persyaratan biasa, tahapan program]. */
function splitJepangRequirements(array $rows): array
{
    $requirements = [];
    $stages = [];
    foreach ($rows as $r) {
        if (strcasecmp(trim((string)($r['tag'] ?? '')), JEPANG_TAHAPAN_TAG) === 0) {
            $stages[] = $r;
        } else {
            $requirements[] = $r;
        }
    }
    return [$requirements, $stages];
}

/** Pastikan kategori galeri khusus "Program Jepang" tersedia (memakai tabel gallery/gallery_categories yang
 *  sudah ada — bukan tabel baru — supaya tidak duplikat sistem galeri). Mengembalikan id kategori. */
function ensureJepangGalleryCategory(PDO $pdo): int
{
    static $id = null;
    if ($id !== null) return $id;
    $stmt = $pdo->prepare("SELECT id FROM gallery_categories WHERE slug = ? OR name = ? ORDER BY id LIMIT 1");
    $stmt->execute(['program-jepang', 'Program Jepang']);
    $row = $stmt->fetch();
    if ($row) {
        return $id = (int)$row['id'];
    }
    // INSERT IGNORE: aman bila dua permintaan membuat kategori bersamaan (slug UNIQUE)
    $pdo->prepare("INSERT IGNORE INTO gallery_categories (name, slug) VALUES (?, ?)")->execute(['Program Jepang', 'program-jepang']);
    $stmt->execute(['program-jepang', 'Program Jepang']);
    return $id = (int)($stmt->fetchColumn() ?: 0);
}

/* ------------------------------------------------------------------
 * STRUKTUR ORGANISASI: dikelompokkan per Bidang (mis. Pimpinan, Bidang
 * Kurikulum, Staff Tata Usaha, dll), tanpa kolom Status maupun Urutan
 * manual — pengelompokan inilah yang menggantikan keduanya.
 * Migrasi otomatis dari instalasi lama: kolom status & sort_order
 * dihapus, kolom parent_id (hierarki lama) dimigrasi menjadi Bidang
 * ("Pimpinan" untuk level puncak, "Bidang Lainnya" untuk sisanya) lalu
 * dihapus, supaya data lama tidak hilang percuma dan cukup dirapikan
 * sekali oleh admin di menu Struktur Organisasi.
 * ------------------------------------------------------------------ */

/** Nama bidang/kelompok yang disarankan (admin tetap boleh mengetik nama lain). */
function orgGroupSuggestions(): array
{
    return ['Pimpinan', 'Bidang Kurikulum', 'Bidang Kesiswaan', 'Bidang Sarana & Prasarana', 'Bidang Hubungan Industri (Humas)', 'Staff Tata Usaha'];
}

/** Nama bidang yang selalu ditampilkan paling atas di halaman publik. */
const ORG_TOP_GROUP = 'Pimpinan';

/** Pastikan struktur tabel organization_structure sesuai model Bidang (grup), migrasi otomatis dari instalasi lama. */
function ensureOrgGroupColumn(PDO $pdo): void
{
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        $col = fn(string $c) => $pdo->query("SHOW COLUMNS FROM organization_structure LIKE '$c'")->fetch();

        if (!$col('group_name')) {
            $pdo->exec("ALTER TABLE organization_structure ADD COLUMN group_name VARCHAR(100) DEFAULT NULL AFTER position");
        }

        // Migrasi dari model hierarki lama (parent_id) ke model Bidang: level puncak -> "Pimpinan",
        // sisanya -> "Bidang Lainnya" (admin bisa mengganti nama bidang tersebut sesuai kebutuhan).
        if ($col('parent_id')) {
            $pdo->exec("UPDATE organization_structure SET group_name = '" . ORG_TOP_GROUP . "'
                        WHERE parent_id IS NULL AND (group_name IS NULL OR group_name = '')");
            $pdo->exec("UPDATE organization_structure SET group_name = 'Bidang Lainnya'
                        WHERE parent_id IS NOT NULL AND (group_name IS NULL OR group_name = '')");
            $fk = $pdo->query("SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE
                                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'organization_structure'
                                AND COLUMN_NAME = 'parent_id' AND REFERENCED_TABLE_NAME IS NOT NULL")->fetchColumn();
            if ($fk) {
                $pdo->exec("ALTER TABLE organization_structure DROP FOREIGN KEY `$fk`");
            }
            $pdo->exec("ALTER TABLE organization_structure DROP COLUMN parent_id");
        }
        if ($col('status')) {
            $pdo->exec("ALTER TABLE organization_structure DROP COLUMN status");
        }
        if ($col('sort_order')) {
            $pdo->exec("ALTER TABLE organization_structure DROP COLUMN sort_order");
        }
    } catch (Throwable $e) {
        error_log('[org_group] ' . $e->getMessage());
    }
}


/* ------------------------------------------------------------------
 * PENCARIAN: escape karakter khusus LIKE (% _ \) supaya pencarian "50%" atau
 * "a_b" mencari teks yang sebenarnya, bukan dianggap wildcard.
 * ------------------------------------------------------------------ */
function likeParam(string $text): string
{
    return '%' . addcslashes($text, '%_\\') . '%';
}

/* ------------------------------------------------------------------
 * GALERI vs FOTO PROGRAM JEPANG
 * Foto siswa magang ke Jepang hanya tampil di halaman Magang (Program Jepang).
 * Foto tersebut TIDAK boleh muncul di galeri umum (beranda, halaman Galeri, admin Galeri).
 * ------------------------------------------------------------------ */

/** ID kategori galeri "Program Jepang" tanpa membuat kategori baru (0 bila belum ada). */
function jepangGalleryCategoryId(PDO $pdo): int
{
    static $id = null;
    if ($id !== null) return $id;
    try {
        $stmt = $pdo->prepare("SELECT id FROM gallery_categories WHERE slug = ? OR name = ? ORDER BY id LIMIT 1");
        $stmt->execute(['program-jepang', 'Program Jepang']);
        return $id = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {
        return $id = 0;
    }
}

/** Potongan SQL (untuk WHERE) yang mengeluarkan foto Program Jepang dari galeri umum. $alias = alias tabel gallery. */
function galleryPublicSql(PDO $pdo, string $alias = ''): string
{
    $jid = jepangGalleryCategoryId($pdo);
    if ($jid <= 0) return '1=1';
    $col = ($alias !== '' ? $alias . '.' : '') . 'category_id';
    return "($col IS NULL OR $col <> " . $jid . ")";
}

/* ------------------------------------------------------------------
 * PKL: konten halaman PKL kini bisa dikelola admin (CRUD) — Tentang,
 * Tujuan, Kerja Sama Industri, dan Tahapan. Tabel dibuat otomatis
 * (database lama tetap jalan tanpa impor ulang).
 * ------------------------------------------------------------------ */
function pklTypes(): array
{
    return [
        'tentang'   => 'Tentang PKL (paragraf)',
        'tujuan'    => 'Tujuan PKL',
        'kerjasama' => 'Kerja Sama Industri',
        'tahapan'   => 'Tahapan Pelaksanaan',
    ];
}

function pklDefaults(): array
{
    return [
        ['tentang', 'Kegiatan Nyata', 'Berbeda dengan pembelajaran di kelas dan laboratorium, PKL menempatkan siswa pada situasi kerja yang sesungguhnya: ada target, tenggat waktu, standar mutu, serta kerja sama lintas bagian. Pengalaman ini membantu siswa memahami bagaimana ilmu yang dipelajari di sekolah dipakai untuk menyelesaikan persoalan nyata.', 'fa-solid fa-circle-info', 1],
        ['tentang', 'Pendampingan', 'Selama PKL siswa tetap berstatus peserta didik SMK INFOKOM BOGOR. Setiap siswa didampingi guru pembimbing dari sekolah dan pembimbing dari tempat PKL, sehingga proses belajar terarah, aman, dan terukur. Hasil kegiatan dicatat dalam jurnal, dilaporkan, dan dinilai bersama oleh sekolah dan industri.', 'fa-solid fa-circle-info', 2],
        ['tentang', 'Kesiapan Kerja', 'Dengan bekal pengalaman tersebut, diharapkan lulusan tidak hanya menguasai keterampilan teknis, tetapi juga siap beradaptasi, berkomunikasi, dan bekerja secara profesional ketika memasuki dunia kerja, melanjutkan studi, atau membangun usaha sendiri.', 'fa-solid fa-circle-info', 3],
        ['tujuan', 'Menerapkan Kompetensi', 'Mempraktikkan ilmu dan keterampilan dari kelas ke pekerjaan nyata di industri.', 'fa-solid fa-screwdriver-wrench', 1],
        ['tujuan', 'Membangun Etos Kerja', 'Melatih tanggung jawab, disiplin, kerja sama tim, dan komunikasi profesional.', 'fa-solid fa-user-tie', 2],
        ['tujuan', 'Mengenal Dunia Industri', 'Memahami struktur organisasi, budaya kerja, dan standar mutu di perusahaan.', 'fa-solid fa-building', 3],
        ['kerjasama', 'Penempatan PKL Siswa', 'Industri mitra menerima siswa PKL pada bidang pekerjaan yang relevan dengan program keahlian, sehingga siswa belajar dari alur kerja yang sebenarnya.', 'fa-solid fa-user-gear', 1],
        ['kerjasama', 'Penyelarasan Kurikulum', 'Masukan dari industri dipakai untuk menyelaraskan materi dan praktik di sekolah dengan teknologi, standar, dan kebutuhan kompetensi terbaru.', 'fa-solid fa-diagram-project', 2],
        ['kerjasama', 'Guru Tamu & Kunjungan Industri', 'Praktisi industri dapat berbagi pengalaman di sekolah, dan siswa berkesempatan mengunjungi tempat kerja untuk mengenal budaya serta lingkungan industri.', 'fa-solid fa-chalkboard-user', 3],
        ['kerjasama', 'Penyaluran Lulusan', 'Melalui Bursa Kerja Khusus (BKK), hubungan yang terjalin selama PKL membuka peluang informasi lowongan dan rekrutmen bagi lulusan.', 'fa-solid fa-briefcase', 4],
        ['tahapan', 'Koordinasi & Penjajakan Industri', 'Sekolah bersama tim Hubungan Industri menjalin komunikasi dengan perusahaan dan instansi mitra, menyepakati bidang pekerjaan yang sesuai kompetensi keahlian, kuota peserta, serta bentuk pendampingan yang akan diberikan selama PKL berlangsung.', 'fa-solid fa-handshake-simple', 1],
        ['tahapan', 'Pembekalan Siswa', 'Sebelum berangkat, siswa mengikuti pembekalan yang mencakup etika dan budaya kerja, keselamatan dan kesehatan kerja (K3), disiplin waktu, komunikasi profesional, serta tata tertib sekolah yang tetap berlaku selama siswa berada di tempat PKL.', 'fa-solid fa-clipboard-list', 2],
        ['tahapan', 'Penempatan & Administrasi', 'Siswa ditempatkan di industri mitra sesuai jurusan dan minat. Sekolah mengurus surat pengantar, perjanjian kerja sama, dan kelengkapan administrasi, sementara orang tua/wali memberikan persetujuan agar siswa siap menjalani praktik.', 'fa-solid fa-file-signature', 3],
        ['tahapan', 'Pelaksanaan & Pendampingan', 'Siswa mengerjakan tugas nyata di tempat PKL dengan bimbingan pembimbing industri. Guru pembimbing dari sekolah memantau perkembangan melalui kunjungan, komunikasi berkala, dan jurnal harian yang diisi siswa selama kegiatan.', 'fa-solid fa-route', 4],
        ['tahapan', 'Monitoring & Evaluasi', 'Pembimbing sekolah dan pembimbing industri mengevaluasi ketercapaian tugas, sikap kerja, dan kompetensi teknis. Kendala yang muncul di lapangan dibahas bersama agar pelaksanaan PKL tetap berjalan aman, nyaman, dan bermanfaat.', 'fa-solid fa-chart-column', 5],
        ['tahapan', 'Penilaian, Laporan & Sertifikat', 'Di akhir PKL, siswa menyusun laporan kegiatan dan mempresentasikan hasilnya. Penilaian dari industri dan sekolah digabungkan, lalu siswa yang memenuhi ketentuan memperoleh sertifikat PKL sebagai bukti pengalaman dan kompetensi kerja.', 'fa-solid fa-award', 6],
    ];
}

/** Pastikan tabel pkl_items ada dan terisi konten bawaan (hanya saat tabel baru dibuat). */
function ensurePklTable(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;
    try {
        $exists = $pdo->query("SHOW TABLES LIKE 'pkl_items'")->fetchColumn() !== false;
        if (!$exists) {
            $pdo->exec("CREATE TABLE pkl_items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                kind VARCHAR(20) NOT NULL,
                title VARCHAR(150) NOT NULL,
                content TEXT,
                icon VARCHAR(60) DEFAULT 'fa-solid fa-circle-check',
                sort_order INT DEFAULT 0,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                KEY idx_kind (kind, sort_order)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $ins = $pdo->prepare("INSERT INTO pkl_items (kind, title, content, icon, sort_order) VALUES (?,?,?,?,?)");
            foreach (pklDefaults() as $row) $ins->execute($row);
        } else {
            // Versi lama memakai kolom "item_type"; database.sql terbaru memakai "kind". Sesuaikan otomatis.
            $hasKind = $pdo->query("SHOW COLUMNS FROM pkl_items LIKE 'kind'")->fetch();
            $hasOld  = $pdo->query("SHOW COLUMNS FROM pkl_items LIKE 'item_type'")->fetch();
            if (!$hasKind && $hasOld) {
                $pdo->exec("ALTER TABLE pkl_items CHANGE item_type kind VARCHAR(20) NOT NULL");
            }
        }
        return $ready = true;
    } catch (Throwable $e) {
        error_log('[pkl_items] ' . $e->getMessage());
        return $ready = false;
    }
}

/** Ambil butir konten PKL per jenis. Bila tabel tidak bisa dibuat, dipakai konten bawaan. */
function pklItems(PDO $pdo, string $type, bool $onlyActive = true): array
{
    if (!ensurePklTable($pdo)) {
        $out = [];
        foreach (pklDefaults() as $i => $r) {
            if ($r[0] === $type) $out[] = ['id' => 0, 'kind' => $r[0], 'title' => $r[1], 'content' => $r[2], 'icon' => $r[3], 'sort_order' => $r[4], 'is_active' => 1];
        }
        return $out;
    }
    $sql = 'SELECT * FROM pkl_items WHERE kind = ?' . ($onlyActive ? ' AND is_active = 1' : '') . ' ORDER BY sort_order ASC, id ASC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$type]);
    return $stmt->fetchAll();
}

/** Buat slug unik untuk tabel kategori ($table = 'gallery_categories' | 'news_categories'). */
function uniqueCategorySlug(PDO $pdo, string $table, string $name, int $ignoreId = 0): string
{
    if (!in_array($table, ['gallery_categories', 'news_categories'], true)) return 'kategori';
    $base = strtolower(trim(preg_replace('~[^a-zA-Z0-9]+~', '-', $name), '-'));
    if ($base === '') $base = 'kategori';
    $slug = $base;
    $n = 2;
    $chk = $pdo->prepare("SELECT COUNT(*) FROM $table WHERE slug = ? AND id <> ?");
    while (true) {
        $chk->execute([$slug, $ignoreId]);
        if ((int)$chk->fetchColumn() === 0) return $slug;
        $slug = $base . '-' . $n++;
    }
}


/* ------------------------------------------------------------------
 * FAQ PPDB — tabel sendiri supaya admin bisa tambah/ubah/hapus/urutkan satu per satu.
 * Data lama (kolom ppdb_settings.faq, satu baris per FAQ) dipindahkan otomatis sekali saat tabel dibuat.
 * ------------------------------------------------------------------ */
function ensurePpdbFaqTable(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;
    try {
        if ($pdo->query("SHOW TABLES LIKE 'ppdb_faqs'")->fetchColumn() === false) {
            $pdo->exec("CREATE TABLE ppdb_faqs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                question VARCHAR(255) NOT NULL,
                answer TEXT,
                sort_order INT DEFAULT 0,
                is_active TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $legacy = '';
            try { $legacy = (string)$pdo->query("SELECT faq FROM ppdb_settings ORDER BY id DESC LIMIT 1")->fetchColumn(); } catch (Throwable $e) {}
            $ins = $pdo->prepare("INSERT INTO ppdb_faqs (question, answer, sort_order) VALUES (?,?,?)");
            foreach (parseLegacyFaq($legacy) as $i => $row) $ins->execute([$row[0], $row[1], $i + 1]);
        }
        return $ready = true;
    } catch (Throwable $e) {
        error_log('[faq] ' . $e->getMessage());
        return $ready = false;
    }
}

/** Pecah teks FAQ lama ("Pertanyaan | Jawaban" atau "Pertanyaan? Jawaban") menjadi [[tanya, jawab], ...] */
function parseLegacyFaq(string $text): array
{
    $out = [];
    foreach (preg_split('/\R/u', $text) as $line) {
        $line = trim($line);
        if ($line === '') continue;
        $q = $line; $a = '';
        $bar = mb_strpos($line, '|');
        $qm  = mb_strpos($line, '?');
        if ($bar !== false) { $q = trim(mb_substr($line, 0, $bar)); $a = trim(mb_substr($line, $bar + 1)); }
        elseif ($qm !== false && $qm < mb_strlen($line) - 1) { $q = trim(mb_substr($line, 0, $qm + 1)); $a = trim(mb_substr($line, $qm + 1)); }
        if ($q === '') continue;
        $out[] = [mb_substr($q, 0, 255), $a];
    }
    return $out;
}

/** Daftar FAQ PPDB. $onlyActive=true untuk halaman publik. */
function ppdbFaqs(PDO $pdo, bool $onlyActive = true): array
{
    if (!ensurePpdbFaqTable($pdo)) return [];
    $sql = 'SELECT * FROM ppdb_faqs' . ($onlyActive ? ' WHERE is_active = 1' : '') . ' ORDER BY sort_order ASC, id ASC';
    return $pdo->query($sql)->fetchAll();
}

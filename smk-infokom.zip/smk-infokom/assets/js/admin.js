/**
 * Posisi scroll sidebar dipertahankan antar halaman.
 * Sebelumnya, setiap klik menu (mis. "Pengaturan Admin" di bagian bawah) memuat ulang halaman
 * dan sidebar melompat kembali ke paling atas sehingga menu aktif tidak terlihat.
 * Sekarang posisi terakhir disimpan lalu dipulihkan; bila belum ada posisi tersimpan (atau menu aktif
 * berada di luar layar), menu aktif otomatis digulir hingga terlihat.
 */
(function keepSidebarScroll() {
  const sidebar = document.getElementById('adminSidebar');
  if (!sidebar) return;
  const KEY = 'adminSidebarScrollTop';
  const store = {
    get() { try { return sessionStorage.getItem(KEY); } catch (e) { return null; } },
    set(v) { try { sessionStorage.setItem(KEY, String(v)); } catch (e) { /* mode privat: abaikan */ } }
  };

  const saved = parseInt(store.get(), 10);
  if (!isNaN(saved)) sidebar.scrollTop = saved;

  const active = sidebar.querySelector('.sidebar-nav a.active');
  if (active) {
    const brand = sidebar.querySelector('.sidebar-brand');
    const topLimit = sidebar.scrollTop + (brand ? brand.offsetHeight : 0);
    const bottomLimit = sidebar.scrollTop + sidebar.clientHeight;
    const itemTop = active.offsetTop;
    const itemBottom = itemTop + active.offsetHeight;
    if (itemTop < topLimit || itemBottom > bottomLimit) {
      sidebar.scrollTop = Math.max(0, itemTop - sidebar.clientHeight / 2 + active.offsetHeight / 2);
    }
  }

  let ticking = false;
  sidebar.addEventListener('scroll', () => {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => { store.set(sidebar.scrollTop); ticking = false; });
  }, { passive: true });
  sidebar.addEventListener('click', (e) => { if (e.target.closest('a')) store.set(sidebar.scrollTop); });
  window.addEventListener('pagehide', () => store.set(sidebar.scrollTop));
})();

document.addEventListener('DOMContentLoaded', function () {
  const sidebar = document.getElementById('adminSidebar');
  const toggleBtn = document.getElementById('sidebarToggle');
  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => sidebar.classList.toggle('open'));
  }

  const userDropdown = document.getElementById('userDropdown');
  const dropdownMenu = document.getElementById('dropdownMenu');
  if (userDropdown && dropdownMenu) {
    userDropdown.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdownMenu.classList.toggle('open');
    });
    document.addEventListener('click', () => dropdownMenu.classList.remove('open'));
  }

  document.querySelectorAll('.js-confirm-delete').forEach(el => {
    el.addEventListener('click', function (e) {
      if (!confirm(this.getAttribute('data-confirm') || 'Yakin ingin menghapus data ini? Tindakan ini tidak dapat dibatalkan.')) {
        e.preventDefault();
      }
    });
  });

  document.querySelectorAll('.js-image-preview').forEach(input => {
    input.addEventListener('change', function () {
      const target = document.getElementById(this.getAttribute('data-preview-target'));
      if (target && this.files && this.files[0]) {
        target.src = URL.createObjectURL(this.files[0]);
        target.style.display = 'block';
      }
    });
  });

  document.querySelectorAll('.js-toggle-pass').forEach(btn => {
    btn.addEventListener('click', function () {
      const input = document.getElementById(this.getAttribute('data-target'));
      if (input) {
        const isPass = input.type === 'password';
        input.type = isPass ? 'text' : 'password';
        this.innerHTML = isPass ? '<i class="fa-solid fa-eye-slash"></i>' : '<i class="fa-solid fa-eye"></i>';
      }
    });
  });

  const toast = document.getElementById('flashToast');
  if (toast) {
    const isError = toast.classList.contains('toast-error');
    toast.style.cursor = 'pointer';
    toast.title = 'Klik untuk menutup';
    toast.addEventListener('click', () => toast.remove());
    setTimeout(() => toast.remove(), isError ? 10000 : 3600);
  }
});

/* =====================================================
   SMK INFOKOM BOGOR - script.js
===================================================== */
window.siteJsReady = true;
document.addEventListener('DOMContentLoaded', function () {

  /* ---------- Reveal on scroll (dijalankan PERTAMA agar konten tidak pernah tertahan) ----------
     Kecepatan & jarak diatur di frontend.css (BAGIAN 7.1). Elemen yang muncul bersamaan diberi jeda
     bertahap (--reveal-delay) supaya kartu satu baris muncul berurutan, bukan serentak. */
  const reveals = document.querySelectorAll('.reveal');
  if (reveals.length > 0) {
    if ('IntersectionObserver' in window) {
      const staggerMs = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--reveal-stagger')) || 70;
      const MAX_DELAY = 350;   // jeda terbesar (ms) supaya baris panjang tidak terasa lambat
      const revealObserver = new IntersectionObserver((entries) => {
        let order = 0;
        entries.forEach(entry => {
          if (!entry.isIntersecting) return;
          entry.target.style.setProperty('--reveal-delay', Math.min(order * staggerMs, MAX_DELAY) + 'ms');
          entry.target.classList.add('show');
          revealObserver.unobserve(entry.target);
          order++;
        });
      }, { threshold: 0, rootMargin: '0px 0px -6% 0px' }); // threshold 0: elemen sangat tinggi tetap muncul
      reveals.forEach(r => revealObserver.observe(r));
    } else {
      reveals.forEach(r => r.classList.add('show'));
    }
  }

  /* ---------- Hamburger mobile menu ---------- */
  const hamburger = document.getElementById('hamburgerBtn');
  const mainNav = document.getElementById('mainNav');
  function closeMobileMenu() {
    if (!mainNav || !hamburger) return;
    mainNav.classList.remove('open');
    hamburger.classList.remove('open');
    hamburger.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('menu-open');
    document.querySelectorAll('.has-dropdown.open').forEach(el => el.classList.remove('open'));
  }
  if (hamburger && mainNav) {
    hamburger.addEventListener('click', function () {
      const isOpen = mainNav.classList.toggle('open');
      hamburger.classList.toggle('open', isOpen);
      hamburger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      document.body.classList.toggle('menu-open', isOpen);
    });
    // Tautan biasa (bukan induk dropdown di mobile) menutup menu — termasuk tautan anchor di halaman yang sama
    mainNav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      const isDropdownParent = a.parentElement.classList.contains('has-dropdown');
      if (window.innerWidth > 860 || !isDropdownParent) closeMobileMenu();
    }));
    window.addEventListener('resize', () => { if (window.innerWidth > 860) closeMobileMenu(); });
  }

  /* ---------- Dropdown nav (mobile: tap to expand) ---------- */
  document.querySelectorAll('.has-dropdown > a').forEach(link => {
    link.addEventListener('click', function (e) {
      if (window.innerWidth <= 860) {
        e.preventDefault();
        const li = this.parentElement;
        const wasOpen = li.classList.contains('open');
        document.querySelectorAll('.has-dropdown.open').forEach(el => el.classList.remove('open'));
        li.classList.toggle('open', !wasOpen);
      }
    });
  });

  /* ---------- Navbar: hilang saat scroll ke bawah, muncul lagi saat scroll ke atas ----------
     Perbaikan: jarak scroll DIAKUMULASI per arah. Versi lama membandingkan tiap frame (selisih kecil
     saat scroll halus/trackpad tidak pernah melewati ambang) sehingga navbar tidak mau hilang. */
  const header = document.getElementById('siteHeader');
  if (header) {
    const root = document.documentElement;
    let lastY = window.pageYOffset || 0;
    let acc = 0;                 // akumulasi jarak scroll searah (positif = ke bawah)
    let ticking = false;
    const HIDE_AFTER = 90;       // mulai boleh hilang setelah melewati posisi ini
    const HIDE_DIST  = 14;       // jarak scroll ke bawah sebelum navbar disembunyikan
    const SHOW_DIST  = 10;       // jarak scroll ke atas sebelum navbar dimunculkan
    const setHidden = (hide) => {
      header.classList.toggle('nav-hidden', hide);
      root.classList.toggle('nav-is-hidden', hide);
      if (hide) {
        document.querySelectorAll('.has-dropdown.open').forEach(el => el.classList.remove('open'));
        if (document.activeElement && header.contains(document.activeElement)) document.activeElement.blur();
      }
    };
    const onScroll = () => {
      ticking = false;
      const y = Math.max(0, window.pageYOffset || document.documentElement.scrollTop || 0);
      const delta = y - lastY;
      lastY = y;
      const menuOpen = mainNav && mainNav.classList.contains('open');
      header.classList.toggle('is-scrolled', y > 10);
      if (menuOpen || y <= HIDE_AFTER) { acc = 0; setHidden(false); return; }   // di puncak halaman: selalu tampil
      if (delta === 0) return;
      if ((delta > 0) !== (acc > 0)) acc = 0;                                      // arah berganti: hitung ulang
      acc += delta;
      if (acc > HIDE_DIST) { setHidden(true); acc = 0; }                           // ke bawah: sembunyi
      else if (acc < -SHOW_DIST) { setHidden(false); acc = 0; }                    // ke atas: tampil lagi
    };
    window.addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });
    header.addEventListener('focusin', () => setHidden(false));
    // Kursor di tepi atas layar (desktop) juga memunculkan navbar kembali
    document.addEventListener('mousemove', (e) => { if (e.clientY < 6 && header.classList.contains('nav-hidden')) setHidden(false); }, { passive: true });
    onScroll();
  }

  /* ---------- Hero Slider ---------- */
  const slides = document.querySelectorAll('.hero-slide');
  const dotsWrap = document.getElementById('sliderDots');
  if (slides.length > 0) {
    let current = 0;
    let timer;

    if (dotsWrap) {
      slides.forEach((_, i) => {
        const dot = document.createElement('button');
        dot.className = 'slider-dot' + (i === 0 ? ' active' : '');
        dot.addEventListener('click', () => goToSlide(i));
        dotsWrap.appendChild(dot);
      });
    }

    function goToSlide(index) {
      slides[current].classList.remove('active');
      dotsWrap && dotsWrap.children[current] && dotsWrap.children[current].classList.remove('active');
      current = (index + slides.length) % slides.length;
      slides[current].classList.add('active');
      dotsWrap && dotsWrap.children[current] && dotsWrap.children[current].classList.add('active');
    }

    function nextSlide() { goToSlide(current + 1); }
    function prevSlide() { goToSlide(current - 1); }

    document.querySelectorAll('.slider-arrow.next').forEach(b => b.addEventListener('click', () => { nextSlide(); resetTimer(); }));
    document.querySelectorAll('.slider-arrow.prev').forEach(b => b.addEventListener('click', () => { prevSlide(); resetTimer(); }));

    function resetTimer() {
      clearInterval(timer);
      timer = setInterval(nextSlide, 6000);
    }
    resetTimer();
  }

  /* ---------- Counter animation on scroll ---------- */
  const counters = document.querySelectorAll('.stat-number[data-target]');
  if (counters.length > 0) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });
    counters.forEach(c => observer.observe(c));
  }
  function animateCounter(el) {
    const target = parseInt(el.getAttribute('data-target'), 10) || 0;
    const suffix = el.getAttribute('data-suffix') || '';
    const duration = 1400;
    const start = performance.now();
    function tick(now) {
      const progress = Math.min((now - start) / duration, 1);
      const value = Math.floor(progress * target);
      el.textContent = value.toLocaleString('id-ID') + suffix;
      if (progress < 1) requestAnimationFrame(tick);
      else el.textContent = target.toLocaleString('id-ID') + suffix;
    }
    requestAnimationFrame(tick);
  }

  /* ---------- Tab navigasi anchor (halaman Akademik) ---------- */
  const tabLinks = document.querySelectorAll('.profile-tabs a[href^="#"]');
  if (tabLinks.length) {
    const items = [];
    tabLinks.forEach(a => {
      const t = document.querySelector(a.getAttribute('href'));
      if (t) items.push({ a, t });
      a.addEventListener('click', () => { tabLinks.forEach(x => x.classList.remove('active')); a.classList.add('active'); });
    });
    let ticking = false;
    const updateActive = () => {
      ticking = false;
      const line = window.innerHeight * 0.35;            // garis acuan di layar
      let current = items[0];                             // di atas target pertama -> tab pertama
      items.forEach(it => { if (it.t.getBoundingClientRect().top <= line) current = it; });
      if (current) { tabLinks.forEach(x => x.classList.remove('active')); current.a.classList.add('active'); }
    };
    window.addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(updateActive); } }, { passive: true });
    updateActive();
  }

  /* ---------- Gallery filter ---------- */
  const filterBtns = document.querySelectorAll('.gallery-filter button');
  const galleryItems = document.querySelectorAll('.gallery-grid .gallery-item');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.getAttribute('data-filter');
      galleryItems.forEach(item => {
        const show = cat === 'all' || item.getAttribute('data-category') === cat;
        item.style.display = show ? '' : 'none';
      });
    });
  });

  /* ---------- Lightbox (galeri, foto Jepang, foto berita) ---------- */
  const lightbox = document.createElement('div');
  lightbox.id = 'lightboxOverlay';
  lightbox.className = 'lightbox';
  lightbox.setAttribute('role', 'dialog');
  lightbox.setAttribute('aria-modal', 'true');
  lightbox.innerHTML = '<button type="button" class="lightbox-close" aria-label="Tutup">&times;</button>' +
    '<figure><img id="lightboxImg" alt=""><figcaption id="lightboxCap"></figcaption></figure>';
  document.body.appendChild(lightbox);
  const lbImg = lightbox.querySelector('#lightboxImg');
  const lbCap = lightbox.querySelector('#lightboxCap');
  function openLightbox(img) {
    lbImg.src = img.currentSrc || img.src;
    lbImg.alt = img.alt || '';
    const holder = img.closest('.gallery-item, .jp-photo-card, .news-photo');
    const capEl = holder && holder.querySelector('.gallery-cap, figcaption');
    lbCap.textContent = capEl ? capEl.textContent.trim() : (img.alt || '');
    lightbox.classList.add('show');
    document.body.classList.add('lightbox-open');
  }
  function closeLightbox() { lightbox.classList.remove('show'); document.body.classList.remove('lightbox-open'); }
  document.querySelectorAll('.gallery-item img, .jp-photo-card img, .news-photo img, img.news-article-cover, img[data-lightbox]').forEach(img => {
    img.style.cursor = 'zoom-in';
    img.addEventListener('click', () => openLightbox(img));
  });
  lightbox.addEventListener('click', (e) => { if (e.target === lightbox || e.target.classList.contains('lightbox-close')) closeLightbox(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeLightbox(); });

  /* ---------- FAQ accordion ---------- */
  document.querySelectorAll('.faq-item').forEach(item => {
    const q = item.querySelector('.faq-question');
    q && q.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item.open').forEach(el => el.classList.remove('open'));
      if (!isOpen) item.classList.add('open');
    });
  });

  /* ---------- Confirm delete (admin) ---------- */
  document.querySelectorAll('.js-confirm-delete').forEach(el => {
    el.addEventListener('click', function (e) {
      if (!confirm(this.getAttribute('data-confirm') || 'Yakin ingin menghapus data ini?')) {
        e.preventDefault();
      }
    });
  });

  /* ---------- Auto-hide toast ---------- */
  const toast = document.getElementById('flashToast');
  if (toast) {
    toast.addEventListener('click', () => toast.remove());
    setTimeout(() => toast.remove(), toast.classList.contains('toast-error') ? 9000 : 3600);
  }

  /* ---------- Image preview on file input (admin) ---------- */
  document.querySelectorAll('.js-image-preview').forEach(input => {
    input.addEventListener('change', function () {
      const target = document.getElementById(this.getAttribute('data-preview-target'));
      if (target && this.files && this.files[0]) {
        target.src = URL.createObjectURL(this.files[0]);
        target.style.display = 'block';
      }
    });
  });
});

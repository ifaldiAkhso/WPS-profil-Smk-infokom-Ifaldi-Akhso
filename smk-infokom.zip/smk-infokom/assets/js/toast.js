/* Notifikasi modern (toast) + validasi form ramah. API: siteToast({type:'success|error|info', title, message, duration}) */
(function(){
  var box;
  var ico={success:'fa-circle-check',error:'fa-circle-exclamation',info:'fa-circle-info'};
  function ensure(){ if(box) return box; box=document.createElement('div'); box.className='toast-stack'; box.setAttribute('role','status'); box.setAttribute('aria-live','polite'); document.body.appendChild(box); return box; }
  function esc(t){ var d=document.createElement('div'); d.textContent=t==null?'':String(t); return d.innerHTML; }
  window.siteToast=function(o){
    o=o||{}; var type=o.type||'info', el=document.createElement('div');
    el.className='toast toast-'+type;
    el.innerHTML='<span class="toast-ico"><i class="fa-solid '+(ico[type]||ico.info)+'"></i></span><div class="toast-body"><strong>'+esc(o.title||'')+'</strong>'+(o.message?'<p>'+esc(o.message)+'</p>':'')+'</div><button type="button" class="toast-x" aria-label="Tutup">&times;</button><span class="toast-bar"></span>';
    var ms=o.duration||6000; el.style.setProperty('--ms',ms+'ms');
    ensure().appendChild(el);
    requestAnimationFrame(function(){ el.classList.add('in'); });
    function close(){ el.classList.remove('in'); setTimeout(function(){ el.remove(); },300); }
    el.querySelector('.toast-x').addEventListener('click',close);
    setTimeout(close,ms);
  };
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('form.form-card').forEach(function(f){
      f.setAttribute('novalidate','novalidate');
      f.addEventListener('submit',function(e){
        var bad=f.querySelector(':invalid');
        if(bad){
          e.preventDefault();
          var lb=bad.closest('.form-group'), name=lb&&lb.querySelector('label')?lb.querySelector('label').textContent.replace('*','').trim():'data';
          siteToast({type:'error',title:'Data belum lengkap',message:'Mohon periksa kembali: '+name+'.'});
          bad.classList.add('is-invalid'); bad.scrollIntoView({behavior:'smooth',block:'center'}); try{bad.focus({preventScroll:true});}catch(x){}
          return;
        }
        var b=f.querySelector('button[type=submit],input[type=submit]'); if(b){ b.classList.add('is-loading'); }
      });
      f.addEventListener('input',function(e){ if(e.target.classList) e.target.classList.remove('is-invalid'); });
    });
    var flash=document.querySelectorAll('[data-toast]');
    flash.forEach(function(n){ siteToast({type:n.getAttribute('data-toast'),title:n.getAttribute('data-title')||'',message:n.getAttribute('data-message')||''}); });
  });
  /* Navigasi: semua menu & dropdown langsung bisa diklik, tanpa jeda.
     Desktop  : dropdown terbuka saat kursor/fokus di atas menu (CSS), klik induk langsung membuka halamannya.
     Layar sentuh lebar (tablet): ketukan pertama membuka dropdown, ketukan kedua membuka halaman induk.
     Mobile   : diatur script.js (menu geser + accordion). */
  document.addEventListener('DOMContentLoaded',function(){
    var items=[].slice.call(document.querySelectorAll('.has-dropdown'));
    var touchWide=window.matchMedia('(hover:none) and (min-width:861px)');
    function closeAll(except){ items.forEach(function(x){ if(x!==except) x.classList.remove('open'); }); }
    items.forEach(function(li){
      var a=[].slice.call(li.children).filter(function(c){return c.tagName==='A';})[0];
      if(a) a.addEventListener('click',function(e){
        if(!touchWide.matches) return;
        if(!li.classList.contains('open')){ e.preventDefault(); closeAll(li); li.classList.add('open'); }
      });
    });
    document.addEventListener('click',function(e){ if(!(e.target.closest&&e.target.closest('.has-dropdown'))) closeAll(); });
    document.addEventListener('keydown',function(e){ if(e.key==='Escape'){ closeAll(); } });
    window.addEventListener('pageshow',function(){ closeAll(); });
    /* Menu mobile: klik area gelap di luar sidebar menutup menu */
    document.addEventListener('click',function(e){
      if(!document.body.classList.contains('menu-open')) return;
      if(e.target.closest&&(e.target.closest('.main-nav')||e.target.closest('#hamburgerBtn')||e.target.closest('.hamburger'))) return;
      var hb=document.getElementById('hamburgerBtn'); if(hb) hb.click();
    });
  });
})();

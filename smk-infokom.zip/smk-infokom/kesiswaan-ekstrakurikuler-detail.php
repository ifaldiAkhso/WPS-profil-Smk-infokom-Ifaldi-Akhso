<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-akademik';
$pdo = getDB();
ensureKesiswaanTables($pdo);

$slug = trim($_GET['slug'] ?? '');
$stmt = $pdo->prepare("SELECT * FROM extracurriculars WHERE slug = ? AND is_active = 1");
$stmt->execute([$slug]);
$item = $stmt->fetch();
if (!$item) {
    setFlash('error', 'Data ekstrakurikuler tidak ditemukan.');
    redirect(BASE_URL . 'kesiswaan-ekstrakurikuler.php');
}
$pageTitle = $item['name'];

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'Ekstrakurikuler';
$heroTitle   = $item['name'];
$heroText    = !empty($item['category']) ? $item['category'] : 'Ekstrakurikuler SMK INFOKOM BOGOR';
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Kesiswaan', BASE_URL . 'kesiswaan.php'], ['Ekstrakurikuler', BASE_URL . 'kesiswaan-ekstrakurikuler.php'], [$item['name'], null]];
$heroCompact = true;
$heroImage = null;
include __DIR__ . '/includes/page-hero.php';
?>
<section class="profile-section">
  <div class="container">
    <div class="profile-story-grid reveal">
      <div class="profile-photo-card">
        <img src="<?= uploadUrl($item['photo'], 'assets/images/program-placeholder.jpg') ?>" alt="<?= e($item['name']) ?>">
        <div class="photo-caption"><i class="fa-solid fa-person-running"></i><span>Ekstrakurikuler</span></div>
      </div>
      <article class="profile-article-card">
        <div class="article-kicker"><span></span> Ekstrakurikuler <span></span></div>
        <h2><?= e($item['name']) ?></h2>
        <div class="article-copy">
          <?php
            $desc = trim((string)($item['description'] ?? ''));
            foreach (preg_split('/\R{2,}/', $desc !== '' ? $desc : 'Deskripsi ekstrakurikuler ini belum diisi.') as $para):
              if (trim($para) === '') continue;
          ?>
            <p><?= nl2br(e(trim($para))) ?></p>
          <?php endforeach; ?>
        </div>

        <div class="school-facts">
          <div class="school-fact">
            <div class="school-fact-icon"><i class="fa-solid fa-clock"></i></div>
            <div><small>Jadwal</small><strong><?= e($item['schedule'] ?: 'Belum diinformasikan') ?></strong></div>
          </div>
          <div class="school-fact">
            <div class="school-fact-icon"><i class="fa-solid fa-user-tie"></i></div>
            <div><small>Pembina</small><strong><?= e($item['supervisor'] ?: 'Belum diinformasikan') ?></strong></div>
          </div>
          <div class="school-fact">
            <div class="school-fact-icon"><i class="fa-solid fa-location-dot"></i></div>
            <div><small>Tempat Kegiatan</small><strong><?= e($item['location'] ?: 'Belum diinformasikan') ?></strong></div>
          </div>
          <div class="school-fact">
            <div class="school-fact-icon"><i class="fa-solid fa-tag"></i></div>
            <div><small>Kategori</small><strong><?= e($item['category'] ?: '-') ?></strong></div>
          </div>
        </div>

        <?php if (!empty(trim((string)($item['achievement_note'] ?? '')))): ?>
          <div class="program-excellence">
            <i class="fa-solid fa-star"></i>
            <div><small>Prestasi</small><p><?= nl2br(e($item['achievement_note'])) ?></p></div>
          </div>
        <?php endif; ?>
      </article>
    </div>

    <div class="profile-back reveal">
      <a href="<?= BASE_URL ?>kesiswaan-ekstrakurikuler.php" class="btn btn-outline-navy btn-sm"><i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar Ekstrakurikuler</a>
    </div>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

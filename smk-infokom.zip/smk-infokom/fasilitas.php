<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-school no-tabs';
$pdo = getDB();
$pageTitle = 'Fasilitas Sekolah';
$activeProfile = 'fasilitas.php';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
$facilities = $pdo->query("SELECT * FROM facilities ORDER BY sort_order ASC, name ASC")->fetchAll();
?>
<?php
$heroEyebrow = 'Profil Sekolah';
$heroTitle = 'Fasilitas Sekolah';
$heroText = 'Sarana dan prasarana yang menunjang pengalaman belajar siswa di SMK INFOKOM BOGOR.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Fasilitas Sekolah', null]];
include __DIR__ . '/includes/page-hero.php';
?>

<section class="profile-section">
  <div class="container">
    <?php include __DIR__ . '/includes/profile-nav.php'; ?>

    <div class="facility-modern-grid reveal">
      <?php if (!$facilities): ?>
        <div class="empty-state modern-empty"><i class="fa-solid fa-building-columns"></i><p>Data fasilitas belum tersedia.</p></div>
      <?php else: ?>
        <?php foreach ($facilities as $facility): ?>
          <article class="facility-modern-card">
            <div class="facility-modern-media">
              <img src="<?= uploadUrl($facility['image'] ?? null, 'assets/images/facility-placeholder.jpg') ?>" alt="<?= e($facility['name']) ?>">
              <span><i class="fa-solid fa-check"></i></span>
            </div>
            <div class="facility-modern-body">
              <div class="article-kicker"><span></span> Sarana <span></span></div>
              <h2><?= e($facility['name']) ?></h2>
              <p><?= e($facility['description'] ?? '') ?></p>
            </div>
          </article>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <a href="<?= BASE_URL ?>struktur.php" class="btn btn-outline-navy profile-back"><i class="fa-solid fa-arrow-left"></i> Kembali ke Struktur Organisasi</a>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-info no-footer';
$pdo = getDB();
$pageTitle = 'Kunjungan Industri';
$ready = ensureIndustryVisits($pdo);
$items = $ready ? $pdo->query("SELECT * FROM industry_visits WHERE is_active = 1 ORDER BY visit_date DESC, id DESC LIMIT 60")->fetchAll() : [];
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
$heroEyebrow = 'Informasi';
$heroTitle = 'Kunjungan Industri';
$heroText = 'Siswa belajar langsung di dunia usaha dan dunia industri melalui kunjungan ke perusahaan mitra.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['Kunjungan Industri', null]];
include __DIR__ . '/includes/page-hero.php';
?>
<section>
  <div class="container">
    <?php if (count($items) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-industry"></i><p>Belum ada data kunjungan industri.</p></div>
    <?php else: ?>
      <div class="visit-grid">
        <?php foreach ($items as $v): ?>
          <a class="visit-card reveal" href="kunjungan-industri-detail.php?id=<?= (int)$v['id'] ?>">
            <div class="visit-media" style="--ar:<?= round(imageRatio($v['image'], 'assets/images/news-placeholder.jpg'), 4) ?>"><img src="<?= uploadUrl($v['image'], 'assets/images/news-placeholder.jpg') ?>" alt="<?= e(visitTitle($v)) ?>" loading="lazy">
              <?php if (!empty($v['company'])): ?><span class="visit-chip"><i class="fa-solid fa-building"></i> <?= e($v['company']) ?></span><?php endif; ?></div>
            <div class="visit-body">
              <div class="visit-meta">
                <?php if (!empty($v['visit_date'])): ?><span><i class="fa-regular fa-calendar"></i> <?= e(tanggalIndo($v['visit_date'])) ?></span><?php endif; ?>
                <?php if (!empty($v['location'])): ?><span><i class="fa-solid fa-location-dot"></i> <?= e($v['location']) ?></span><?php endif; ?>
              </div>
              <?php if (visitTitle($v) !== ''): ?><h3><?= e(visitTitle($v)) ?></h3><?php endif; ?>
              <?php if (!empty($v['description'])): ?><p><?= e(cutSentence(strip_tags($v['description']), 170)) ?></p><?php endif; ?>
              <span class="visit-more">Lihat detail <i class="fa-solid fa-arrow-right"></i></span>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php $backHref = BASE_URL . 'index.php'; $backLabel = 'Kembali ke Beranda'; include __DIR__ . '/includes/back-button.php'; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>

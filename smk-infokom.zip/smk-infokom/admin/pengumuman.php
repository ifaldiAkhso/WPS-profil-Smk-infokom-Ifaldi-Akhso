<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Pengumuman';
ensureAnnouncementImageColumn($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    if ($action === 'delete') {
        $delId = (int)($_POST['id'] ?? 0);
        $img = $pdo->prepare("SELECT image FROM announcements WHERE id=?");
        $img->execute([$delId]);
        deleteUploadedFile($img->fetchColumn() ?: null);
        $pdo->prepare("DELETE FROM announcements WHERE id=?")->execute([$delId]);
        setFlash('success', 'Pengumuman berhasil dihapus.');
        redirect('pengumuman.php');
    } elseif ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $upload = handleImageUpload('image', 'pengumuman');
        if (!$upload['ok']) {
            setFlash('error', $upload['message']);
            redirect('pengumuman.php' . ($id > 0 ? '?edit=' . $id : ''));
        }
        if ($id > 0) {
            $old = $pdo->prepare("SELECT image FROM announcements WHERE id=?");
            $old->execute([$id]);
            $oldImage = $old->fetchColumn() ?: null;
            $image = $upload['file'] ?? (!empty($_POST['remove_image']) ? null : $oldImage);
            $pdo->prepare("UPDATE announcements SET title=?, content=?, image=?, is_active=? WHERE id=?")
                ->execute([$title, $content, $image, $isActive, $id]);
            if ($oldImage && $oldImage !== $image) deleteUploadedFile($oldImage);
            setFlash('success', 'Pengumuman berhasil diperbarui.');
        } else {
            $pdo->prepare("INSERT INTO announcements (title, content, image, is_active) VALUES (?,?,?,?)")
                ->execute([$title, $content, $upload['file'], $isActive]);
            setFlash('success', 'Pengumuman berhasil ditambahkan.');
        }
        redirect('pengumuman.php');
    }
}

$editId = (int)($_GET['edit'] ?? 0);
$editData = null;
if ($editId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM announcements WHERE id=?");
    $stmt->execute([$editId]);
    $editData = $stmt->fetch();
}
$items = $pdo->query("SELECT * FROM announcements ORDER BY created_at DESC")->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= $editData ? 'Edit Pengumuman' : 'Tambah Pengumuman' ?></h3></div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editData['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group full"><label>Judul Pengumuman <span class="req">*</span></label>
          <input type="text" name="title" maxlength="200" class="form-control" required value="<?= e($editData['title'] ?? '') ?>"></div>
        <div class="form-group full"><label>Isi Pengumuman <span class="req">*</span></label>
          <textarea name="content" class="form-control" required style="min-height:140px;"><?= e($editData['content'] ?? '') ?></textarea></div>
        <div class="form-group full">
          <label>Gambar Pengumuman (opsional)</label>
          <input type="file" name="image" class="form-control js-image-preview" data-preview-target="imgPreview" accept="image/*">
          <p class="form-hint">Poster / foto / tangkapan layar pengumuman. JPG, PNG, atau WEBP.</p>
          <img id="imgPreview" class="img-preview" style="display:<?= !empty($editData['image']) ? 'block' : 'none' ?>;" src="<?= uploadUrl($editData['image'] ?? null) ?>" alt="">
          <?php if (!empty($editData['image'])): ?>
            <label class="form-check"><input type="checkbox" name="remove_image" value="1"> Hapus gambar ini</label>
          <?php endif; ?>
        </div>
        <div class="form-group full">
          <label><input type="checkbox" name="is_active" value="1" <?= (!$editData || $editData['is_active']) ? 'checked' : '' ?>> Tampilkan di website</label>
        </div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <?php if ($editData): ?><a href="pengumuman.php" class="btn btn-outline">Batal Edit</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar Pengumuman</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($items) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-bullhorn"></i><p>Belum ada pengumuman.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Gambar</th><th>Judul</th><th>Status</th><th>Tanggal</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($items as $a): ?>
          <tr>
            <td><img src="<?= uploadUrl($a['image'] ?? null, 'assets/images/news-placeholder.jpg') ?>" class="thumb-sm" alt=""></td>
            <td><?= e($a['title']) ?></td>
            <td><?= $a['is_active'] ? '<span class="badge badge-success">Aktif</span>' : '<span class="badge badge-gray">Nonaktif</span>' ?></td>
            <td><?= tanggalIndo($a['created_at']) ?></td>
            <td class="actions"><div class="row-actions">
              <a href="pengumuman.php?edit=<?= (int)$a['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus pengumuman ini?')" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/../includes/functions.php';
$_SESSION = [];
session_unset();
session_destroy();
session_start();
setFlash('success', 'Anda telah berhasil logout.');
redirect('login.php');

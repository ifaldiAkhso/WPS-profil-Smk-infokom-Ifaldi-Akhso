<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Prestasi';
ensureAchievementColumns($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf() && ($_POST['action'] ?? '') === 'delete') {
    $pdo->prepare("DELETE FROM achievements WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
    setFlash('success', 'Prestasi berhasil dihapus.');
    redirect('prestasi.php');
}
$achievements = $pdo->query("SELECT * FROM achievements ORDER BY year DESC, created_at DESC")->fetchAll();
include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3>Daftar Prestasi</h3><a href="prestasi-form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Tambah Prestasi</a></div>
  <div class="card-body table-responsive">
    <?php if (count($achievements) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-trophy"></i><p>Belum ada data prestasi.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Foto</th><th>Judul</th><th>Tingkat</th><th>Tahun</th><th>Sumber</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($achievements as $a): ?>
          <tr>
            <td><img src="<?= uploadUrl($a['image'], 'assets/images/achievement-placeholder.jpg') ?>" class="thumb-sm"></td>
            <td><?= e($a['title']) ?></td>
            <td><?= e($a['level']) ?></td>
            <td><?= e((string)$a['year']) ?></td>
            <td><?php $aUrl = safeUrl($a['source_url'] ?? ''); ?><?php if ($aUrl !== ''): ?><a href="<?= e($aUrl) ?>" target="_blank" rel="noopener noreferrer"><?= e(trim((string)($a['source_name'] ?? '')) !== '' ? $a['source_name'] : urlHost($aUrl)) ?></a><?php else: ?><span class="form-hint">-</span><?php endif; ?></td>
            <td class="actions"><div class="row-actions">
              <a href="prestasi-form.php?id=<?= (int)$a['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus prestasi ini?')" style="display:inline;">
                <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

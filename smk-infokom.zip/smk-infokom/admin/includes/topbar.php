<div class="admin-main">
  <header class="admin-topbar">
    <div style="display:flex;align-items:center;gap:14px;">
      <button class="sidebar-toggle" id="sidebarToggle"><i class="fa-solid fa-bars"></i></button>
      <span class="topbar-title"><?= isset($pageTitle) ? e($pageTitle) : 'Dashboard' ?></span>
    </div>
    <div class="dropdown">
      <div class="topbar-user" id="userDropdown" style="cursor:pointer;">
        <img src="<?= uploadUrl($currentAdmin['photo'] ?? null, 'assets/images/avatar-placeholder.jpg') ?>" alt="Admin">
        <div>
          <div class="u-name"><?= e($currentAdmin['full_name']) ?></div>
          <div class="u-role"><?= e(ucfirst($currentAdmin['role'])) ?></div>
        </div>
        <i class="fa-solid fa-chevron-down" style="font-size:.7rem;color:var(--ink-500);"></i>
      </div>
      <div class="dropdown-menu" id="dropdownMenu">
        <a href="pengaturan.php"><i class="fa-solid fa-user-gear"></i> Pengaturan Akun</a>
        <a href="<?= BASE_URL ?>index.php" target="_blank"><i class="fa-solid fa-globe"></i> Lihat Website</a>
        <a href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</a>
      </div>
    </div>
  </header>
  <main class="admin-content">

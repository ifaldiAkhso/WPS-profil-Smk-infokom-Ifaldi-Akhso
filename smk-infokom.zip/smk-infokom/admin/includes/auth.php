<?php
/**
 * Proteksi halaman admin: wajib login sebelum mengakses dashboard.
 * Include file ini di baris paling atas setiap halaman admin (kecuali login.php).
 */
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/frontend-status.php';

if (empty($_SESSION['admin_id'])) {
    redirect('login.php');
}

// Session timeout 2 jam tidak aktif
$timeout = 2 * 60 * 60;
if (!empty($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity']) > $timeout) {
    session_unset();
    session_destroy();
    redirect('login.php?expired=1');
}
$_SESSION['admin_last_activity'] = time();

$currentAdmin = [
    'id' => $_SESSION['admin_id'],
    'username' => $_SESSION['admin_username'] ?? '',
    'full_name' => $_SESSION['admin_full_name'] ?? 'Admin',
    'photo' => $_SESSION['admin_photo'] ?? null,
    'role' => $_SESSION['admin_role'] ?? 'admin',
];

/* ------------------------------------------------------------------
 * PENJAGA TERPUSAT (berlaku untuk semua halaman admin)
 * ------------------------------------------------------------------ */

/** URL halaman admin yang sedang dibuka (tanpa domain), untuk redirect balik */
function currentAdminUrl(): string
{
    $q = $_SERVER['QUERY_STRING'] ?? '';
    return basename($_SERVER['SCRIPT_NAME']) . ($q !== '' ? '?' . $q : '');
}

// 1) Error database/PHP tidak lagi membuat halaman putih: tampilkan pesan yang jelas.
set_exception_handler(function (Throwable $e) {
    error_log('[ADMIN] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    $message = friendlyErrorMessage($e);
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && !headers_sent()) {
        setFlash('error', $message);
        redirect(currentAdminUrl());
    }
    if (!headers_sent()) http_response_code(500);
    echo '<div style="font-family:Arial,sans-serif;max-width:640px;margin:60px auto;padding:24px;border:1px solid #f1c0bd;'
       . 'background:#fff5f4;border-radius:12px;color:#7a1f1a"><h2 style="margin-top:0">Terjadi kesalahan</h2><p>'
       . e($message) . '</p><p><a href="dashboard.php">&larr; Kembali ke Dashboard</a></p></div>';
});

// 2) Form yang gagal dikirim tidak lagi "diam saja": beri tahu penyebabnya.
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $bodyTooBig = empty($_POST) && empty($_FILES) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0;
    if ($bodyTooBig) {
        setFlash('error', 'Data yang dikirim terlalu besar sehingga ditolak server (batas post_max_size = '
            . ini_get('post_max_size') . '). Kecilkan ukuran gambar atau unggah lebih sedikit foto sekaligus, lalu coba lagi.');
        redirect(currentAdminUrl());
    }
    if (!verifyCsrf()) {
        setFlash('error', 'Sesi formulir sudah kedaluwarsa, data belum tersimpan. Silakan ulangi aksi Anda.');
        redirect(currentAdminUrl());
    }
}

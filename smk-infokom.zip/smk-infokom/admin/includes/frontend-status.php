<?php
/**
 * =====================================================================
 *  DAFTAR "BELUM TAMPIL DI WEBSITE"  (ubah di file ini saja)
 * =====================================================================
 *  Dipakai untuk memberi tanda kuning "Belum di website" di menu & isian admin,
 *  supaya jelas mana yang sudah / belum punya tampilan di frontend.
 *
 *  Cara MENAMBAH tanda:
 *    1. Tambahkan baris di FRONTEND_PENDING_MENU (untuk menu sidebar) atau
 *       FRONTEND_PENDING_FIELD (untuk satu isian form).
 *    2. Menu sidebar otomatis bertanda. Untuk isian form, tulis
 *       <?= pendingTag('profil.school_name') ?> di dalam <label> isian itu.
 *
 *  Cara MENGHAPUS tanda (setelah frontend selesai): hapus barisnya dari daftar di bawah.
 *
 *  Hasil audit terakhir: Okt 2026.
 */

/* Menu admin yang halaman publiknya ada, tetapi BELUM punya menu di navbar website. */
const FRONTEND_PENDING_MENU = [];

/* Isian form yang tersimpan di database tetapi BELUM dipakai di tampilan website. Format: 'halaman.kolom' => catatan. */
const FRONTEND_PENDING_FIELD = [];

/** Tanda kecil untuk isian form. Contoh: <label>Nama Sekolah <?= pendingTag('profil.school_name') ?></label> */
function pendingTag(string $key): string
{
    $note = FRONTEND_PENDING_FIELD[$key] ?? null;
    if ($note === null) return '';
    return '<span class="tag-pending" title="' . e($note) . '"><i class="fa-solid fa-eye-slash"></i> Belum di website</span>';
}

/** Tanda kecil untuk menu sidebar (otomatis dari FRONTEND_PENDING_MENU). */
function pendingMenuTag(string $file): string
{
    $note = FRONTEND_PENDING_MENU[$file] ?? null;
    if ($note === null) return '';
    return '<span class="tag-pending tag-pending-dot" title="' . e($note) . '" aria-label="Belum ada menu di website"></span>';
}

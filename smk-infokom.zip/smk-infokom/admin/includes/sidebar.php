<?php
$current = basename($_SERVER['SCRIPT_NAME']);
$sidebarSchoolProfile = schoolProfile();
?>
<aside class="admin-sidebar" id="adminSidebar">
  <div class="sidebar-brand">
    <img src="<?= uploadUrl($sidebarSchoolProfile['logo'] ?? null, 'assets/images/logo-smk-infokom.png') ?>" alt="Logo">
    <span>SMK INFOKOM<br><small>BOGOR &middot; Admin</small></span>
  </div>
  <nav class="sidebar-nav">
    <a href="dashboard.php" class="<?= $current === 'dashboard.php' ? 'active' : '' ?>"><i class="fa-solid fa-gauge"></i> Dashboard</a>

    <div class="nav-label">Profil Sekolah</div>
    <a href="profil.php" class="<?= $current === 'profil.php' ? 'active' : '' ?>"><i class="fa-solid fa-school"></i> Profil &amp; Sambutan</a>
    <a href="struktur.php" class="<?= $current === 'struktur.php' ? 'active' : '' ?>"><i class="fa-solid fa-sitemap"></i> Struktur Organisasi</a>
    <a href="guru-staff.php" class="<?= $current === 'guru-staff.php' ? 'active' : '' ?>"><i class="fa-solid fa-chalkboard-user"></i> Guru &amp; Staff</a>
    <a href="fasilitas.php" class="<?= $current === 'fasilitas.php' ? 'active' : '' ?>"><i class="fa-solid fa-building"></i> Fasilitas</a>

    <div class="nav-label">Akademik</div>
    <a href="program.php" class="<?= in_array($current,['program.php','program-form.php']) ? 'active' : '' ?>"><i class="fa-solid fa-layer-group"></i> Program Keahlian</a>
    <a href="akademik.php" class="<?= $current === 'akademik.php' ? 'active' : '' ?>"><i class="fa-solid fa-book-open"></i> Kurikulum &amp; Kalender</a>
    <a href="pkl.php" class="<?= $current === 'pkl.php' ? 'active' : '' ?>"><i class="fa-solid fa-user-clock"></i> Konten PKL</a>

    <div class="nav-label">Kesiswaan</div>
    <a href="kesiswaan-ekstrakurikuler.php" class="<?= in_array($current,['kesiswaan-ekstrakurikuler.php','kesiswaan-ekstrakurikuler-form.php']) ? 'active' : '' ?>"><i class="fa-solid fa-person-running"></i> Ekstrakurikuler</a>
    <a href="kesiswaan-tata-tertib.php" class="<?= $current === 'kesiswaan-tata-tertib.php' ? 'active' : '' ?>"><i class="fa-solid fa-scale-balanced"></i> Tata Tertib</a>
    <a href="prestasi.php" class="<?= in_array($current,['prestasi.php','prestasi-form.php']) ? 'active' : '' ?>"><i class="fa-solid fa-trophy"></i> Prestasi Sekolah</a>

    <div class="nav-label">Informasi &amp; Berita</div>
    <a href="berita.php" class="<?= in_array($current,['berita.php','berita-form.php']) ? 'active' : '' ?>"><i class="fa-solid fa-newspaper"></i> Berita</a>
    <a href="kunjungan-industri.php" class="<?= in_array($current,['kunjungan-industri.php','kunjungan-industri-form.php']) ? 'active' : '' ?>"><i class="fa-solid fa-industry"></i> Kunjungan Industri</a>
    <a href="galeri.php" class="<?= $current === 'galeri.php' ? 'active' : '' ?>"><i class="fa-solid fa-images"></i> Galeri</a>
    <a href="agenda.php" class="<?= $current === 'agenda.php' ? 'active' : '' ?>"><i class="fa-solid fa-calendar-days"></i> Agenda</a>
    <a href="pengumuman.php" class="<?= $current === 'pengumuman.php' ? 'active' : '' ?>"><i class="fa-solid fa-bullhorn"></i> Pengumuman</a>

    <div class="nav-label">BKK &amp; Magang Jepang</div>
    <a href="bkk.php" class="<?= $current === 'bkk.php' ? 'active' : '' ?>"><i class="fa-solid fa-building-user"></i> Profil BKK</a>
    <a href="bkk-lowongan.php" class="<?= in_array($current,['bkk-lowongan.php','bkk-lowongan-form.php']) ? 'active' : '' ?>"><i class="fa-solid fa-briefcase"></i> Lowongan Kerja</a>
    <a href="bkk-perusahaan.php" class="<?= in_array($current,['bkk-perusahaan.php','bkk-perusahaan-form.php']) ? 'active' : '' ?>"><i class="fa-solid fa-handshake"></i> Perusahaan Mitra</a>
    <a href="jepang-profil.php" class="<?= $current === 'jepang-profil.php' ? 'active' : '' ?>"><i class="fa-solid fa-earth-asia"></i> Profil Magang</a>
    <a href="jepang-persyaratan.php" class="<?= $current === 'jepang-persyaratan.php' ? 'active' : '' ?>"><i class="fa-solid fa-clipboard-check"></i> Persyaratan Magang</a>
    <a href="jepang-galeri.php" class="<?= in_array($current,['jepang-galeri.php','jepang-galeri-form.php']) ? 'active' : '' ?>"><i class="fa-solid fa-camera-retro"></i> Foto Siswa Magang</a>

    <div class="nav-label">PPDB</div>
    <a href="ppdb.php" class="<?= in_array($current,['ppdb.php','ppdb-detail.php']) ? 'active' : '' ?>"><i class="fa-solid fa-user-graduate"></i> Data Pendaftar</a>
    <a href="ppdb-pengaturan.php" class="<?= $current === 'ppdb-pengaturan.php' ? 'active' : '' ?>"><i class="fa-solid fa-sliders"></i> Pengaturan PPDB</a>
    <a href="ppdb-faq.php" class="<?= $current === 'ppdb-faq.php' ? 'active' : '' ?>"><i class="fa-solid fa-circle-question"></i> Ubah FAQ</a>

    <div class="nav-label">Lainnya</div>
    <a href="kontak.php" class="<?= $current === 'kontak.php' ? 'active' : '' ?>"><i class="fa-solid fa-envelope"></i> Pesan Masuk</a>
    <a href="pengaturan.php" class="<?= $current === 'pengaturan.php' ? 'active' : '' ?>"><i class="fa-solid fa-gear"></i> Pengaturan Admin</a>
    <a href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</a>

  </nav>
</aside>

<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Profil Sekolah';
ensureHistoryImageColumn($pdo);
ensureKabarSekolahColumn($pdo);

$profile = $pdo->query("SELECT * FROM school_profile ORDER BY id LIMIT 1")->fetch();
if (!$profile) {
    $pdo->exec("INSERT INTO school_profile (school_name) VALUES ('SMK INFOKOM BOGOR')");
    $profile = $pdo->query("SELECT * FROM school_profile ORDER BY id LIMIT 1")->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $section = $_POST['section'] ?? 'profile';

    /* ---------------- Profil Sekolah ---------------- */
    if ($section === 'profile') {
        $logoResult = handleImageUpload('logo', 'lainnya');
        $principalPhotoResult = handleImageUpload('principal_photo', 'lainnya');
        $historyImageResult = handleImageUpload('history_image', 'lainnya');

        $rawKabar = trim($_POST['kabar_video_url'] ?? '');
        $kabarValid = true;
        foreach (preg_split('~[\r\n,\s]+~', $rawKabar) as $kabarPart) {
            if ($kabarPart !== '' && youtubeId($kabarPart) === '') { $kabarValid = false; break; }
        }

        if (!$logoResult['ok']) {
            setFlash('error', $logoResult['message']);
        } elseif (!$principalPhotoResult['ok']) {
            setFlash('error', $principalPhotoResult['message']);
        } elseif (!$historyImageResult['ok']) {
            setFlash('error', $historyImageResult['message']);
        } elseif (!$kabarValid) {
            setFlash('error', 'Setiap link video Kabar Sekolah harus berupa link YouTube yang valid, contoh: https://www.youtube.com/watch?v=xxxxxxxxxxx.');
        } else {
            $logo = $logoResult['file'] ?? $profile['logo'];
            $principalPhoto = $principalPhotoResult['file'] ?? $profile['principal_photo'];
            $historyImage = $historyImageResult['file'] ?? $profile['history_image'];
            $f = fn(string $k): string => trim($_POST[$k] ?? '');

            $stmt = $pdo->prepare("UPDATE school_profile SET
                school_name=?, npsn=?, short_description=?, history=?, history_image=?, vision=?, mission=?, excellence=?,
                principal_name=?, principal_photo=?, principal_message=?, logo=?, address=?, phone=?, email=?,
                operating_hours=?, map_embed=?, kabar_video_url=? WHERE id=?");
            $stmt->execute([
                $f('school_name'), $f('npsn'), $f('short_description'),
                $f('history'), $historyImage, $f('vision'), $f('mission'), $f('excellence'),
                $f('principal_name'), $principalPhoto, $f('principal_message'),
                $logo, $f('address'), $f('phone'), $f('email'),
                $f('operating_hours'), $f('map_embed'), $rawKabar ?: null, $profile['id'],
            ]);
            setFlash('success', 'Profil sekolah berhasil diperbarui.');
            redirect('profil.php');
        }
        $profile = $pdo->query("SELECT * FROM school_profile ORDER BY id LIMIT 1")->fetch();

    /* ---------------- Banner / Slider ---------------- */
    } elseif ($section === 'banner') {
        $action = $_POST['action'] ?? '';
        if ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $upload = handleImageUpload('image', 'lainnya');
            if (!$upload['ok']) {
                setFlash('error', $upload['message']);
            } elseif ($title === '') {
                setFlash('error', 'Judul banner wajib diisi.');
            } elseif ($id === 0 && empty($upload['file'])) {
                setFlash('error', 'Gambar banner wajib diunggah.');
            } else {
                $isActive = isset($_POST['is_active']) ? 1 : 0;
                $sortOrder = (int)($_POST['sort_order'] ?? 0);
                $subtitle = trim($_POST['subtitle'] ?? '');
                if ($id > 0) {
                    $existing = $pdo->prepare("SELECT image FROM banners WHERE id=?");
                    $existing->execute([$id]);
                    $image = $upload['file'] ?? $existing->fetchColumn();
                    $pdo->prepare("UPDATE banners SET title=?, subtitle=?, image=?, is_active=?, sort_order=? WHERE id=?")
                        ->execute([$title, $subtitle, $image, $isActive, $sortOrder, $id]);
                    setFlash('success', 'Banner berhasil diperbarui.');
                } else {
                    $pdo->prepare("INSERT INTO banners (title, subtitle, image, is_active, sort_order) VALUES (?,?,?,?,?)")
                        ->execute([$title, $subtitle, $upload['file'], $isActive, $sortOrder]);
                    setFlash('success', 'Banner berhasil ditambahkan.');
                }
            }
        } elseif ($action === 'delete') {
            $pdo->prepare("DELETE FROM banners WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
            setFlash('success', 'Banner berhasil dihapus.');
        }
        redirect('profil.php#banner');

    /* ---------------- Statistik Sekolah ---------------- */
    } elseif ($section === 'statistik') {
        $action = $_POST['action'] ?? '';
        if ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $label = trim($_POST['label'] ?? '');
            if ($label === '') {
                setFlash('error', 'Label statistik wajib diisi.');
            } else {
                $value = max(0, (int)($_POST['value'] ?? 0));
                $suffix = trim($_POST['suffix'] ?? '');
                $icon = trim($_POST['icon'] ?? '') ?: 'fa-solid fa-chart-simple';
                $sortOrder = (int)($_POST['sort_order'] ?? 0);
                if ($id > 0) {
                    $pdo->prepare("UPDATE school_statistics SET label=?, value=?, suffix=?, icon=?, sort_order=? WHERE id=?")
                        ->execute([$label, $value, $suffix, $icon, $sortOrder, $id]);
                    setFlash('success', 'Statistik berhasil diperbarui.');
                } else {
                    $pdo->prepare("INSERT INTO school_statistics (label, value, suffix, icon, sort_order) VALUES (?,?,?,?,?)")
                        ->execute([$label, $value, $suffix, $icon, $sortOrder]);
                    setFlash('success', 'Statistik berhasil ditambahkan.');
                }
            }
        } elseif ($action === 'delete') {
            $pdo->prepare("DELETE FROM school_statistics WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
            setFlash('success', 'Statistik berhasil dihapus.');
        }
        redirect('profil.php#statistik');

    /* ---------------- Sosial Media ---------------- */
    } elseif ($section === 'social') {
        $action = $_POST['action'] ?? '';
        if ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $platform = trim($_POST['platform'] ?? '');
            $url = trim($_POST['url'] ?? '');
            if ($platform === '' || $url === '') {
                setFlash('error', 'Platform dan link wajib diisi.');
            } else {
                $icon = trim($_POST['icon'] ?? '') ?: 'fa-solid fa-link';
                $sortOrder = (int)($_POST['sort_order'] ?? 0);
                if ($id > 0) {
                    $pdo->prepare("UPDATE social_media SET platform=?, url=?, icon=?, sort_order=? WHERE id=?")
                        ->execute([$platform, $url, $icon, $sortOrder, $id]);
                    setFlash('success', 'Sosial media berhasil diperbarui.');
                } else {
                    $pdo->prepare("INSERT INTO social_media (platform, url, icon, sort_order) VALUES (?,?,?,?)")
                        ->execute([$platform, $url, $icon, $sortOrder]);
                    setFlash('success', 'Sosial media berhasil ditambahkan.');
                }
            }
        } elseif ($action === 'delete') {
            $pdo->prepare("DELETE FROM social_media WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
            setFlash('success', 'Sosial media berhasil dihapus.');
        }
        redirect('profil.php#social');
    }
}

// Data untuk bagian Banner/Slider & Statistik (ditampilkan paling bawah, setelah Google Maps)
$editBanner = null;
if (!empty($_GET['edit_banner'])) {
    $stmt = $pdo->prepare("SELECT * FROM banners WHERE id=?");
    $stmt->execute([(int)$_GET['edit_banner']]);
    $editBanner = $stmt->fetch() ?: null;
}
$editStat = null;
if (!empty($_GET['edit_stat'])) {
    $stmt = $pdo->prepare("SELECT * FROM school_statistics WHERE id=?");
    $stmt->execute([(int)$_GET['edit_stat']]);
    $editStat = $stmt->fetch() ?: null;
}
$banners = $pdo->query("SELECT * FROM banners ORDER BY sort_order ASC, id ASC")->fetchAll();
$stats = $pdo->query("SELECT * FROM school_statistics ORDER BY sort_order ASC, id ASC")->fetchAll();

$editSocial = null;
if (!empty($_GET['edit_social'])) {
    $stmt = $pdo->prepare("SELECT * FROM social_media WHERE id=?");
    $stmt->execute([(int)$_GET['edit_social']]);
    $editSocial = $stmt->fetch() ?: null;
}
$socialList = $pdo->query("SELECT * FROM social_media ORDER BY sort_order ASC, id ASC")->fetchAll();
$socialIconSuggestions = ['fa-brands fa-instagram', 'fa-brands fa-facebook-f', 'fa-brands fa-youtube', 'fa-brands fa-tiktok', 'fa-brands fa-whatsapp', 'fa-brands fa-x-twitter'];

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<form method="post" enctype="multipart/form-data">
  <?= csrfField() ?>
  <input type="hidden" name="section" value="profile">

  <div class="card">
    <div class="card-header"><h3>Identitas Sekolah</h3></div>
    <div class="card-body">
      <div class="form-grid">
        <div class="form-group"><label>Nama Sekolah <span class="req">*</span></label><input type="text" name="school_name" maxlength="150" class="form-control" required value="<?= e($profile['school_name']) ?>"></div>
        <div class="form-group"><label>NPSN</label><input type="text" name="npsn" maxlength="20" class="form-control" value="<?= e($profile['npsn']) ?>"></div>
        <div class="form-group full"><label>Deskripsi Singkat</label><textarea name="short_description" class="form-control"><?= e($profile['short_description']) ?></textarea></div>
        <div class="form-group">
          <label>Logo Sekolah</label>
          <input type="file" name="logo" class="form-control js-image-preview" data-preview-target="logoPreview" accept="image/*">
          <img id="logoPreview" class="img-preview" src="<?= uploadUrl($profile['logo'], 'assets/images/logo-smk-infokom.png') ?>" style="display:block;max-width:120px;">
        </div>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><h3>Sejarah, Visi, Misi & Keunggulan</h3></div>
    <div class="card-body">
      <div class="form-group full"><label>Sejarah Sekolah</label><textarea name="history" class="form-control" style="min-height:140px;"><?= e($profile['history']) ?></textarea></div>
      <div class="form-group">
        <label>Foto Halaman Sejarah</label>
        <input type="file" name="history_image" class="form-control js-image-preview" data-preview-target="historyImagePreview" accept="image/*">
        <img id="historyImagePreview" class="img-preview" src="<?= uploadUrl($profile['history_image'] ?? null, 'assets/images/profile-school-building.jpg') ?>" style="display:block;max-width:220px;">
      </div>
      <div class="form-group full"><label>Visi</label><textarea name="vision" class="form-control"><?= e($profile['vision']) ?></textarea></div>
      <div class="form-group full"><label>Misi <span class="form-hint">(satu poin per baris)</span></label><textarea name="mission" class="form-control" style="min-height:120px;"><?= e($profile['mission']) ?></textarea></div>
      <div class="form-group full"><label>Keunggulan Sekolah</label><textarea name="excellence" class="form-control"><?= e($profile['excellence']) ?></textarea></div>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><h3>Sambutan Kepala Sekolah</h3></div>
    <div class="card-body">
      <div class="form-grid">
        <div class="form-group"><label>Nama Kepala Sekolah</label><input type="text" name="principal_name" maxlength="100" class="form-control" value="<?= e($profile['principal_name']) ?>"></div>
        <div class="form-group">
          <label>Foto Kepala Sekolah</label>
          <input type="file" name="principal_photo" class="form-control js-image-preview" data-preview-target="principalPreview" accept="image/*">
          <img id="principalPreview" class="img-preview" src="<?= uploadUrl($profile['principal_photo'], 'assets/images/principal-placeholder.jpg') ?>" style="display:block;">
        </div>
        <div class="form-group full"><label>Isi Sambutan</label><textarea name="principal_message" class="form-control" style="min-height:120px;"><?= e($profile['principal_message']) ?></textarea></div>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><h3>Kontak & Lokasi</h3></div>
    <div class="card-body">
      <div class="form-grid">
        <div class="form-group full"><label>Alamat</label><textarea name="address" maxlength="255" class="form-control"><?= e($profile['address']) ?></textarea></div>
        <div class="form-group"><label>Telepon</label><input type="text" name="phone" maxlength="50" class="form-control" value="<?= e($profile['phone']) ?>"></div>
        <div class="form-group"><label>Email</label><input type="email" name="email" maxlength="100" class="form-control" value="<?= e($profile['email']) ?>"></div>
        <div class="form-group full"><label>Jam Operasional</label><input type="text" name="operating_hours" maxlength="150" class="form-control" value="<?= e($profile['operating_hours']) ?>"></div>
        <div class="form-group full"><label>Embed Google Maps (opsional, kode iframe)</label><textarea name="map_embed" class="form-control" placeholder="<iframe src=...></iframe>"><?= e($profile['map_embed']) ?></textarea></div>
        <div class="form-group full"><label>Video Kabar Sekolah (link YouTube, satu link per baris)</label><textarea name="kabar_video_url" rows="4" maxlength="3000" class="form-control" placeholder="https://www.youtube.com/watch?v=xxxxxxxxxxx&#10;https://youtu.be/yyyyyyyyyyy"><?= e($profile['kabar_video_url'] ?? '') ?></textarea><p class="form-hint">Boleh lebih dari satu video (maksimal 10). Tampil sebagai bagian &ldquo;Kabar Sekolah&rdquo; di bagian paling bawah beranda dan bisa digeser ke samping. Kosongkan untuk menyembunyikan bagian ini.</p></div>
      </div>
    </div>
  </div>

  <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan</button>
</form>

<!-- ================= BANNER / SLIDER (dipindahkan dari menu terpisah) ================= -->
<div class="card" id="banner" style="margin-top:28px;scroll-margin-top:90px;">
  <div class="card-header"><h3><i class="fa-solid fa-panorama"></i> <?= $editBanner ? 'Edit Banner / Slider' : 'Tambah Banner / Slider' ?></h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Banner tampil sebagai slide utama di beranda website, diurutkan dari angka <b>Urutan</b> terkecil.</p>
    <form method="post" enctype="multipart/form-data" action="profil.php#banner">
      <?= csrfField() ?>
      <input type="hidden" name="section" value="banner">
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editBanner['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group"><label>Judul <span class="req">*</span></label><input type="text" name="title" maxlength="150" class="form-control" required value="<?= e($editBanner['title'] ?? '') ?>"></div>
        <div class="form-group"><label>Urutan</label><input type="number" name="sort_order" class="form-control" value="<?= (int)($editBanner['sort_order'] ?? 0) ?>"></div>
        <div class="form-group full"><label>Deskripsi</label><textarea name="subtitle" maxlength="255" class="form-control"><?= e($editBanner['subtitle'] ?? '') ?></textarea></div>
        <div class="form-group full">
          <label>Gambar Banner <?= $editBanner ? '' : '<span class="req">*</span>' ?></label>
          <input type="file" name="image" class="form-control js-image-preview" data-preview-target="bannerPreview" accept="image/*" <?= $editBanner ? '' : 'required' ?>>
          <img id="bannerPreview" class="img-preview" style="display:<?= !empty($editBanner['image']) ? 'block' : 'none' ?>;max-width:100%;height:200px;" src="<?= uploadUrl($editBanner['image'] ?? null) ?>" alt="Pratinjau banner">
        </div>
        <div class="form-group full">
          <label><input type="checkbox" name="is_active" value="1" <?= (!$editBanner || (int)$editBanner['is_active'] === 1) ? 'checked' : '' ?>> Tampilkan banner ini di beranda</label>
        </div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan Banner</button>
      <?php if ($editBanner): ?><a href="profil.php#banner" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar Banner</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($banners) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-panorama"></i><p>Belum ada banner.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Gambar</th><th>Judul</th><th>Urutan</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($banners as $b): ?>
          <tr>
            <td><img src="<?= uploadUrl($b['image']) ?>" class="thumb-sm" alt=""></td>
            <td><?= e($b['title']) ?></td>
            <td><?= (int)$b['sort_order'] ?></td>
            <td><?= $b['is_active'] ? '<span class="badge badge-success">Aktif</span>' : '<span class="badge badge-gray">Nonaktif</span>' ?></td>
            <td class="actions"><div class="row-actions">
              <a href="?edit_banner=<?= (int)$b['id'] ?>#banner" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" action="profil.php#banner" onsubmit="return confirm('Hapus banner ini?')" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="section" value="banner">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<!-- ================= STATISTIK SEKOLAH (dipindahkan dari menu terpisah) ================= -->
<div class="card" id="statistik" style="margin-top:28px;scroll-margin-top:90px;">
  <div class="card-header"><h3><i class="fa-solid fa-chart-simple"></i> <?= $editStat ? 'Edit Statistik' : 'Tambah Statistik' ?></h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Angka statistik tampil di beranda website (mis. jumlah siswa aktif, guru &amp; staff).</p>
    <form method="post" action="profil.php#statistik">
      <?= csrfField() ?>
      <input type="hidden" name="section" value="statistik">
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editStat['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group"><label>Label <span class="req">*</span></label><input type="text" name="label" maxlength="100" class="form-control" required placeholder="Siswa Aktif" value="<?= e($editStat['label'] ?? '') ?>"></div>
        <div class="form-group"><label>Nilai <span class="req">*</span></label><input type="number" name="value" min="0" class="form-control" required value="<?= (int)($editStat['value'] ?? 0) ?>"></div>
        <div class="form-group"><label>Suffix</label><input type="text" name="suffix" maxlength="10" class="form-control" value="<?= e($editStat['suffix'] ?? '+') ?>"></div>
        <div class="form-group"><label>Icon (Font Awesome class)</label><input type="text" name="icon" maxlength="50" class="form-control" placeholder="fa-solid fa-user-graduate" value="<?= e($editStat['icon'] ?? 'fa-solid fa-chart-simple') ?>"></div>
        <div class="form-group"><label>Urutan</label><input type="number" name="sort_order" class="form-control" value="<?= (int)($editStat['sort_order'] ?? 0) ?>"></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan Statistik</button>
      <?php if ($editStat): ?><a href="profil.php#statistik" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar Statistik</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($stats) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-chart-simple"></i><p>Belum ada data statistik.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Icon</th><th>Label</th><th>Nilai</th><th>Urutan</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($stats as $st): ?>
          <tr>
            <td style="width:50px;"><i class="<?= e($st['icon']) ?>" style="font-size:1.2rem;color:var(--navy-800);"></i></td>
            <td><?= e($st['label']) ?></td>
            <td><?= (int)$st['value'] . e($st['suffix']) ?></td>
            <td><?= (int)$st['sort_order'] ?></td>
            <td class="actions"><div class="row-actions">
              <a href="?edit_stat=<?= (int)$st['id'] ?>#statistik" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" action="profil.php#statistik" onsubmit="return confirm('Hapus statistik ini?')" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="section" value="statistik">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$st['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<!-- ================= SOSIAL MEDIA (tautan Instagram/Facebook/dll, tampil di footer & halaman Magang) ================= -->
<div class="card" id="social" style="margin-top:28px;scroll-margin-top:90px;">
  <div class="card-header"><h3><i class="fa-brands fa-instagram"></i> <?= $editSocial ? 'Edit Sosial Media' : 'Tambah Sosial Media' ?></h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Tautan sosial media tampil di footer seluruh halaman, dan Instagram juga ditampilkan sebagai tombol "Ikuti Instagram" di halaman <b>Program Magang</b>.</p>
    <form method="post" action="profil.php#social">
      <?= csrfField() ?>
      <input type="hidden" name="section" value="social">
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editSocial['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group"><label>Platform <span class="req">*</span></label><input type="text" name="platform" maxlength="50" class="form-control" required placeholder="Instagram" value="<?= e($editSocial['platform'] ?? '') ?>"></div>
        <div class="form-group"><label>Link <span class="req">*</span></label><input type="url" name="url" maxlength="255" class="form-control" required placeholder="https://instagram.com/smkinfokombogor" value="<?= e($editSocial['url'] ?? '') ?>"></div>
        <div class="form-group"><label>Icon (Font Awesome class)</label><input type="text" name="icon" list="socialIconOptions" maxlength="50" class="form-control" placeholder="fa-brands fa-instagram" value="<?= e($editSocial['icon'] ?? 'fa-brands fa-instagram') ?>"><datalist id="socialIconOptions"><?php foreach ($socialIconSuggestions as $opt): ?><option value="<?= e($opt) ?>"><?php endforeach; ?></datalist></div>
        <div class="form-group"><label>Urutan</label><input type="number" name="sort_order" class="form-control" value="<?= (int)($editSocial['sort_order'] ?? 0) ?>"></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan Sosial Media</button>
      <?php if ($editSocial): ?><a href="profil.php#social" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar Sosial Media</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($socialList) === 0): ?>
      <div class="empty-state"><i class="fa-brands fa-instagram"></i><p>Belum ada tautan sosial media.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Icon</th><th>Platform</th><th>Link</th><th>Urutan</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($socialList as $sm): ?>
          <tr>
            <td style="width:50px;"><i class="<?= e($sm['icon']) ?>" style="font-size:1.2rem;color:var(--navy-800);"></i></td>
            <td><?= e($sm['platform']) ?></td>
            <td><a href="<?= e($sm['url']) ?>" target="_blank" rel="noopener"><?= e(safeCut($sm['url'], 45)) ?></a></td>
            <td><?= (int)$sm['sort_order'] ?></td>
            <td class="actions"><div class="row-actions">
              <a href="?edit_social=<?= (int)$sm['id'] ?>#social" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" action="profil.php#social" onsubmit="return confirm('Hapus sosial media ini?')" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="section" value="social">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$sm['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
ensureNewsColumns($pdo);

$id = (int)($_GET['id'] ?? 0);
$news = null;
if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM news WHERE id=?");
    $stmt->execute([$id]);
    $news = $stmt->fetch();
    if (!$news) { setFlash('error', 'Berita tidak ditemukan.'); redirect('berita.php'); }
}
$pageTitle = $id > 0 ? 'Edit Berita' : 'Tulis Berita';
$categories = $pdo->query("SELECT * FROM news_categories ORDER BY name")->fetchAll();

$newsGalleryRows = [];
if ($news) {
    $gs = $pdo->prepare("SELECT * FROM news_gallery WHERE news_id = ? ORDER BY id");
    $gs->execute([$news['id']]);
    $newsGalleryRows = $gs->fetchAll();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        setFlash('error', 'Sesi formulir kedaluwarsa. Muat ulang halaman lalu coba lagi.');
    } else {
        $title = trim($_POST['title'] ?? '');
        $rawContent = trim($_POST['content'] ?? '');
        $rawSource = trim($_POST['source_url'] ?? '');
        $sourceUrl = safeUrl($rawSource);
        $upload = handleImageUpload('thumbnail', 'berita');
        if ($title === '' || $rawContent === '') {
            setFlash('error', 'Judul dan isi berita wajib diisi.');
        } elseif ($rawSource !== '' && $sourceUrl === '') {
            setFlash('error', 'Link sumber tidak valid. Gunakan alamat lengkap, contoh: https://www.contoh.com/berita.');
        } elseif (!$upload['ok']) {
            setFlash('error', $upload['message']);
        } elseif (!$news && empty($upload['file'])) {
            setFlash('error', 'Thumbnail wajib diunggah untuk berita baru.');
        } else {
            $status = ($_POST['status'] ?? '') === 'published' ? 'published' : 'draft';
            $categoryId = (int)($_POST['category_id'] ?? 0) ?: null;
            $excerpt = safeCut(trim($_POST['excerpt'] ?? ''), 300);
            $sourceName = safeCut(trim($_POST['source_name'] ?? ''), 150) ?: null;
            $sourceUrl = $sourceUrl ?: null;
            // tanggal terbit: dipertahankan bila sudah pernah terbit; berita draft yang baru dipublikasikan mendapat tanggal hari ini
            $publishedAt = $status === 'published' ? (($news['published_at'] ?? null) ?: date('Y-m-d H:i:s')) : null;

            if ($news) {
                $thumb = $upload['file'] ?? $news['thumbnail'];
                $pdo->prepare("UPDATE news SET category_id=?, title=?, thumbnail=?, excerpt=?, content=?, source_url=?, source_name=?, status=?, published_at=? WHERE id=?")
                    ->execute([$categoryId, $title, $thumb, $excerpt, $rawContent, $sourceUrl, $sourceName, $status, $publishedAt, $news['id']]);
                $newsId = (int)$news['id'];
                $msg = 'Berita berhasil diperbarui.';
            } else {
                $slug = uniqueSlug($pdo, 'news', slugify($title) . '-' . substr(uniqid(), -5));
                $pdo->prepare("INSERT INTO news (category_id, admin_id, title, slug, thumbnail, excerpt, content, source_url, source_name, status, published_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
                    ->execute([$categoryId, $currentAdmin['id'] ?? null, $title, $slug, $upload['file'], $excerpt, $rawContent, $sourceUrl, $sourceName, $status, $publishedAt]);
                $newsId = (int)$pdo->lastInsertId();
                $msg = 'Berita berhasil disimpan.';
            }

            // hapus foto galeri yang dicentang
            foreach ((array)($_POST['remove_gallery'] ?? []) as $gid) {
                $row = $pdo->prepare("SELECT image FROM news_gallery WHERE id=? AND news_id=?");
                $row->execute([(int)$gid, $newsId]);
                if ($img = $row->fetchColumn()) {
                    $pdo->prepare("DELETE FROM news_gallery WHERE id=? AND news_id=?")->execute([(int)$gid, $newsId]);
                    @unlink(BASE_PATH . '/assets/uploads/' . $img);
                }
            }
            // tambah foto galeri baru (boleh banyak sekaligus)
            $multi = handleMultiImageUpload('gallery', 'berita');
            foreach ($multi['files'] as $f) {
                $pdo->prepare("INSERT INTO news_gallery (news_id, image) VALUES (?,?)")->execute([$newsId, $f]);
            }
            if ($multi['errors']) $msg .= ' Namun sebagian foto galeri gagal: ' . implode('; ', $multi['errors']);
            setFlash($multi['errors'] ? 'error' : 'success', $msg);
            redirect('berita.php');
        }
    }
    // kembalikan isian agar tidak hilang saat validasi gagal
    $news = array_merge($news ?: [], [
        'title' => $_POST['title'] ?? '', 'content' => $_POST['content'] ?? '', 'excerpt' => $_POST['excerpt'] ?? '',
        'source_url' => $_POST['source_url'] ?? '', 'source_name' => $_POST['source_name'] ?? '',
        'status' => $_POST['status'] ?? 'draft', 'category_id' => (int)($_POST['category_id'] ?? 0),
    ]);
    $isEditing = $id > 0;
}
$isEditing = $isEditing ?? ($id > 0);

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= e($pageTitle) ?></h3></div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <div class="form-grid">
        <div class="form-group full"><label>Judul Berita <span class="req">*</span></label><input type="text" name="title" maxlength="200" class="form-control" required value="<?= e($news['title'] ?? '') ?>"></div>
        <div class="form-group">
          <label>Kategori</label>
          <select name="category_id" class="form-control">
            <option value="0">- Pilih Kategori -</option>
            <?php foreach ($categories as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= (int)($news['category_id'] ?? 0) === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Status</label>
          <select name="status" class="form-control">
            <option value="draft" <?= (($news['status'] ?? 'draft') === 'draft') ? 'selected' : '' ?>>Draft</option>
            <option value="published" <?= (($news['status'] ?? '') === 'published') ? 'selected' : '' ?>>Publish</option>
          </select>
        </div>
        <div class="form-group full"><label>Ringkasan Singkat</label><textarea name="excerpt" class="form-control" maxlength="300"><?= e($news['excerpt'] ?? '') ?></textarea></div>
        <div class="form-group full"><label>Isi Berita <span class="req">*</span></label>
          <textarea name="content" class="form-control" style="min-height:260px;" required><?= e($news['content'] ?? '') ?></textarea>
          <p class="form-hint">Tulis biasa saja: baris kosong = paragraf baru, dan alamat website (https://...) otomatis menjadi link yang bisa diklik. Tag HTML dasar (bold, list, link) juga boleh.</p>
        </div>
        <div class="form-group"><label>Link Sumber Berita (opsional)</label>
          <input type="text" name="source_url" maxlength="500" class="form-control" placeholder="https://www.contoh.com/artikel-berita" value="<?= e($news['source_url'] ?? '') ?>">
          <p class="form-hint">Tampil sebagai tombol yang bisa diklik di halaman berita.</p>
        </div>
        <div class="form-group"><label>Nama Sumber (opsional)</label>
          <input type="text" name="source_name" maxlength="150" class="form-control" placeholder="Contoh: Detik.com / Instagram SMK INFOKOM" value="<?= e($news['source_name'] ?? '') ?>">
          <p class="form-hint">Bila kosong, otomatis memakai nama domain dari link.</p>
        </div>
        <div class="form-group full">
          <label>Thumbnail <?= $id > 0 ? '' : '<span class="req">*</span>' ?></label>
          <input type="file" name="thumbnail" class="form-control js-image-preview" data-preview-target="imgPreview" accept="image/*" <?= $id > 0 ? '' : 'required' ?>>
          <p class="form-hint">Format JPG/PNG/WEBP. Paling pas <b>potret rasio 4:5</b> (mis. 1080 &times; 1350 px) seperti poster Instagram; foto besar otomatis dikecilkan.</p>
          <img id="imgPreview" class="img-preview" style="display:<?= !empty($news['thumbnail']) ? 'block' : 'none' ?>;" src="<?= uploadUrl($news['thumbnail'] ?? null) ?>">
        </div>
        <div class="form-group full">
          <label>Foto Galeri Berita (opsional, boleh pilih banyak)</label>
          <input type="file" name="gallery[]" class="form-control" accept="image/*" multiple>
          <?php if (count($newsGalleryRows) > 0): ?>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:10px;margin-top:12px;">
              <?php foreach ($newsGalleryRows as $g): ?>
                <label style="display:block;border:1px solid var(--line);border-radius:10px;overflow:hidden;font-size:.74rem;text-align:center;cursor:pointer;">
                  <img src="<?= uploadUrl($g['image']) ?>" style="width:100%;height:80px;object-fit:cover;display:block;" alt="">
                  <span style="display:block;padding:6px;"><input type="checkbox" name="remove_gallery[]" value="<?= (int)$g['id'] ?>"> Hapus</span>
                </label>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan Berita</button>
      <a href="berita.php" class="btn btn-outline">Batal</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

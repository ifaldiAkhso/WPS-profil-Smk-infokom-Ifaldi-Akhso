<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
ensureAchievementColumns($pdo);
$id = (int)($_GET['id'] ?? 0);
$item = null;
if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM achievements WHERE id=?"); $stmt->execute([$id]); $item = $stmt->fetch();
    if (!$item) { setFlash('error','Data tidak ditemukan.'); redirect('prestasi.php'); }
}
$pageTitle = $item ? 'Edit Prestasi' : 'Tambah Prestasi';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $upload = handleImageUpload('image', 'prestasi');
    $rawSource = trim($_POST['source_url'] ?? '');
    $sourceUrl = safeUrl($rawSource);
    $sourceName = safeCut(trim($_POST['source_name'] ?? ''), 150);
    if (!$upload['ok']) { setFlash('error', $upload['message']); }
    elseif ($rawSource !== '' && $sourceUrl === '') { setFlash('error', 'Link sumber tidak valid. Gunakan alamat lengkap, contoh: https://www.contoh.com/berita-prestasi.'); }
    else {
        if ($item) {
            $image = $upload['file'] ?? $item['image'];
            $stmt = $pdo->prepare("UPDATE achievements SET title=?, image=?, level=?, year=?, description=?, source_url=?, source_name=? WHERE id=?");
            $stmt->execute([trim($_POST['title'] ?? ''), $image, $_POST['level'], (int)($_POST['year'] ?? 0), trim($_POST['description'] ?? ''), $sourceUrl ?: null, $sourceName ?: null, $item['id']]);
            setFlash('success', 'Prestasi berhasil diperbarui.');
        } else {
            $stmt = $pdo->prepare("INSERT INTO achievements (title, image, level, year, description, source_url, source_name) VALUES (?,?,?,?,?,?,?)");
            $stmt->execute([trim($_POST['title'] ?? ''), $upload['file'], $_POST['level'], (int)($_POST['year'] ?? 0), trim($_POST['description'] ?? ''), $sourceUrl ?: null, $sourceName ?: null]);
            setFlash('success', 'Prestasi berhasil ditambahkan.');
        }
        redirect('prestasi.php');
    }
}
include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
$levels = ['Kabupaten/Kota','Provinsi','Nasional','Internasional'];
?>
<div class="card">
  <div class="card-header"><h3><?= e($pageTitle) ?></h3></div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <div class="form-grid">
        <div class="form-group full"><label>Judul Prestasi <span class="req">*</span></label><input type="text" name="title" maxlength="200" class="form-control" required value="<?= e($item['title'] ?? '') ?>"></div>
        <div class="form-group">
          <label>Tingkat</label>
          <select name="level" class="form-control">
            <?php foreach ($levels as $l): ?><option value="<?= $l ?>" <?= (($item['level'] ?? '') === $l) ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="form-group"><label>Tahun</label><input type="number" name="year" class="form-control" min="2000" max="2100" value="<?= e((string)($item['year'] ?? date('Y'))) ?>"></div>
        <div class="form-group full"><label>Keterangan</label><textarea name="description" class="form-control"><?= e($item['description'] ?? '') ?></textarea></div>
        <div class="form-group"><label>Link Sumber</label><input type="text" name="source_url" maxlength="500" class="form-control" placeholder="https://www.contoh.com/berita-prestasi" value="<?= e($item['source_url'] ?? '') ?>"><p class="form-hint">Tampil sebagai tautan &ldquo;Sumber&rdquo; yang bisa diklik pada kartu prestasi.</p></div>
        <div class="form-group"><label>Nama Sumber</label><input type="text" name="source_name" maxlength="150" class="form-control" placeholder="Contoh: Radar Bogor" value="<?= e($item['source_name'] ?? '') ?>"><p class="form-hint">Bila kosong, otomatis memakai nama domain dari link.</p></div>
        <div class="form-group full">
          <label>Foto</label>
          <input type="file" name="image" class="form-control js-image-preview" data-preview-target="imgPreview" accept="image/*">
          <img id="imgPreview" class="img-preview" style="display:<?= !empty($item['image']) ? 'block':'none' ?>;" src="<?= uploadUrl($item['image'] ?? null) ?>">
        </div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <a href="prestasi.php" class="btn btn-outline">Batal</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Pesan Masuk';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    if ($action === 'delete') {
        $pdo->prepare("DELETE FROM contact_messages WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Pesan berhasil dihapus.');
        redirect('kontak.php');
    } elseif ($action === 'read') {
        $pdo->prepare("UPDATE contact_messages SET is_read=1 WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        redirect('kontak.php?view=' . (int)($_POST['id'] ?? 0));
    }
}

$viewId = (int)($_GET['view'] ?? 0);
$viewData = null;
if ($viewId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM contact_messages WHERE id=?");
    $stmt->execute([$viewId]);
    $viewData = $stmt->fetch();
    if ($viewData && !$viewData['is_read']) {
        $pdo->prepare("UPDATE contact_messages SET is_read=1 WHERE id=?")->execute([$viewId]);
    }
}
$messages = $pdo->query("SELECT * FROM contact_messages ORDER BY created_at DESC")->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<?php if ($viewData): ?>
<div class="card">
  <div class="card-header">
    <h3>Detail Pesan</h3>
    <a href="kontak.php" class="btn btn-outline btn-sm"><i class="fa-solid fa-arrow-left"></i> Kembali</a>
  </div>
  <div class="card-body">
    <div class="detail-grid" style="margin-bottom:16px;">
      <div><span style="font-size:.78rem;color:var(--ink-500);">Nama</span><br><b><?= e($viewData['name']) ?></b></div>
      <div><span style="font-size:.78rem;color:var(--ink-500);">Email</span><br><b><?= e($viewData['email']) ?></b></div>
      <div><span style="font-size:.78rem;color:var(--ink-500);">No. HP</span><br><b><?= e($viewData['phone'] ?: '-') ?></b></div>
      <div><span style="font-size:.78rem;color:var(--ink-500);">Tanggal</span><br><b><?= tanggalIndo($viewData['created_at'], true) ?></b></div>
    </div>
    <p><b>Subjek:</b> <?= e($viewData['subject'] ?: '(Tanpa subjek)') ?></p>
    <div style="background:var(--bg-soft);padding:18px;border-radius:10px;"><?= nl2br(e($viewData['message'])) ?></div>
    <a href="mailto:<?= e($viewData['email']) ?>" class="btn btn-primary" style="margin-top:16px;"><i class="fa-solid fa-reply"></i> Balas via Email</a>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="card-header"><h3>Semua Pesan (<?= count($messages) ?>)</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($messages) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-envelope"></i><p>Belum ada pesan masuk.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th></th><th>Nama</th><th>Email</th><th>Subjek</th><th>Tanggal</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($messages as $m): ?>
          <tr style="<?= $m['is_read'] ? '' : 'font-weight:700;' ?>">
            <td><?= $m['is_read'] ? '' : '<span class="badge badge-info">Baru</span>' ?></td>
            <td><?= e($m['name']) ?></td>
            <td><?= e($m['email']) ?></td>
            <td><?= e($m['subject'] ?: '(Tanpa subjek)') ?></td>
            <td><?= tanggalIndo($m['created_at']) ?></td>
            <td class="actions"><div class="row-actions">
              <a href="kontak.php?view=<?= (int)$m['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Lihat" aria-label="Lihat"><i class="fa-solid fa-eye"></i></a>
              <form method="post" onsubmit="return confirm('Hapus pesan ini?')" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

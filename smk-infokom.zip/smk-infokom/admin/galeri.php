<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Galeri';
$jepangId = jepangGalleryCategoryId($pdo);   // kategori khusus foto magang: dikelola di menu "Foto Siswa Magang"

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'add') {
            // Boleh banyak foto sekaligus
            $multi = handleMultiImageUpload('images', 'galeri');
            $title = trim($_POST['title'] ?? '');
            $saved = 0;
            $ins = $pdo->prepare("INSERT INTO gallery (title, image) VALUES (?,?)");   // galeri umum: tanpa kategori
            foreach ($multi['files'] as $file) {
                $ins->execute([$title !== '' ? safeCut($title, 150) : null, $file]);
                $saved++;
            }
            if ($saved > 0 && !$multi['errors']) {
                setFlash('success', $saved . ' foto berhasil ditambahkan ke galeri.');
            } elseif ($saved > 0) {
                setFlash('error', $saved . ' foto tersimpan, tetapi ada yang gagal — ' . implode('; ', $multi['errors']));
            } elseif ($multi['errors']) {
                setFlash('error', implode('; ', $multi['errors']));
            } else {
                setFlash('error', 'Silakan pilih minimal satu gambar untuk diunggah.');
            }
        } elseif ($action === 'update') {
            $id = (int)($_POST['id'] ?? 0);
            $upload = handleImageUpload('image', 'galeri');
            if (!$upload['ok']) {
                setFlash('error', $upload['message']);
                redirect('galeri.php?edit=' . $id);
            }
            if (!empty($upload['file'])) {
                $pdo->prepare("UPDATE gallery SET title=?, image=? WHERE id=? AND (category_id IS NULL OR category_id <> ?)")
                    ->execute([safeCut(trim($_POST['title'] ?? ''), 150) ?: null, $upload['file'], $id, $jepangId]);
            } else {
                $pdo->prepare("UPDATE gallery SET title=? WHERE id=? AND (category_id IS NULL OR category_id <> ?)")
                    ->execute([safeCut(trim($_POST['title'] ?? ''), 150) ?: null, $id, $jepangId]);
            }
            setFlash('success', 'Foto galeri berhasil diperbarui.');
        } elseif ($action === 'delete') {
            // Foto Program Jepang tidak dihapus dari sini (ada di menu Foto Siswa Magang)
            $pdo->prepare("DELETE FROM gallery WHERE id=? AND (category_id IS NULL OR category_id <> ?)")->execute([(int)($_POST['id'] ?? 0), $jepangId]);
            setFlash('success', 'Foto berhasil dihapus.');
        }
    } catch (Throwable $e) {
        setFlash('error', friendlyErrorMessage($e));
    }
    redirect('galeri.php');
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM gallery WHERE id=? AND (category_id IS NULL OR category_id <> ?)");
    $stmt->execute([(int)$_GET['edit'], $jepangId]);
    $editItem = $stmt->fetch() ?: null;
}

$search = trim($_GET['q'] ?? '');
$where = [galleryPublicSql($pdo, 'g')];
$params = [];
if ($search !== '') { $where[] = '(g.title LIKE ?)'; $params[] = likeParam($search); }
$stmt = $pdo->prepare("SELECT g.* FROM gallery g WHERE " . implode(' AND ', $where) . " ORDER BY g.created_at DESC, g.id DESC");
$stmt->execute($params);
$gallery = $stmt->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= $editItem ? 'Edit Foto Galeri' : 'Unggah Foto Baru' ?></h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Galeri ini untuk dokumentasi kegiatan sekolah. Foto siswa magang ke Jepang <b>tidak</b> masuk ke sini — kelola di menu <a href="jepang-galeri.php"><b>Foto Siswa Magang</b></a> (hanya tampil di halaman Magang).</p>
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="<?= $editItem ? 'update' : 'add' ?>">
      <?php if ($editItem): ?><input type="hidden" name="id" value="<?= (int)$editItem['id'] ?>"><?php endif; ?>
      <div class="form-grid">
        <div class="form-group"><label>Judul (opsional)</label><input type="text" name="title" maxlength="150" class="form-control" value="<?= e($editItem['title'] ?? '') ?>"></div>
        <?php if ($editItem): ?>
          <div class="form-group full">
            <label>Ganti Gambar (opsional)</label>
            <input type="file" name="image" class="form-control js-image-preview" data-preview-target="imgPreview" accept="image/*">
            <img id="imgPreview" class="img-preview" src="<?= uploadUrl($editItem['image']) ?>" style="display:block;">
          </div>
        <?php else: ?>
          <div class="form-group full">
            <label>Gambar <span class="req">*</span> (boleh pilih beberapa sekaligus)</label>
            <input type="file" name="images[]" class="form-control" accept="image/*" multiple required>
            <p class="form-hint">Format JPG/PNG/WEBP. Foto besar dari HP otomatis dikecilkan. Judul di atas dipakai untuk semua foto yang dipilih.</p>
          </div>
        <?php endif; ?>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-<?= $editItem ? 'floppy-disk' : 'upload' ?>"></i> <?= $editItem ? 'Simpan Perubahan' : 'Unggah' ?></button>
      <?php if ($editItem): ?><a href="galeri.php" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Semua Foto Galeri (<?= count($gallery) ?>)</h3></div>
  <div class="card-body">
    <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px;">
      <input type="text" name="q" class="form-control" style="max-width:260px;" placeholder="Cari judul foto..." value="<?= e($search) ?>">
      <button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Cari</button>
      <?php if ($search !== ''): ?><a href="galeri.php" class="btn btn-outline btn-sm">Reset</a><?php endif; ?>
    </form>
    <?php if (count($gallery) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-images"></i><p>Belum ada foto galeri<?= $search !== '' ? ' yang sesuai pencarian' : '' ?>.</p></div>
    <?php else: ?>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:16px;">
        <?php foreach ($gallery as $g): ?>
          <div style="border:1px solid var(--admin-line);border-radius:12px;overflow:hidden;background:#fff;">
            <img src="<?= uploadUrl($g['image']) ?>" alt="" style="width:100%;height:120px;object-fit:cover;display:block;">
            <div style="padding:10px;">
              <div style="font-size:.78rem;font-weight:700;margin-bottom:2px;"><?= e($g['title'] ?: '(tanpa judul)') ?></div>
              <div style="margin-bottom:8px;"></div>
              <div style="display:flex;gap:6px;">
                <a href="?edit=<?= (int)$g['id'] ?>" class="btn btn-outline btn-sm" style="flex:1;"><i class="fa-solid fa-pen"></i> Edit</a>
                <form method="post" onsubmit="return confirm('Hapus foto ini?')" style="flex:1;display:flex;">
                  <?= csrfField() ?>
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= (int)$g['id'] ?>">
                  <button class="btn btn-danger btn-sm" style="width:100%;" type="submit"><i class="fa-solid fa-trash"></i></button>
                </form>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

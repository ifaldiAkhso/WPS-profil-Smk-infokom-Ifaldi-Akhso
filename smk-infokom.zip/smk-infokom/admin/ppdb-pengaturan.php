<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Pengaturan PPDB';
ensurePpdbInfoImageColumn($pdo);
ensurePpdbFormPdfColumn($pdo);

$settings = $pdo->query("SELECT * FROM ppdb_settings ORDER BY id DESC LIMIT 1")->fetch();
if (!$settings) {
    $pdo->exec("INSERT INTO ppdb_settings (academic_year, is_open) VALUES ('2026/2027', 1)");
    $settings = $pdo->query("SELECT * FROM ppdb_settings ORDER BY id DESC LIMIT 1")->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $upload = handleImageUpload('info_image', 'ppdb');
    $pdfUpload = handlePdfUpload('form_pdf', 'ppdb');
    if (!$upload['ok']) {
        setFlash('error', $upload['message']);
    } elseif (!$pdfUpload['ok']) {
        setFlash('error', $pdfUpload['message']);
    } else {
        $removePdf = !empty($_POST['remove_form_pdf']);
        $formPdf = $pdfUpload['file'] ?? ($removePdf ? null : ($settings['form_pdf'] ?? null));
        $formPdfLabel = trim($_POST['form_pdf_label'] ?? '');
        $removeImage = !empty($_POST['remove_info_image']);
        $infoImage = $upload['file'] ?? ($removeImage ? null : ($settings['info_image'] ?? null));
        $stmt = $pdo->prepare("UPDATE ppdb_settings SET academic_year=?, is_open=?, start_date=?, end_date=?, requirements=?, info_image=?, form_pdf=?, form_pdf_label=?, flow=? WHERE id=?");
        $stmt->execute([
            trim($_POST['academic_year'] ?? ''),
            isset($_POST['is_open']) ? 1 : 0,
            $_POST['start_date'] ?: null,
            $_POST['end_date'] ?: null,
            $_POST['requirements'],
            $infoImage,
            $formPdf,
            $formPdfLabel !== '' ? mb_substr($formPdfLabel, 0, 150) : null,
            $_POST['flow'],
            $settings['id'],
        ]);
        setFlash('success', 'Pengaturan PPDB berhasil disimpan.');
        redirect('ppdb-pengaturan.php');
    }
}

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3>Pengaturan PPDB</h3></div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <div class="form-grid">
        <div class="form-group"><label>Tahun Ajaran</label>
          <input type="text" name="academic_year" maxlength="20" class="form-control" value="<?= e($settings['academic_year']) ?>"></div>
        <div class="form-group"><label>Status Pendaftaran</label>
          <label style="display:flex;align-items:center;gap:8px;font-weight:400;padding-top:10px;">
            <input type="checkbox" name="is_open" value="1" <?= $settings['is_open'] ? 'checked' : '' ?>> PPDB dibuka untuk pendaftaran
          </label>
        </div>
        <div class="form-group"><label>Tanggal Mulai</label>
          <input type="date" name="start_date" class="form-control" value="<?= e($settings['start_date']) ?>"></div>
        <div class="form-group"><label>Tanggal Selesai</label>
          <input type="date" name="end_date" class="form-control" value="<?= e($settings['end_date']) ?>"></div>
        <div class="form-group full">
          <label>Gambar Informasi PPDB</label>
          <input type="file" name="info_image" class="form-control js-image-preview" data-preview-target="infoImagePreview" accept="image/*">
          <p class="form-hint">Unggah satu gambar/poster berisi info persyaratan &amp; alur PPDB. Jika diisi, gambar ini akan ditampilkan di halaman PPDB menggantikan teks persyaratan di bawah.</p>
          <img id="infoImagePreview" class="img-preview" style="display:<?= !empty($settings['info_image']) ? 'block' : 'none' ?>;max-width:320px;" src="<?= uploadUrl($settings['info_image'] ?? null) ?>">
          <?php if (!empty($settings['info_image'])): ?>
            <label style="display:flex;align-items:center;gap:8px;font-weight:400;margin-top:8px;">
              <input type="checkbox" name="remove_info_image" value="1"> Hapus gambar ini
            </label>
          <?php endif; ?>
        </div>
        <div class="form-group full">
          <label>File PDF Formulir / Panduan Pendaftaran</label>
          <input type="file" name="form_pdf" class="form-control" accept="application/pdf,.pdf">
          <p class="form-hint">Opsional. Unggah satu file PDF (maks. 10MB). Akan tampil sebagai tombol unduh di bawah tombol "Kirim Formulir Pendaftaran" pada halaman formulir.</p>
          <input type="text" name="form_pdf_label" maxlength="150" class="form-control" style="margin-top:8px;" placeholder="Teks tombol (contoh: Unduh Brosur PPDB)" value="<?= e($settings['form_pdf_label'] ?? '') ?>">
          <?php if (!empty($settings['form_pdf'])): ?>
            <p class="form-hint" style="margin-top:8px;">File saat ini: <a href="<?= uploadUrl($settings['form_pdf']) ?>" target="_blank" rel="noopener"><?= e(basename($settings['form_pdf'])) ?></a></p>
            <label style="display:flex;align-items:center;gap:8px;font-weight:400;margin-top:4px;">
              <input type="checkbox" name="remove_form_pdf" value="1"> Hapus file PDF ini
            </label>
          <?php endif; ?>
        </div>
        <div class="form-group full"><label>Persyaratan Pendaftaran (teks cadangan bila gambar tidak diisi)</label>
          <textarea name="requirements" class="form-control" style="min-height:120px;"><?= e($settings['requirements']) ?></textarea>
          <p class="form-hint">Satu baris = satu poin persyaratan.</p></div>
        <div class="form-group full"><label>Alur Pendaftaran</label>
          <textarea name="flow" class="form-control" style="min-height:120px;"><?= e($settings['flow']) ?></textarea>
          <p class="form-hint">Satu baris = satu langkah alur pendaftaran.</p></div>
        <div class="form-group full"><label>FAQ (Pertanyaan Umum)</label>
          <p class="form-hint" style="margin-top:0;">FAQ kini dikelola satu per satu di menu khusus.</p>
          <a href="ppdb-faq.php" class="btn btn-outline"><i class="fa-solid fa-circle-question"></i> Ubah FAQ</a></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan Pengaturan</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

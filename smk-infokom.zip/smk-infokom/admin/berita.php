<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
ensureNewsColumns($pdo);
$pageTitle = 'Berita';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'delete') {
            $pdo->prepare("DELETE FROM news WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
            setFlash('success', 'Berita berhasil dihapus.');
        } elseif ($action === 'cat_save') {
            $catId = (int)($_POST['cat_id'] ?? 0);
            $name = safeCut(trim($_POST['cat_name'] ?? ''), 100);
            if ($name === '') {
                setFlash('error', 'Nama kategori wajib diisi.');
            } elseif ($catId > 0) {
                $pdo->prepare("UPDATE news_categories SET name=?, slug=? WHERE id=?")->execute([$name, uniqueCategorySlug($pdo, 'news_categories', $name, $catId), $catId]);
                setFlash('success', 'Kategori berita berhasil diperbarui.');
            } else {
                $pdo->prepare("INSERT INTO news_categories (name, slug) VALUES (?,?)")->execute([$name, uniqueCategorySlug($pdo, 'news_categories', $name)]);
                setFlash('success', 'Kategori berita berhasil ditambahkan.');
            }
        } elseif ($action === 'cat_delete') {
            $pdo->prepare("DELETE FROM news_categories WHERE id=?")->execute([(int)($_POST['cat_id'] ?? 0)]);   // berita di dalamnya jadi tanpa kategori
            setFlash('success', 'Kategori dihapus. Berita di dalamnya menjadi tanpa kategori.');
        }
    } catch (Throwable $e) {
        setFlash('error', friendlyErrorMessage($e));
    }
    redirect('berita.php');
}

$newsCategories = $pdo->query("SELECT c.*, (SELECT COUNT(*) FROM news n WHERE n.category_id = c.id) AS total FROM news_categories c ORDER BY c.name")->fetchAll();
$editCat = null;
if (!empty($_GET['edit_cat'])) {
    foreach ($newsCategories as $c) { if ((int)$c['id'] === (int)$_GET['edit_cat']) { $editCat = $c; break; } }
}

$search = trim($_GET['q'] ?? '');
$filterStatus = $_GET['status'] ?? '';
$filterCat = (int)($_GET['kategori'] ?? 0);
$where = [];
$params = [];
if ($search !== '') { $where[] = "(n.title LIKE ? OR n.excerpt LIKE ?)"; $like = likeParam($search); array_push($params, $like, $like); }
if (in_array($filterStatus, ['draft', 'published'], true)) { $where[] = "n.status = ?"; $params[] = $filterStatus; }
if ($filterCat > 0) { $where[] = "n.category_id = ?"; $params[] = $filterCat; }
$sql = "SELECT n.*, c.name AS category_name FROM news n LEFT JOIN news_categories c ON c.id=n.category_id"
     . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . " ORDER BY n.created_at DESC, n.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$newsList = $stmt->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header">
    <h3>Daftar Berita</h3>
    <a href="berita-form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Tulis Berita</a>
  </div>
  <div class="card-body">
    <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px;">
      <input type="text" name="q" class="form-control" style="max-width:260px;" placeholder="Cari judul / ringkasan berita..." value="<?= e($search) ?>">
      <select name="kategori" class="form-control" style="max-width:200px;" onchange="this.form.submit()">
        <option value="0">Semua kategori</option>
        <?php foreach ($newsCategories as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $filterCat === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
      </select>
      <select name="status" class="form-control" style="max-width:160px;" onchange="this.form.submit()">
        <option value="">Semua status</option>
        <option value="published" <?= $filterStatus === 'published' ? 'selected' : '' ?>>Publish</option>
        <option value="draft" <?= $filterStatus === 'draft' ? 'selected' : '' ?>>Draft</option>
      </select>
      <button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Cari</button>
      <?php if ($search !== '' || $filterCat > 0 || $filterStatus !== ''): ?><a href="berita.php" class="btn btn-outline btn-sm">Reset</a><?php endif; ?>
    </form>
    <div class="table-responsive">
    <?php if (count($newsList) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-newspaper"></i><p>Belum ada berita.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Thumbnail</th><th>Judul</th><th>Kategori</th><th>Status</th><th>Tanggal</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($newsList as $n): ?>
          <tr>
            <td><img src="<?= uploadUrl($n['thumbnail'], 'assets/images/news-placeholder.jpg') ?>" class="thumb-sm"></td>
            <td><?= e($n['title']) ?><?php if (!empty($n['source_url'])): ?> <a href="<?= e(safeUrl($n['source_url'])) ?>" target="_blank" rel="noopener noreferrer" title="Buka sumber" style="color:var(--navy-600);"><i class="fa-solid fa-link"></i></a><?php endif; ?></td>
            <td><?= e($n['category_name'] ?? '-') ?></td>
            <td><?= $n['status'] === 'published' ? '<span class="badge badge-success">Publish</span>' : '<span class="badge badge-warning">Draft</span>' ?></td>
            <td><?= tanggalIndo($n['created_at']) ?></td>
            <td class="actions"><div class="row-actions">
              <a href="<?= BASE_URL ?>detail-berita.php?slug=<?= urlencode($n['slug']) ?>" target="_blank" class="btn btn-outline btn-sm btn-icon" title="Lihat" aria-label="Lihat"><i class="fa-solid fa-eye"></i></a>
              <a href="berita-form.php?id=<?= (int)$n['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus berita ini?')" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$n['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
    </div>
  </div>
</div>
<div class="card">
  <div class="card-header"><h3>Kategori Berita</h3></div>
  <div class="card-body">
    <form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:16px;">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="cat_save">
      <input type="hidden" name="cat_id" value="<?= (int)($editCat['id'] ?? 0) ?>">
      <input type="text" name="cat_name" class="form-control" style="max-width:280px;" maxlength="100" required placeholder="Nama kategori baru" value="<?= e($editCat['name'] ?? '') ?>">
      <button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-<?= $editCat ? 'floppy-disk' : 'plus' ?>"></i> <?= $editCat ? 'Simpan Kategori' : 'Tambah Kategori' ?></button>
      <?php if ($editCat): ?><a href="berita.php" class="btn btn-outline btn-sm">Batal</a><?php endif; ?>
    </form>
    <div style="display:flex;flex-wrap:wrap;gap:10px;">
      <?php foreach ($newsCategories as $c): ?>
        <div style="display:flex;align-items:center;gap:8px;border:1px solid var(--admin-line);border-radius:999px;padding:6px 8px 6px 14px;background:#fbfdff;">
          <span style="font-size:.75rem;font-weight:700;"><?= e($c['name']) ?> <small style="color:var(--admin-muted);">(<?= (int)$c['total'] ?>)</small></span>
          <a href="?edit_cat=<?= (int)$c['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Ubah nama"><i class="fa-solid fa-pen"></i></a>
          <form method="post" onsubmit="return confirm('Hapus kategori ini? Berita di dalamnya menjadi tanpa kategori.')" style="display:inline;">
            <?= csrfField() ?><input type="hidden" name="action" value="cat_delete"><input type="hidden" name="cat_id" value="<?= (int)$c['id'] ?>">
            <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus kategori"><i class="fa-solid fa-trash"></i></button>
          </form>
        </div>
      <?php endforeach; ?>
      <?php if (count($newsCategories) === 0): ?><span class="form-hint">Belum ada kategori.</span><?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

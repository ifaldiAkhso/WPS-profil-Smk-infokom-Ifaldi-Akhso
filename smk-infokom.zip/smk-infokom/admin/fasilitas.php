<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Fasilitas Sekolah';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $upload = handleImageUpload('image', 'fasilitas');
        if (!$upload['ok']) { setFlash('error', $upload['message']); }
        else {
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                $existing = $pdo->prepare("SELECT image FROM facilities WHERE id=?"); $existing->execute([$id]);
                $image = $upload['file'] ?? $existing->fetchColumn();
                $stmt = $pdo->prepare("UPDATE facilities SET name=?, image=?, description=? WHERE id=?");
                $stmt->execute([trim($_POST['name'] ?? ''), $image, trim($_POST['description'] ?? ''), $id]);
                setFlash('success', 'Fasilitas berhasil diperbarui.');
            } else {
                $stmt = $pdo->prepare("INSERT INTO facilities (name, image, description, sort_order) VALUES (?,?,?,0)");
                $stmt->execute([trim($_POST['name'] ?? ''), $upload['file'], trim($_POST['description'] ?? '')]);
                setFlash('success', 'Fasilitas berhasil ditambahkan.');
            }
        }
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM facilities WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Fasilitas berhasil dihapus.');
    }
    redirect('fasilitas.php');
}

$editItem = null;
if (!empty($_GET['edit'])) { $stmt = $pdo->prepare("SELECT * FROM facilities WHERE id=?"); $stmt->execute([(int)$_GET['edit']]); $editItem = $stmt->fetch(); }
$facilities = $pdo->query("SELECT * FROM facilities ORDER BY sort_order")->fetchAll();
include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= $editItem ? 'Edit Fasilitas' : 'Tambah Fasilitas' ?></h3></div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editItem['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group full"><label>Nama Fasilitas <span class="req">*</span></label><input type="text" name="name" maxlength="150" class="form-control" required value="<?= e($editItem['name'] ?? '') ?>"></div>
        <div class="form-group full"><label>Deskripsi</label><textarea name="description" class="form-control"><?= e($editItem['description'] ?? '') ?></textarea></div>
        <div class="form-group full">
          <label>Foto</label>
          <input type="file" name="image" class="form-control js-image-preview" data-preview-target="imgPreview" accept="image/*">
          <img id="imgPreview" class="img-preview" style="display:<?= !empty($editItem['image']) ? 'block':'none' ?>;" src="<?= uploadUrl($editItem['image'] ?? null) ?>">
        </div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <?php if ($editItem): ?><a href="fasilitas.php" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar Fasilitas</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($facilities) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-building"></i><p>Belum ada data fasilitas.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Foto</th><th>Nama</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($facilities as $f): ?>
          <tr>
            <td><img src="<?= uploadUrl($f['image'], 'assets/images/facility-placeholder.jpg') ?>" class="thumb-sm"></td>
            <td><?= e($f['name']) ?></td>
            <td class="actions"><div class="row-actions">
              <a href="?edit=<?= (int)$f['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus fasilitas ini?')" style="display:inline;">
                <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

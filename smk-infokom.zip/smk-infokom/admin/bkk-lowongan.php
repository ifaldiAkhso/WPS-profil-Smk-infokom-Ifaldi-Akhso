<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Lowongan Kerja';
ensureBkkTables($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    if ($action === 'delete') {
        $pdo->prepare("DELETE FROM job_vacancies WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Lowongan kerja berhasil dihapus.');
        redirect('bkk-lowongan.php');
    } elseif ($action === 'toggle') {
        $pdo->prepare("UPDATE job_vacancies SET status = IF(status='aktif','ditutup','aktif') WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Status lowongan berhasil diperbarui.');
        redirect('bkk-lowongan.php');
    }
}

$search = trim($_GET['q'] ?? '');
$where = [];
$params = [];
if ($search !== '') { $where[] = "(jv.position LIKE ? OR jv.company_name LIKE ? OR c.name LIKE ?)"; array_push($params, "%$search%", "%$search%", "%$search%"); }
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
$stmt = $pdo->prepare("SELECT jv.*, jv.company_name AS company_name_free, c.name AS partner_name, c.logo AS company_logo, p.name AS program_name
                        FROM job_vacancies jv
                        LEFT JOIN partner_companies c ON c.id = jv.company_id
                        LEFT JOIN programs p ON p.id = jv.program_id
                        $whereSql ORDER BY jv.created_at DESC");
$stmt->execute($params);
$list = $stmt->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header">
    <h3>Daftar Lowongan Kerja</h3>
    <a href="bkk-lowongan-form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Tambah Lowongan</a>
  </div>
  <div class="card-body">
    <form method="get" class="filter-bar">
      <input type="text" name="q" class="form-control" placeholder="Cari posisi / perusahaan" value="<?= e($search) ?>">
      <button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Cari</button>
      <?php if ($search !== ''): ?><a href="bkk-lowongan.php" class="btn btn-outline btn-sm">Reset</a><?php endif; ?>
    </form>

    <div class="table-responsive" style="margin-top:18px;">
    <?php if (count($list) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-briefcase"></i><p>Belum ada data lowongan kerja.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Gambar</th><th>Posisi</th><th>Perusahaan</th><th>Jurusan</th><th>Lokasi</th><th>Batas</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($list as $jv): ?>
          <tr>
            <td><?php if (jobHasImage($jv)): ?><img src="<?= jobImageUrl($jv) ?>" class="thumb-sm" alt=""><?php else: ?><span class="muted">-</span><?php endif; ?></td>
            <td><?= e(jobTitle($jv)) ?></td>
            <td><?= e(jobCompanyName($jv) ?: '-') ?></td>
            <td><?= e($jv['program_name'] ?: 'Semua Jurusan') ?></td>
            <td><?= e($jv['location'] ?: '-') ?></td>
            <td><?= !empty($jv['deadline']) ? tanggalIndo($jv['deadline']) : '-' ?></td>
            <td>
              <form method="post" style="display:inline;">
                <?= csrfField() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$jv['id'] ?>">
                <button type="submit" class="badge <?= $jv['status'] === 'aktif' ? 'badge-success' : 'badge-gray' ?>" style="border:0;cursor:pointer;">
                  <?= $jv['status'] === 'aktif' ? 'Aktif' : 'Ditutup' ?>
                </button>
              </form>
            </td>
            <td class="actions"><div class="row-actions">
              <a href="<?= BASE_URL ?>bkk-lowongan-detail.php?id=<?= (int)$jv['id'] ?>" target="_blank" class="btn btn-outline btn-sm btn-icon" title="Lihat"><i class="fa-solid fa-eye"></i></a>
              <a href="bkk-lowongan-form.php?id=<?= (int)$jv['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus lowongan ini?')" style="display:inline;">
                <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$jv['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

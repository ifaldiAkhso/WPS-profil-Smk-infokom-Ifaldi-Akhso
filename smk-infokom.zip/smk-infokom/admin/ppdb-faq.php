<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Ubah FAQ PPDB';
ensurePpdbFaqTable($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $question = trim($_POST['question'] ?? '');
        $answer = trim($_POST['answer'] ?? '');
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $sort = (int)($_POST['sort_order'] ?? 0);
        if ($question === '') {
            setFlash('error', 'Pertanyaan wajib diisi.');
        } elseif ($id > 0) {
            $pdo->prepare("UPDATE ppdb_faqs SET question=?, answer=?, sort_order=?, is_active=? WHERE id=?")
                ->execute([mb_substr($question, 0, 255), $answer, $sort, $isActive, $id]);
            setFlash('success', 'FAQ berhasil diperbarui.');
        } else {
            if ($sort <= 0) $sort = (int)$pdo->query("SELECT COALESCE(MAX(sort_order),0)+1 FROM ppdb_faqs")->fetchColumn();
            $pdo->prepare("INSERT INTO ppdb_faqs (question, answer, sort_order, is_active) VALUES (?,?,?,?)")
                ->execute([mb_substr($question, 0, 255), $answer, $sort, $isActive]);
            setFlash('success', 'FAQ berhasil ditambahkan.');
        }
    } elseif ($action === 'toggle') {
        $pdo->prepare("UPDATE ppdb_faqs SET is_active = 1 - is_active WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Status tampil FAQ diubah.');
    } elseif ($action === 'move') {
        // Tukar urutan dengan FAQ di atas/bawahnya, lalu rapikan nomor urut 1..n
        $id = (int)($_POST['id'] ?? 0);
        $dir = ($_POST['dir'] ?? '') === 'up' ? -1 : 1;
        $ids = array_map('intval', array_column(ppdbFaqs($pdo, false), 'id'));
        $pos = array_search($id, $ids, true);
        if ($pos !== false && isset($ids[$pos + $dir])) {
            [$ids[$pos], $ids[$pos + $dir]] = [$ids[$pos + $dir], $ids[$pos]];
            $up = $pdo->prepare("UPDATE ppdb_faqs SET sort_order=? WHERE id=?");
            foreach ($ids as $i => $fid) $up->execute([$i + 1, $fid]);
        }
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM ppdb_faqs WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'FAQ berhasil dihapus.');
    }
    redirect('ppdb-faq.php');
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM ppdb_faqs WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editItem = $stmt->fetch() ?: null;
}
$items = ppdbFaqs($pdo, false);

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= $editItem ? 'Edit FAQ' : 'Tambah FAQ' ?></h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">FAQ tampil di halaman <b>PPDB</b> bagian "Pertanyaan seputar PPDB". Satu pertanyaan, satu jawaban.</p>
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editItem['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group full"><label>Pertanyaan <span class="req">*</span></label>
          <input type="text" name="question" class="form-control" required maxlength="255" placeholder="Contoh: Apa saja syarat mendaftar?" value="<?= e($editItem['question'] ?? '') ?>"></div>
        <div class="form-group full"><label>Jawaban</label>
          <textarea name="answer" class="form-control" style="min-height:120px;" placeholder="Tulis jawaban lengkap di sini"><?= e($editItem['answer'] ?? '') ?></textarea></div>
        <div class="form-group"><label>Urutan</label>
          <input type="number" name="sort_order" class="form-control" value="<?= (int)($editItem['sort_order'] ?? 0) ?>">
          <p class="form-hint">Kosongkan/0 untuk menaruh di paling bawah.</p></div>
        <div class="form-group"><label style="margin-top:28px;"><input type="checkbox" name="is_active" value="1" <?= (!$editItem || (int)$editItem['is_active'] === 1) ? 'checked' : '' ?>> Tampilkan di website</label></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <?php if ($editItem): ?><a href="ppdb-faq.php" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar FAQ (<?= count($items) ?>)</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($items) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-circle-question"></i><p>Belum ada FAQ. Tambahkan lewat form di atas.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Urutan</th><th>Pertanyaan</th><th>Jawaban</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($items as $it): ?>
          <tr>
            <td><?= (int)$it['sort_order'] ?></td>
            <td><?= e($it['question']) ?></td>
            <td><?= e(safeCut((string)$it['answer'], 80)) ?></td>
            <td><?= (int)$it['is_active'] === 1 ? '<span class="badge badge-success">Tampil</span>' : '<span class="badge badge-gray">Disembunyikan</span>' ?></td>
            <td class="actions"><div class="row-actions">
              <form method="post"><?= csrfField() ?><input type="hidden" name="action" value="move"><input type="hidden" name="id" value="<?= (int)$it['id'] ?>"><input type="hidden" name="dir" value="up">
                <button class="btn btn-outline btn-sm btn-icon" type="submit" title="Naik" aria-label="Naik"><i class="fa-solid fa-arrow-up"></i></button></form>
              <form method="post"><?= csrfField() ?><input type="hidden" name="action" value="move"><input type="hidden" name="id" value="<?= (int)$it['id'] ?>"><input type="hidden" name="dir" value="down">
                <button class="btn btn-outline btn-sm btn-icon" type="submit" title="Turun" aria-label="Turun"><i class="fa-solid fa-arrow-down"></i></button></form>
              <form method="post"><?= csrfField() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                <button class="btn btn-outline btn-sm btn-icon" type="submit" title="Tampil/Sembunyikan" aria-label="Tampil/Sembunyikan"><i class="fa-solid <?= (int)$it['is_active'] === 1 ? 'fa-eye-slash' : 'fa-eye' ?>"></i></button></form>
              <a href="?edit=<?= (int)$it['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus FAQ ini?')"><?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button></form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Kunjungan Industri';
ensureIndustryVisits($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $act = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    if ($act === 'delete') {
        $pdo->prepare("DELETE FROM industry_visits WHERE id=?")->execute([$id]);
        setFlash('success', 'Data kunjungan industri berhasil dihapus.');
    } elseif ($act === 'toggle') {
        $pdo->prepare("UPDATE industry_visits SET is_active = 1 - is_active WHERE id=?")->execute([$id]);
        setFlash('success', 'Status tampil diperbarui.');
    }
    redirect('kunjungan-industri.php');
}
$items = $pdo->query("SELECT * FROM industry_visits ORDER BY visit_date DESC, id DESC")->fetchAll();
include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3>Daftar Kunjungan Industri</h3><a href="kunjungan-industri-form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Tambah Kunjungan</a></div>
  <div class="card-body table-responsive">
    <?php if (count($items) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-industry"></i><p>Belum ada data kunjungan industri.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Foto</th><th>Judul</th><th>Perusahaan</th><th>Tanggal</th><th>Tampil</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($items as $v): ?>
          <tr>
            <td><img src="<?= uploadUrl($v['image'], 'assets/images/news-placeholder.jpg') ?>" class="thumb-sm" alt=""></td>
            <td><?= trim((string)$v['title']) !== '' ? e($v['title']) : '<em class="muted">-</em>' ?></td>
            <td><?= e((string)$v['company']) ?></td>
            <td><?= $v['visit_date'] ? e(tanggalIndo($v['visit_date'])) : '-' ?></td>
            <td>
              <form method="post" style="display:inline;"><?= csrfField() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$v['id'] ?>">
                <button type="submit" class="btn btn-outline btn-sm"><?= $v['is_active'] ? 'Aktif' : 'Disembunyikan' ?></button></form>
            </td>
            <td class="actions"><div class="row-actions">
              <a href="kunjungan-industri-form.php?id=<?= (int)$v['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus data ini?')" style="display:inline;"><?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$v['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button></form>
            </div></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

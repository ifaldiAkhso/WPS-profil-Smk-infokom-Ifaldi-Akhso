<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
ensureBkkTables($pdo);

$id = (int)($_GET['id'] ?? 0);
$item = null;
if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM partner_companies WHERE id=?"); $stmt->execute([$id]); $item = $stmt->fetch();
    if (!$item) { setFlash('error', 'Data tidak ditemukan.'); redirect('bkk-perusahaan.php'); }
}
$pageTitle = $item ? 'Edit Perusahaan Mitra' : 'Tambah Perusahaan Mitra';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !verifyCsrf()) {
    // Sebelumnya gagal diam-diam (mis. sesi habis atau file logo melebihi batas server) sehingga data terlihat "tidak tersimpan"
    setFlash('error', 'Data tidak tersimpan: sesi habis atau ukuran logo melebihi batas server. Muat ulang halaman lalu coba lagi (gunakan logo di bawah 2MB).');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $name = trim($_POST['name'] ?? '');
    if ($name === '') {
        setFlash('error', 'Nama perusahaan wajib diisi.');
    } else {
        $upload = handleImageUpload('logo', 'bkk/perusahaan');
        if (!$upload['ok']) {
            setFlash('error', $upload['message']);
        } else {
            $field       = trim($_POST['field'] ?? '');
            $location    = trim($_POST['location'] ?? '');
            $website     = trim($_POST['website'] ?? '');
            $description = trim($_POST['description'] ?? '');
            // Website: otomatis diberi https:// bila belum ada, agar link bisa diklik di halaman publik
            if ($website !== '' && !preg_match('~^https?://~i', $website)) $website = 'https://' . $website;
            if ($website !== '' && !preg_match('~^https?://[^\s]+$~i', $website)) {
                setFlash('error', 'Format website tidak valid. Contoh: https://www.perusahaan.com');
                $website = null;
            }
            $isPartner   = isset($_POST['is_partner']) ? 1 : 0;

            if ($website === null) {
                // website tidak valid: data tidak disimpan, form tampil lagi dengan pesan error
            } elseif ($item) {
                $logo = $upload['file'] ?? $item['logo'];
                $stmt = $pdo->prepare("UPDATE partner_companies SET name=?, logo=?, field=?, location=?, description=?, website=?, is_partner=? WHERE id=?");
                $stmt->execute([$name, $logo, $field ?: null, $location ?: null, $description ?: null, $website ?: null, $isPartner, $item['id']]);
                setFlash('success', 'Perusahaan mitra berhasil diperbarui.');
                redirect('bkk-perusahaan.php');
            } else {
                $stmt = $pdo->prepare("INSERT INTO partner_companies (name, logo, field, location, description, website, is_partner) VALUES (?,?,?,?,?,?,?)");
                $stmt->execute([$name, $upload['file'], $field ?: null, $location ?: null, $description ?: null, $website ?: null, $isPartner]);
                setFlash('success', 'Perusahaan mitra berhasil ditambahkan.');
                redirect('bkk-perusahaan.php');
            }
        }
    }
}

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= e($pageTitle) ?></h3></div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <div class="form-grid">
        <div class="form-group full"><label>Nama Perusahaan <span class="req">*</span></label><input type="text" name="name" maxlength="150" class="form-control" required value="<?= e($item['name'] ?? '') ?>"></div>
        <div class="form-group"><label>Bidang (opsional)</label><input type="text" name="field" maxlength="150" class="form-control" placeholder="Contoh: Teknologi Informasi" value="<?= e($item['field'] ?? '') ?>"><p class="form-hint">Tampil di kartu daftar mitra, filter, dan halaman detail.</p></div>
        <div class="form-group"><label>Lokasi</label><input type="text" name="location" maxlength="150" class="form-control" placeholder="Contoh: Bogor, Jawa Barat" value="<?= e($item['location'] ?? '') ?>"></div>
        <div class="form-group"><label>Website (opsional)</label><input type="text" name="website" maxlength="255" class="form-control" placeholder="https://www.perusahaan.com" value="<?= e($item['website'] ?? '') ?>"><p class="form-hint">Akan tampil sebagai link yang bisa diklik di halaman mitra.</p></div>
        <div class="form-group full"><label>Penjelasan Perusahaan (opsional)</label><textarea name="description" rows="6" class="form-control" placeholder="Deskripsi singkat perusahaan, kerja sama dengan sekolah, dll."><?= e($item['description'] ?? '') ?></textarea><p class="form-hint">Tampil di halaman detail perusahaan mitra.</p></div>
        <div class="form-group full">
          <label>Logo Perusahaan</label>
          <input type="file" name="logo" class="form-control js-image-preview" data-preview-target="imgPreview" accept="image/*">
          <p class="form-hint">Gunakan logo landscape (lebar), rasio sekitar 16:9. Format JPG/PNG/WEBP, maksimal 8MB (otomatis dikecilkan).</p>
          <img id="imgPreview" class="img-preview" style="display:<?= !empty($item['logo']) ? 'block':'none' ?>;" src="<?= uploadUrl($item['logo'] ?? null) ?>">
        </div>
        <div class="form-group"><label><input type="checkbox" name="is_partner" value="1" <?= (!$item || (int)$item['is_partner'] === 1) ? 'checked' : '' ?>> Mitra aktif (tampil di website)</label></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <a href="bkk-perusahaan.php" class="btn btn-outline">Batal</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

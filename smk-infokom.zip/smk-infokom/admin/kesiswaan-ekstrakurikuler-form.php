<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
ensureKesiswaanTables($pdo);

$id = (int)($_GET['id'] ?? 0);
$item = null;
if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM extracurriculars WHERE id=?"); $stmt->execute([$id]); $item = $stmt->fetch();
    if (!$item) { setFlash('error', 'Data tidak ditemukan.'); redirect('kesiswaan-ekstrakurikuler.php'); }
}
$pageTitle = $item ? 'Edit Ekstrakurikuler' : 'Tambah Ekstrakurikuler';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $name = trim($_POST['name'] ?? '');
    if ($name === '') {
        setFlash('error', 'Nama ekstrakurikuler wajib diisi.');
    } else {
        $upload = handleImageUpload('photo', 'kesiswaan/ekstrakurikuler');
        if (!$upload['ok']) {
            setFlash('error', $upload['message']);
        } else {
            $category   = trim($_POST['category'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $schedule   = trim($_POST['schedule'] ?? '');
            $supervisor = trim($_POST['supervisor'] ?? '');
            $location   = trim($_POST['location'] ?? '');
            $achievement = trim($_POST['achievement_note'] ?? '');
            $sortOrder  = (int)($_POST['sort_order'] ?? 0);
            $isActive   = isset($_POST['is_active']) ? 1 : 0;
            $baseSlug   = slugify($name);

            if ($item) {
                $photo = $upload['file'] ?? $item['photo'];
                // slug unik manual (tabel extracurriculars belum termasuk daftar di uniqueSlug())
                $slug = $baseSlug; $i = 2;
                $chk = $pdo->prepare("SELECT COUNT(*) FROM extracurriculars WHERE slug=? AND id<>?");
                while (true) { $chk->execute([$slug, $item['id']]); if ((int)$chk->fetchColumn() === 0) break; $slug = $baseSlug . '-' . $i++; }

                $stmt = $pdo->prepare("UPDATE extracurriculars SET name=?, slug=?, category=?, photo=?, description=?, schedule=?, supervisor=?, location=?, achievement_note=?, sort_order=?, is_active=? WHERE id=?");
                $stmt->execute([$name, $slug, $category ?: null, $photo, $description, $schedule ?: null, $supervisor ?: null, $location ?: null, $achievement, $sortOrder, $isActive, $item['id']]);
                setFlash('success', 'Ekstrakurikuler berhasil diperbarui.');
            } else {
                $slug = $baseSlug; $i = 2;
                $chk = $pdo->prepare("SELECT COUNT(*) FROM extracurriculars WHERE slug=?");
                while (true) { $chk->execute([$slug]); if ((int)$chk->fetchColumn() === 0) break; $slug = $baseSlug . '-' . $i++; }

                $stmt = $pdo->prepare("INSERT INTO extracurriculars (name, slug, category, photo, description, schedule, supervisor, location, achievement_note, sort_order, is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
                $stmt->execute([$name, $slug, $category ?: null, $upload['file'], $description, $schedule ?: null, $supervisor ?: null, $location ?: null, $achievement, $sortOrder, $isActive]);
                setFlash('success', 'Ekstrakurikuler berhasil ditambahkan.');
            }
            redirect('kesiswaan-ekstrakurikuler.php');
        }
    }
}

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= e($pageTitle) ?></h3></div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <div class="form-grid">
        <div class="form-group full"><label>Nama Ekstrakurikuler <span class="req">*</span></label><input type="text" name="name" maxlength="150" class="form-control" required value="<?= e($item['name'] ?? '') ?>"></div>
        <div class="form-group"><label>Kategori</label><input type="text" name="category" maxlength="80" class="form-control" placeholder="Contoh: Olahraga, Seni, Teknologi" value="<?= e($item['category'] ?? '') ?>"></div>
        <div class="form-group"><label>Jadwal</label><input type="text" name="schedule" maxlength="150" class="form-control" placeholder="Contoh: Setiap Jumat, 14.00-16.00" value="<?= e($item['schedule'] ?? '') ?>"></div>
        <div class="form-group"><label>Pembina</label><input type="text" name="supervisor" maxlength="150" class="form-control" value="<?= e($item['supervisor'] ?? '') ?>"></div>
        <div class="form-group full"><label>Tempat Kegiatan</label><input type="text" name="location" maxlength="150" class="form-control" value="<?= e($item['location'] ?? '') ?>"></div>
        <div class="form-group full"><label>Deskripsi</label><textarea name="description" class="form-control" style="min-height:120px;"><?= e($item['description'] ?? '') ?></textarea></div>
        <div class="form-group full"><label>Prestasi (opsional)</label><textarea name="achievement_note" class="form-control" placeholder="Isi jika ekstrakurikuler ini pernah meraih prestasi"><?= e($item['achievement_note'] ?? '') ?></textarea></div>
        <div class="form-group full">
          <label>Foto</label>
          <input type="file" name="photo" class="form-control js-image-preview" data-preview-target="imgPreview" accept="image/*">
          <p class="form-hint">Format JPG/PNG/WEBP, maksimal 8MB (foto besar otomatis dikecilkan).</p>
          <img id="imgPreview" class="img-preview" style="display:<?= !empty($item['photo']) ? 'block':'none' ?>;" src="<?= uploadUrl($item['photo'] ?? null) ?>">
        </div>
        <div class="form-group"><label><input type="checkbox" name="is_active" value="1" <?= (!$item || (int)$item['is_active'] === 1) ? 'checked' : '' ?>> Aktif (tampil di website)</label></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <a href="kesiswaan-ekstrakurikuler.php" class="btn btn-outline">Batal</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Pengaturan Akun';

$stmt = $pdo->prepare("SELECT * FROM admins WHERE id=?");
$stmt->execute([$currentAdmin['id']]);
$admin = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $formType = $_POST['form_type'] ?? '';

    if ($formType === 'profile') {
        $upload = handleImageUpload('photo', 'lainnya');
        if (!$upload['ok']) {
            setFlash('error', $upload['message']);
        } else {
            $fullName = trim($_POST['full_name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $photo = $upload['file'] ?? $admin['photo'];

            $check = $pdo->prepare("SELECT COUNT(*) FROM admins WHERE email=? AND id<>?");
            $check->execute([$email, $admin['id']]);
            if ($check->fetchColumn() > 0) {
                setFlash('error', 'Email sudah digunakan oleh admin lain.');
            } else {
                $pdo->prepare("UPDATE admins SET full_name=?, email=?, photo=? WHERE id=?")
                    ->execute([$fullName, $email, $photo, $admin['id']]);
                $_SESSION['admin_full_name'] = $fullName;
                $_SESSION['admin_photo'] = $photo;
                setFlash('success', 'Profil berhasil diperbarui.');
            }
        }
        redirect('pengaturan.php');
    }

    if ($formType === 'password') {
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (!password_verify($current, $admin['password'])) {
            setFlash('error', 'Password saat ini salah.');
        } elseif (strlen($new) < 8) {
            setFlash('error', 'Password baru minimal 8 karakter.');
        } elseif ($new !== $confirm) {
            setFlash('error', 'Konfirmasi password baru tidak cocok.');
        } else {
            $hash = password_hash($new, PASSWORD_BCRYPT);
            $pdo->prepare("UPDATE admins SET password=? WHERE id=?")->execute([$hash, $admin['id']]);
            setFlash('success', 'Password berhasil diubah. Silakan gunakan password baru saat login berikutnya.');
        }
        redirect('pengaturan.php');
    }
}

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3>Profil Admin</h3></div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <input type="hidden" name="form_type" value="profile">
      <div class="form-grid">
        <div class="form-group"><label>Nama Lengkap <span class="req">*</span></label>
          <input type="text" name="full_name" maxlength="100" class="form-control" required value="<?= e($admin['full_name']) ?>"></div>
        <div class="form-group"><label>Email <span class="req">*</span></label>
          <input type="email" name="email" maxlength="100" class="form-control" required value="<?= e($admin['email']) ?>"></div>
        <div class="form-group"><label>Username</label>
          <input type="text" class="form-control" value="<?= e($admin['username']) ?>" disabled></div>
        <div class="form-group"><label>Peran</label>
          <input type="text" class="form-control" value="<?= e(ucfirst($admin['role'])) ?>" disabled></div>
        <div class="form-group full">
          <label>Foto Profil</label>
          <input type="file" name="photo" class="form-control js-image-preview" data-preview-target="imgPreview" accept="image/*">
          <img id="imgPreview" class="img-preview" style="display:<?= !empty($admin['photo']) ? 'block':'none' ?>;width:90px;height:90px;border-radius:50%;object-fit:cover;" src="<?= uploadUrl($admin['photo'], 'assets/images/avatar-placeholder.jpg') ?>">
        </div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan Profil</button>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Ganti Password</h3></div>
  <div class="card-body">
    <form method="post" autocomplete="off">
      <?= csrfField() ?>
      <input type="hidden" name="form_type" value="password">
      <div class="form-grid">
        <div class="form-group full"><label>Password Saat Ini <span class="req">*</span></label>
          <input type="password" name="current_password" class="form-control" required></div>
        <div class="form-group"><label>Password Baru <span class="req">*</span></label>
          <input type="password" name="new_password" class="form-control" required minlength="8"></div>
        <div class="form-group"><label>Konfirmasi Password Baru <span class="req">*</span></label>
          <input type="password" name="confirm_password" class="form-control" required minlength="8"></div>
        <div class="form-group full"><p class="form-hint">Minimal 8 karakter. Gunakan kombinasi huruf, angka, dan simbol untuk keamanan lebih baik.</p></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-key"></i> Ubah Password</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Struktur Organisasi';
ensureOrgGroupColumn($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $upload = handleImageUpload('photo', 'lainnya');
        if (!$upload['ok']) {
            setFlash('error', $upload['message']);
        } else {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $position = trim($_POST['position'] ?? '');
            $groupName = trim($_POST['group_name'] ?? '');

            if ($name === '' || $position === '') {
                setFlash('error', 'Nama dan jabatan wajib diisi.');
            } elseif ($groupName === '') {
                setFlash('error', 'Bidang / kelompok wajib diisi.');
            } elseif ($id > 0) {
                $existing = $pdo->prepare("SELECT photo FROM organization_structure WHERE id=?");
                $existing->execute([$id]);
                $photo = $upload['file'] ?? $existing->fetchColumn();
                $stmt = $pdo->prepare("UPDATE organization_structure SET name=?, position=?, group_name=?, photo=? WHERE id=?");
                $stmt->execute([$name, $position, $groupName, $photo, $id]);
                setFlash('success', 'Struktur organisasi berhasil diperbarui.');
            } else {
                $stmt = $pdo->prepare("INSERT INTO organization_structure (name, position, group_name, photo) VALUES (?,?,?,?)");
                $stmt->execute([$name, $position, $groupName, $upload['file']]);
                setFlash('success', 'Struktur organisasi berhasil ditambahkan.');
            }
        }
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM organization_structure WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Data berhasil dihapus.');
    }
    redirect('struktur.php');
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM organization_structure WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editItem = $stmt->fetch();
}

// Urutkan: Bidang "Pimpinan" selalu tampil paling atas, lalu bidang lain menurut kemunculan pertamanya
// (MIN id), lalu nama — sederhana dan cukup tanpa perlu kolom Urutan manual.
$allItems = $pdo->query("
    SELECT o.*, g.first_id
    FROM organization_structure o
    JOIN (SELECT group_name, MIN(id) AS first_id FROM organization_structure GROUP BY group_name) g ON g.group_name = o.group_name
    ORDER BY (o.group_name = '" . ORG_TOP_GROUP . "') DESC, g.first_id ASC, o.name ASC
")->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= $editItem ? 'Edit Anggota Struktur' : 'Tambah Anggota Struktur' ?></h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Anggota dikelompokkan berdasarkan <b>Bidang</b> (mis. Pimpinan, Bidang Kurikulum, Staff Tata Usaha). Bidang <b><?= e(ORG_TOP_GROUP) ?></b> selalu ditampilkan pertama di halaman publik.</p>
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editItem['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group"><label>Nama <span class="req">*</span></label><input type="text" name="name" maxlength="150" class="form-control" required value="<?= e($editItem['name'] ?? '') ?>"></div>
        <div class="form-group"><label>Jabatan <span class="req">*</span></label><input type="text" name="position" maxlength="150" class="form-control" required value="<?= e($editItem['position'] ?? '') ?>"></div>
        <div class="form-group full">
          <label>Bidang / Kelompok <span class="req">*</span></label>
          <input type="text" name="group_name" list="orgGroupOptions" maxlength="100" class="form-control" required placeholder="Contoh: Bidang Kurikulum" value="<?= e($editItem['group_name'] ?? '') ?>">
          <datalist id="orgGroupOptions"><?php foreach (orgGroupSuggestions() as $opt): ?><option value="<?= e($opt) ?>"><?php endforeach; ?></datalist>
        </div>
        <div class="form-group full">
          <label>Foto (disarankan potret, sama seperti foto Guru &amp; Staff)</label>
          <input type="file" name="photo" class="form-control js-image-preview" data-preview-target="photoPreview" accept="image/*">
          <img id="photoPreview" class="img-preview" style="display:<?= !empty($editItem['photo']) ? 'block' : 'none' ?>;" src="<?= uploadUrl($editItem['photo'] ?? null) ?>">
        </div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <?php if ($editItem): ?><a href="struktur.php" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar Struktur Organisasi</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($allItems) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-sitemap"></i><p>Belum ada data struktur organisasi.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Foto</th><th>Nama</th><th>Jabatan</th><th>Bidang</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($allItems as $o): ?>
          <tr>
            <td><img src="<?= uploadUrl($o['photo'], 'assets/images/avatar-placeholder.jpg') ?>" class="thumb-sm" alt=""></td>
            <td><?= e($o['name']) ?></td>
            <td><?= e($o['position']) ?></td>
            <td><span class="badge <?= $o['group_name'] === ORG_TOP_GROUP ? 'badge-gold' : 'badge-info' ?>"><?= e($o['group_name']) ?></span></td>
            <td class="actions"><div class="row-actions">
              <a href="?edit=<?= (int)$o['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus data ini?')" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
ensureBkkTables($pdo);

/* Mitra bersifat OPSIONAL: lowongan boleh dibuat tanpa memilih Perusahaan Mitra. */
$companies = $pdo->query("SELECT id, name FROM partner_companies ORDER BY name ASC")->fetchAll();
$programs  = $pdo->query("SELECT id, name FROM programs ORDER BY name ASC")->fetchAll();

$id = (int)($_GET['id'] ?? 0);
$item = null;
if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM job_vacancies WHERE id=?");
    $stmt->execute([$id]);
    $item = $stmt->fetch();
    if (!$item) { setFlash('error', 'Data tidak ditemukan.'); redirect('bkk-lowongan.php'); }
}
$pageTitle = $item ? 'Edit Lowongan Kerja' : 'Tambah Lowongan Kerja';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $upload       = handleImageUpload('image', 'lowongan');
    $position     = safeCut(trim($_POST['position'] ?? ''), 150);
    $companyId    = (int)($_POST['company_id'] ?? 0) ?: null;
    $companyName  = safeCut(trim($_POST['company_name'] ?? ''), 150);
    $programId    = (int)($_POST['program_id'] ?? 0) ?: null;
    $location     = safeCut(trim($_POST['location'] ?? ''), 150);
    $description  = trim($_POST['description'] ?? '');
    $requirements = trim($_POST['requirements'] ?? '');
    $deadline     = trim($_POST['deadline'] ?? '') ?: null;
    $regLink      = safeCut(trim($_POST['registration_link'] ?? ''), 255);
    $status       = ($_POST['status'] ?? '') === 'ditutup' ? 'ditutup' : 'aktif';
    $removeImage  = !empty($_POST['remove_image']);

    $oldImage = $item['image'] ?? null;
    $hasImage = !empty($upload['file']) || ($oldImage && !$removeImage);

    if (!$upload['ok']) {
        setFlash('error', $upload['message']);
    } elseif (!empty($upload['file']) && !uploadExists($upload['file'])) {
        setFlash('error', 'Foto terunggah tetapi tidak ditemukan di server (assets/uploads/lowongan). Periksa izin folder lalu coba lagi.');
    } elseif ($position === '' && !$hasImage && $description === '') {
        // Syarat minimal: isi salah satu — posisi, gambar, atau deskripsi.
        setFlash('error', 'Isi minimal salah satu: Posisi, Gambar, atau Deskripsi.');
    } else {
        $image = $upload['file'] ?? ($removeImage ? null : $oldImage);
        $values = [$companyId, $companyName ?: null, $image, $position, $programId, $location ?: null,
                   $description, $requirements, $deadline, $regLink ?: null, $status];
        try {
            if ($item) {
                $pdo->prepare("UPDATE job_vacancies SET company_id=?, company_name=?, image=?, position=?, program_id=?, location=?, description=?, requirements=?, deadline=?, registration_link=?, status=? WHERE id=?")
                    ->execute([...$values, $item['id']]);
                if ($oldImage && $oldImage !== $image) deleteUploadedFile($oldImage);
                setFlash('success', 'Lowongan kerja berhasil diperbarui.');
            } else {
                $pdo->prepare("INSERT INTO job_vacancies (company_id, company_name, image, position, program_id, location, description, requirements, deadline, registration_link, status) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
                    ->execute($values);
                setFlash('success', 'Lowongan kerja berhasil ditambahkan.');
            }
        } catch (Throwable $e) {
            error_log('[bkk-lowongan-form] ' . $e->getMessage());
            setFlash('error', 'Gagal menyimpan lowongan: periksa isian (Jurusan, Perusahaan Mitra, tanggal) lalu coba lagi.');
            redirect('bkk-lowongan-form.php' . ($item ? '?id=' . (int)$item['id'] : ''));
        }
        redirect('bkk-lowongan.php');
    }
}

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= e($pageTitle) ?></h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Perusahaan Mitra <b>tidak wajib</b>. Cukup unggah gambar/poster lowongan dan isi data seperlunya. Isi minimal salah satu: Posisi, Gambar, atau Deskripsi.</p>
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <div class="form-grid">
        <div class="form-group full">
          <label>Gambar / Poster Lowongan</label>
          <input type="file" name="image" class="form-control js-image-preview" data-preview-target="imgPreview" accept="image/*">
          <img id="imgPreview" class="img-preview" style="display:<?= !empty($item['image']) ? 'block' : 'none' ?>;" src="<?= uploadUrl($item['image'] ?? null) ?>" alt="">
          <?php if (!empty($item['image'])): ?>
            <label class="form-check"><input type="checkbox" name="remove_image" value="1"> Hapus gambar ini</label>
          <?php endif; ?>
        </div>

        <div class="form-group full"><label>Posisi Pekerjaan</label><input type="text" name="position" maxlength="150" class="form-control" value="<?= e($item['position'] ?? '') ?>" placeholder="Contoh: Staff Administrasi"></div>

        <div class="form-group">
          <label>Nama Perusahaan / Instansi</label>
          <input type="text" name="company_name" maxlength="150" class="form-control" value="<?= e($item['company_name'] ?? '') ?>" placeholder="Ketik bebas, tidak harus mitra">
        </div>
        <div class="form-group">
          <label>Perusahaan Mitra (opsional)</label>
          <select name="company_id" class="form-control">
            <option value="0">- Bukan mitra / tidak dipilih -</option>
            <?php foreach ($companies as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= (int)($item['company_id'] ?? 0) === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <p class="form-hint">Bila dipilih dan gambar kosong, logo mitra dipakai sebagai gambar lowongan.</p>
        </div>

        <div class="form-group">
          <label>Jurusan yang Sesuai</label>
          <select name="program_id" class="form-control">
            <option value="0">Semua Jurusan</option>
            <?php foreach ($programs as $p): ?>
              <option value="<?= (int)$p['id'] ?>" <?= (int)($item['program_id'] ?? 0) === (int)$p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group"><label>Lokasi</label><input type="text" name="location" maxlength="150" class="form-control" value="<?= e($item['location'] ?? '') ?>"></div>
        <div class="form-group"><label>Batas Pendaftaran</label><input type="date" name="deadline" class="form-control" value="<?= e($item['deadline'] ?? '') ?>"></div>
        <div class="form-group">
          <label>Status</label>
          <select name="status" class="form-control">
            <option value="aktif" <?= (($item['status'] ?? 'aktif') === 'aktif') ? 'selected' : '' ?>>Aktif</option>
            <option value="ditutup" <?= (($item['status'] ?? '') === 'ditutup') ? 'selected' : '' ?>>Ditutup</option>
          </select>
        </div>
        <div class="form-group full"><label>Link Pendaftaran (opsional)</label><input type="url" name="registration_link" maxlength="255" class="form-control" placeholder="https://" value="<?= e($item['registration_link'] ?? '') ?>"></div>
        <div class="form-group full"><label>Deskripsi Pekerjaan</label><textarea name="description" class="form-control" style="min-height:110px;"><?= e($item['description'] ?? '') ?></textarea></div>
        <div class="form-group full">
          <label>Persyaratan Penting</label>
          <textarea name="requirements" class="form-control" style="min-height:130px;" placeholder="Pendidikan minimal SMK/sederajat&#10;Usia maksimal 25 tahun&#10;Sehat jasmani dan rohani&#10;Membawa CV, ijazah, dan KTP"><?= e($item['requirements'] ?? '') ?></textarea>
          <p class="form-hint">Tulis <b>poin yang penting saja</b> (pendidikan, usia, pengalaman, dokumen), <b>satu poin per baris</b> (disarankan maksimal 8 baris). Di website tampil sebagai daftar centang.</p>
        </div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <a href="bkk-lowongan.php" class="btn btn-outline">Batal</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

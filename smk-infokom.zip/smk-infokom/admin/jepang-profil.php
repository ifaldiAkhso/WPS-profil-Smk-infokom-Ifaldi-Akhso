<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Profil Program Jepang';
ensureJepangTables($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $profile = jepangProfile($pdo);
    $rawSource = trim($_POST['source_url'] ?? '');
    $sourceUrl = safeUrl($rawSource);
    if ($rawSource !== '' && $sourceUrl === '') {
        setFlash('error', 'Link sumber tidak valid. Gunakan alamat lengkap, contoh: https://www.contoh.com/informasi-magang.');
        redirect('jepang-profil.php');
    }
    // Video YouTube dokumentasi: satu link per baris, semuanya harus link YouTube yang valid
    $rawVideo = trim($_POST['video_url'] ?? '');
    $videoLines = [];
    foreach (preg_split('~\R+~', $rawVideo) as $line) {
        $line = trim($line);
        if ($line === '') continue;
        if (youtubeId($line) === '') {
            setFlash('error', 'Link video tidak valid: "' . safeCut($line, 60) . '". Gunakan link YouTube, contoh: https://www.youtube.com/watch?v=xxxxxxxxxxx atau https://youtu.be/xxxxxxxxxxx.');
            redirect('jepang-profil.php');
        }
        $videoLines[] = $line;
    }
    $videoValue = $videoLines ? implode("\n", array_slice($videoLines, 0, 6)) : null;
    $stmt = $pdo->prepare("UPDATE jepang_profile SET about=?, purpose=?, target_participants=?, duration=?, status=?, important_info=?, source_url=?, source_name=?, video_url=? WHERE id=?");
    $stmt->execute([
        trim($_POST['about'] ?? ''),
        trim($_POST['purpose'] ?? ''),
        trim($_POST['target_participants'] ?? ''),
        trim($_POST['duration'] ?? '') ?: null,
        trim($_POST['status'] ?? '') ?: null,
        trim($_POST['important_info'] ?? '') ?: null,
        $sourceUrl ?: null,
        safeCut(trim($_POST['source_name'] ?? ''), 150) ?: null,
        $videoValue,
        (int)$profile['id'],
    ]);
    setFlash('success', 'Profil Program Kerja Jepang berhasil disimpan.');
    redirect('jepang-profil.php');
}

$profile = $pdo->query('SELECT * FROM jepang_profile ORDER BY id LIMIT 1')->fetch() ?: [];

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3>Profil Program Kerja ke Jepang</h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Informasi ini tampil pada bagian <b>Profil Program</b> di halaman publik Program Kerja ke Jepang. Kosongkan bila belum ada kepastian informasi — jangan mengisi dengan perkiraan.</p>
    <form method="post">
      <?= csrfField() ?>
      <div class="form-grid">
        <div class="form-group full"><label>Tentang Program</label><textarea name="about" class="form-control" style="min-height:100px;"><?= e($profile['about'] ?? '') ?></textarea></div>
        <div class="form-group full"><label>Tujuan Program</label><textarea name="purpose" class="form-control" style="min-height:90px;"><?= e($profile['purpose'] ?? '') ?></textarea></div>
        <div class="form-group full"><label>Target Peserta</label><textarea name="target_participants" class="form-control" style="min-height:90px;"><?= e($profile['target_participants'] ?? '') ?></textarea></div>
        <div class="form-group"><label>Durasi Program (jika tersedia)</label><input type="text" name="duration" maxlength="150" class="form-control" placeholder="Contoh: 3 tahun (magang + kerja)" value="<?= e($profile['duration'] ?? '') ?>"></div>
        <div class="form-group"><label>Status Program</label><input type="text" name="status" maxlength="255" class="form-control" placeholder="Contoh: Pendaftaran Dibuka" value="<?= e($profile['status'] ?? '') ?>"></div>
        <div class="form-group full"><label>Informasi Penting (opsional)</label><textarea name="important_info" class="form-control" style="min-height:90px;" placeholder="Catatan penting yang perlu diketahui calon peserta"><?= e($profile['important_info'] ?? '') ?></textarea></div>
        <div class="form-group"><label>Link Sumber Informasi</label><input type="text" name="source_url" maxlength="500" class="form-control" placeholder="https://www.contoh.com/informasi-magang" value="<?= e($profile['source_url'] ?? '') ?>"><p class="form-hint">Tampil sebagai tombol sumber yang bisa diklik di halaman Magang dan Persyaratan.</p></div>
        <div class="form-group"><label>Nama Sumber</label><input type="text" name="source_name" maxlength="150" class="form-control" placeholder="Contoh: Website resmi lembaga penyalur" value="<?= e($profile['source_name'] ?? '') ?>"><p class="form-hint">Bila kosong, otomatis memakai nama domain dari link.</p></div>
        <div class="form-group full"><label>Video YouTube Dokumentasi</label><textarea name="video_url" class="form-control" style="min-height:80px;" placeholder="https://www.youtube.com/watch?v=xxxxxxxxxxx"><?= e($profile['video_url'] ?? '') ?></textarea><p class="form-hint">Satu link per baris (maksimal 6 video). Tampil di bawah foto pada bagian Dokumentasi halaman Magang. Kosongkan bila tidak ada video.</p></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

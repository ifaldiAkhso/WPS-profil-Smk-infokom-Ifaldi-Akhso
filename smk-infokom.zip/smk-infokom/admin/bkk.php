<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Profil BKK';
ensureBkkTables($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';

    if ($action === 'save_settings') {
        $settings = bkkSettings($pdo);
        $upload = handleImageUpload('coordinator_photo', 'bkk/koordinator');
        if (!$upload['ok']) {
            setFlash('error', $upload['message']);
        } else {
            $photo = $upload['file'] ?? ($settings['coordinator_photo'] ?? null);
            $stmt = $pdo->prepare("UPDATE bkk_settings SET description=?, contact_phone=?, contact_email=?, contact_address=?, coordinator_name=?, coordinator_position=?, coordinator_photo=? WHERE id=?");
            $stmt->execute([
                trim($_POST['description'] ?? ''),
                trim($_POST['contact_phone'] ?? '') ?: null,
                trim($_POST['contact_email'] ?? '') ?: null,
                trim($_POST['contact_address'] ?? '') ?: null,
                trim($_POST['coordinator_name'] ?? '') ?: null,
                trim($_POST['coordinator_position'] ?? '') ?: null,
                $photo,
                (int)$settings['id'],
            ]);
            setFlash('success', 'Pengaturan umum BKK berhasil disimpan.');
        }
        redirect('bkk.php');
    } elseif ($action === 'save_section') {
        $id = (int)($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $icon = trim($_POST['icon'] ?? '') ?: 'fa-solid fa-briefcase';
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        if ($title === '') {
            setFlash('error', 'Judul bagian wajib diisi.');
        } elseif ($id > 0) {
            $pdo->prepare("UPDATE bkk_sections SET title=?, content=?, icon=?, sort_order=?, is_active=? WHERE id=?")
                ->execute([$title, trim($_POST['content'] ?? ''), $icon, (int)($_POST['sort_order'] ?? 0), $isActive, $id]);
            setFlash('success', 'Bagian Profil BKK berhasil diperbarui.');
        } else {
            $pdo->prepare("INSERT INTO bkk_sections (title, content, icon, sort_order, is_active) VALUES (?,?,?,?,?)")
                ->execute([$title, trim($_POST['content'] ?? ''), $icon, (int)($_POST['sort_order'] ?? 0), $isActive]);
            setFlash('success', 'Bagian Profil BKK berhasil ditambahkan.');
        }
        redirect('bkk.php');
    } elseif ($action === 'delete_section') {
        $pdo->prepare("DELETE FROM bkk_sections WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Bagian Profil BKK berhasil dihapus.');
        redirect('bkk.php');
    }
}

$settings = bkkSettings($pdo);
$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM bkk_sections WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editItem = $stmt->fetch() ?: null;
}
$sections = bkkSections($pdo, false);

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3>Pengaturan Umum BKK</h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Deskripsi singkat, informasi kontak, dan koordinator BKK yang tampil di halaman <b>Profil BKK</b>.</p>
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save_settings">
      <div class="form-grid">
        <div class="form-group full"><label>Deskripsi Singkat BKK</label><textarea name="description" class="form-control" style="min-height:90px;"><?= e($settings['description'] ?? '') ?></textarea></div>
        <div class="form-group"><label>Telepon</label><input type="text" name="contact_phone" maxlength="50" class="form-control" value="<?= e($settings['contact_phone'] ?? '') ?>"></div>
        <div class="form-group"><label>Email</label><input type="email" name="contact_email" maxlength="100" class="form-control" value="<?= e($settings['contact_email'] ?? '') ?>"></div>
        <div class="form-group full"><label>Alamat</label><input type="text" name="contact_address" maxlength="255" class="form-control" value="<?= e($settings['contact_address'] ?? '') ?>"></div>
        <div class="form-group"><label>Nama Koordinator BKK</label><input type="text" name="coordinator_name" maxlength="150" class="form-control" value="<?= e($settings['coordinator_name'] ?? '') ?>"></div>
        <div class="form-group"><label>Jabatan Koordinator</label><input type="text" name="coordinator_position" maxlength="150" class="form-control" placeholder="Koordinator BKK" value="<?= e($settings['coordinator_position'] ?? '') ?>"></div>
        <div class="form-group full">
          <label>Foto Koordinator (opsional)</label>
          <input type="file" name="coordinator_photo" class="form-control js-image-preview" data-preview-target="imgPreviewCoord" accept="image/*">
          <p class="form-hint">Format JPG/PNG/WEBP, maksimal 8MB (foto besar otomatis dikecilkan).</p>
          <img id="imgPreviewCoord" class="img-preview" style="display:<?= !empty($settings['coordinator_photo']) ? 'block':'none' ?>;" src="<?= uploadUrl($settings['coordinator_photo'] ?? null) ?>">
        </div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan Pengaturan</button>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3><?= $editItem ? 'Edit Bagian Profil BKK' : 'Tambah Bagian Profil BKK' ?></h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Bagian ini tampil sebagai blok informasi di halaman <b>Profil BKK</b>, misalnya Tentang BKK, Tujuan, Fungsi, atau Layanan.</p>
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save_section">
      <input type="hidden" name="id" value="<?= (int)($editItem['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group"><label>Judul <span class="req">*</span></label><input type="text" name="title" class="form-control" required maxlength="150" placeholder="Contoh: Tujuan BKK" value="<?= e($editItem['title'] ?? '') ?>"></div>
        <div class="form-group"><label>Urutan</label><input type="number" name="sort_order" class="form-control" value="<?= (int)($editItem['sort_order'] ?? 0) ?>"></div>
        <div class="form-group full"><label>Isi / Penjelasan</label><textarea name="content" class="form-control" style="min-height:120px;"><?= e($editItem['content'] ?? '') ?></textarea></div>
        <div class="form-group"><label>Ikon (Font Awesome class)</label><input type="text" name="icon" class="form-control" maxlength="60" placeholder="fa-solid fa-briefcase" value="<?= e($editItem['icon'] ?? 'fa-solid fa-briefcase') ?>"></div>
        <div class="form-group"><label style="margin-top:28px;"><input type="checkbox" name="is_active" value="1" <?= (!$editItem || (int)$editItem['is_active'] === 1) ? 'checked' : '' ?>> Tampilkan di website</label></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <?php if ($editItem): ?><a href="bkk.php" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar Bagian Profil BKK</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($sections) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-building-user"></i><p>Belum ada bagian Profil BKK.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Ikon</th><th>Judul</th><th>Status</th><th>Urutan</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($sections as $it): ?>
          <tr>
            <td style="width:50px;"><i class="<?= e($it['icon']) ?>" style="font-size:1.2rem;color:var(--navy-800);"></i></td>
            <td><?= e($it['title']) ?></td>
            <td><?= (int)$it['is_active'] === 1 ? '<span class="badge badge-success">Tampil</span>' : '<span class="badge badge-gray">Disembunyikan</span>' ?></td>
            <td><?= (int)$it['sort_order'] ?></td>
            <td class="actions"><div class="row-actions">
              <a href="?edit=<?= (int)$it['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus bagian ini?')">
                <?= csrfField() ?><input type="hidden" name="action" value="delete_section"><input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

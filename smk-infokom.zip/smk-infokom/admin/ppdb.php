<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Data Pendaftar PPDB';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf() && ($_POST['action'] ?? '') === 'delete') {
    $pdo->prepare("DELETE FROM ppdb_registrations WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
    setFlash('success', 'Data pendaftar berhasil dihapus.');
    redirect('ppdb.php');
}

$search   = trim($_GET['q'] ?? '');
$program  = (int)($_GET['program'] ?? 0);
$status   = $_GET['status'] ?? '';
$tanggal  = $_GET['tanggal'] ?? '';
$page     = max(1, (int)($_GET['page'] ?? 1));
$perPage  = 10;

$where = [];
$params = [];
if ($search !== '') { $where[] = "(r.full_name LIKE ? OR r.registration_number LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($program > 0) { $where[] = "r.program_id = ?"; $params[] = $program; }
if ($status !== '') { $where[] = "r.status = ?"; $params[] = $status; }
if ($tanggal !== '') { $where[] = "DATE(r.created_at) = ?"; $params[] = $tanggal; }
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM ppdb_registrations r $whereSql");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($total / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$sql = "SELECT r.*, p.name AS program_name FROM ppdb_registrations r
        LEFT JOIN programs p ON p.id = r.program_id
        $whereSql ORDER BY r.created_at DESC LIMIT $perPage OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$registrations = $stmt->fetchAll();

$programs = $pdo->query("SELECT * FROM programs ORDER BY name")->fetchAll();
$statusClass = ['Menunggu'=>'badge-warning','Diverifikasi'=>'badge-info','Diterima'=>'badge-success','Ditolak'=>'badge-danger'];

function keepQuery(array $override = []): string
{
    $q = array_merge($_GET, $override);
    return http_build_query($q);
}

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3>Data Pendaftar PPDB (<?= $total ?>)</h3></div>
  <div class="card-body">
    <form method="get" class="filter-bar">
      <input type="text" name="q" class="form-control" placeholder="Cari nama / no. pendaftaran" value="<?= e($search) ?>">
      <select name="program" class="form-control">
        <option value="0">Semua Jurusan</option>
        <?php foreach ($programs as $p): ?>
          <option value="<?= (int)$p['id'] ?>" <?= $program === (int)$p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?></option>
        <?php endforeach; ?>
      </select>
      <select name="status" class="form-control">
        <option value="">Semua Status</option>
        <?php foreach (['Menunggu','Diverifikasi','Diterima','Ditolak'] as $s): ?>
          <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= $s ?></option>
        <?php endforeach; ?>
      </select>
      <input type="date" name="tanggal" class="form-control" value="<?= e($tanggal) ?>">
      <button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-filter"></i> Filter</button>
      <a href="ppdb.php" class="btn btn-outline btn-sm">Reset</a>
    </form>

    <div class="table-responsive" style="margin-top:18px;">
    <?php if (count($registrations) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-user-graduate"></i><p>Belum ada data pendaftar sesuai filter.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>No</th><th>No. Pendaftaran</th><th>Nama</th><th>Asal Sekolah</th><th>Jurusan</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php $no = $offset + 1; foreach ($registrations as $r): ?>
          <tr>
            <td><?= $no++ ?></td>
            <td><?= e($r['registration_number']) ?></td>
            <td><?= e($r['full_name']) ?></td>
            <td><?= e($r['previous_school'] ?: '-') ?></td>
            <td><?= e($r['program_name'] ?? '-') ?></td>
            <td><?= tanggalIndo($r['created_at']) ?></td>
            <td><span class="badge <?= $statusClass[$r['status']] ?? 'badge-gray' ?>"><?= e($r['status']) ?></span></td>
            <td class="actions"><div class="row-actions">
              <a href="ppdb-detail.php?id=<?= (int)$r['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Detail"><i class="fa-solid fa-eye"></i></a>
              <a href="ppdb-detail.php?id=<?= (int)$r['id'] ?>&print=1" target="_blank" class="btn btn-outline btn-sm btn-icon" title="Cetak"><i class="fa-solid fa-print"></i></a>
              <form method="post" onsubmit="return confirm('Hapus data pendaftar ini?')" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>

      <?php if ($totalPages > 1): ?>
      <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
          <a href="?<?= keepQuery(['page' => $i]) ?>" class="<?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
      </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

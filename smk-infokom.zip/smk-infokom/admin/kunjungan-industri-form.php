<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
ensureIndustryVisits($pdo);
$id = (int)($_GET['id'] ?? 0);
$item = null;
if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM industry_visits WHERE id=?"); $stmt->execute([$id]); $item = $stmt->fetch();
    if (!$item) { setFlash('error', 'Data tidak ditemukan.'); redirect('kunjungan-industri.php'); }
}
$pageTitle = $item ? 'Edit Kunjungan Industri' : 'Tambah Kunjungan Industri';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $upload = handleImageUpload('image', 'kunjungan');
    $title = safeCut(trim($_POST['title'] ?? ''), 200);   // opsional
    $company = safeCut(trim($_POST['company'] ?? ''), 200);
    $location = safeCut(trim($_POST['location'] ?? ''), 200);
    $participants = safeCut(trim($_POST['participants'] ?? ''), 200);
    $desc = trim($_POST['description'] ?? '');
    $date = trim($_POST['visit_date'] ?? '');
    $active = !empty($_POST['is_active']) ? 1 : 0;
    $dateOk = $date === '' || (bool)preg_match('~^\d{4}-\d{2}-\d{2}$~', $date);
    if (!$upload['ok']) { setFlash('error', $upload['message']); }
    elseif ($title === '' && $company === '' && $desc === '' && empty($upload['file']) && empty($item['image'])) {
        // Judul OPSIONAL, tetapi minimal satu hal harus diisi supaya data tidak kosong.
        setFlash('error', 'Isi minimal salah satu: Judul, Nama Perusahaan, Deskripsi, atau Foto.');
    }
    elseif (!$dateOk) { setFlash('error', 'Format tanggal tidak valid.'); }
    else {
        $dateVal = $date !== '' ? $date : null;
        if ($item) {
            $image = $upload['file'] ?? $item['image'];
            $pdo->prepare("UPDATE industry_visits SET title=?, company=?, location=?, visit_date=?, participants=?, description=?, image=?, is_active=? WHERE id=?")
                ->execute([$title, $company ?: null, $location ?: null, $dateVal, $participants ?: null, $desc, $image, $active, $item['id']]);
            setFlash('success', 'Kunjungan industri berhasil diperbarui.');
        } else {
            $pdo->prepare("INSERT INTO industry_visits (title, company, location, visit_date, participants, description, image, is_active) VALUES (?,?,?,?,?,?,?,?)")
                ->execute([$title, $company ?: null, $location ?: null, $dateVal, $participants ?: null, $desc, $upload['file'], $active]);
            setFlash('success', 'Kunjungan industri berhasil ditambahkan.');
        }
        redirect('kunjungan-industri.php');
    }
}
include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= e($pageTitle) ?></h3></div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <div class="form-grid">
        <div class="form-group full"><label>Judul Kegiatan (opsional)</label><input type="text" name="title" maxlength="200" class="form-control" value="<?= e($item['title'] ?? '') ?>" placeholder="Contoh: Studi lapangan di PT Telkom Bogor"><p class="form-hint">Boleh dikosongkan. Jika kosong, tidak ada judul yang ditampilkan di website.</p></div>
        <div class="form-group"><label>Nama Perusahaan / Instansi</label><input type="text" name="company" maxlength="200" class="form-control" value="<?= e($item['company'] ?? '') ?>"></div>
        <div class="form-group"><label>Lokasi</label><input type="text" name="location" maxlength="200" class="form-control" value="<?= e($item['location'] ?? '') ?>"></div>
        <div class="form-group"><label>Tanggal Kunjungan</label><input type="date" name="visit_date" class="form-control" value="<?= e($item['visit_date'] ?? '') ?>"></div>
        <div class="form-group"><label>Peserta</label><input type="text" name="participants" maxlength="200" class="form-control" value="<?= e($item['participants'] ?? '') ?>" placeholder="Contoh: Kelas XI RPL, 36 siswa"></div>
        <div class="form-group full"><label>Deskripsi / Hasil Kegiatan</label><textarea name="description" rows="7" class="form-control"><?= e($item['description'] ?? '') ?></textarea></div>
        <div class="form-group full">
          <label>Foto</label>
          <input type="file" name="image" class="form-control js-image-preview" data-preview-target="imgPreview" accept="image/*">
          <img id="imgPreview" class="img-preview" style="display:<?= !empty($item['image']) ? 'block' : 'none' ?>;" src="<?= uploadUrl($item['image'] ?? null) ?>" alt="">
        </div>
        <div class="form-group full"><label><input type="checkbox" name="is_active" value="1" <?= (!$item || !empty($item['is_active'])) ? 'checked' : '' ?>> Tampilkan di website</label></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <a href="kunjungan-industri.php" class="btn btn-outline">Batal</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

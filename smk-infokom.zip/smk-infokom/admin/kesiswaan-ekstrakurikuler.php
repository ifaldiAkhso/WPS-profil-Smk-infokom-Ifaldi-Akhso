<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Ekstrakurikuler';
ensureKesiswaanTables($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    if ($action === 'delete') {
        $pdo->prepare("DELETE FROM extracurriculars WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Ekstrakurikuler berhasil dihapus.');
        redirect('kesiswaan-ekstrakurikuler.php');
    } elseif ($action === 'toggle') {
        $pdo->prepare("UPDATE extracurriculars SET is_active = 1 - is_active WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Status ekstrakurikuler berhasil diperbarui.');
        redirect('kesiswaan-ekstrakurikuler.php');
    }
}

$search = trim($_GET['q'] ?? '');
$where = [];
$params = [];
if ($search !== '') { $where[] = "name LIKE ?"; $params[] = "%$search%"; }
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
$stmt = $pdo->prepare("SELECT * FROM extracurriculars $whereSql ORDER BY sort_order ASC, name ASC");
$stmt->execute($params);
$list = $stmt->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header">
    <h3>Daftar Ekstrakurikuler</h3>
    <a href="kesiswaan-ekstrakurikuler-form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Tambah Ekstrakurikuler</a>
  </div>
  <div class="card-body">
    <form method="get" class="filter-bar">
      <input type="text" name="q" class="form-control" placeholder="Cari nama ekstrakurikuler" value="<?= e($search) ?>">
      <button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Cari</button>
      <?php if ($search !== ''): ?><a href="kesiswaan-ekstrakurikuler.php" class="btn btn-outline btn-sm">Reset</a><?php endif; ?>
    </form>

    <div class="table-responsive" style="margin-top:18px;">
    <?php if (count($list) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-person-running"></i><p>Belum ada data ekstrakurikuler.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Foto</th><th>Nama</th><th>Kategori</th><th>Jadwal</th><th>Pembina</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($list as $ek): ?>
          <tr>
            <td><img src="<?= uploadUrl($ek['photo'], 'assets/images/program-placeholder.jpg') ?>" class="thumb-sm"></td>
            <td><?= e($ek['name']) ?></td>
            <td><?= e($ek['category'] ?: '-') ?></td>
            <td><?= e($ek['schedule'] ?: '-') ?></td>
            <td><?= e($ek['supervisor'] ?: '-') ?></td>
            <td>
              <form method="post" style="display:inline;">
                <?= csrfField() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$ek['id'] ?>">
                <button type="submit" class="badge <?= (int)$ek['is_active'] === 1 ? 'badge-success' : 'badge-gray' ?>" style="border:0;cursor:pointer;">
                  <?= (int)$ek['is_active'] === 1 ? 'Aktif' : 'Nonaktif' ?>
                </button>
              </form>
            </td>
            <td><?= (int)$ek['sort_order'] ?></td>
            <td class="actions"><div class="row-actions">
              <a href="<?= BASE_URL ?>kesiswaan-ekstrakurikuler.php" target="_blank" class="btn btn-outline btn-sm btn-icon" title="Lihat di halaman publik"><i class="fa-solid fa-eye"></i></a>
              <a href="kesiswaan-ekstrakurikuler-form.php?id=<?= (int)$ek['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus ekstrakurikuler ini?')" style="display:inline;">
                <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$ek['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Agenda Sekolah';
ensureAgendaColumns($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    if ($action === 'delete') {
        $pdo->prepare("DELETE FROM agendas WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Agenda berhasil dihapus.');
        redirect('agenda.php');
    } elseif ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $date = trim($_POST['event_date'] ?? '') ?: null;   // tanggal tidak wajib
        $loc = trim($_POST['location'] ?? '');
        $status = ($_POST['status'] ?? '') === 'akan_datang' ? 'akan_datang' : 'otomatis';
        if ($title === '') { setFlash('error', 'Judul agenda wajib diisi.'); redirect('agenda.php' . ($id > 0 ? '?edit=' . $id : '')); }
        if ($id > 0) {
            $pdo->prepare("UPDATE agendas SET title=?, description=?, event_date=?, location=?, status=? WHERE id=?")
                ->execute([$title, $desc, $date, $loc, $status, $id]);
            setFlash('success', 'Agenda berhasil diperbarui.');
        } else {
            $pdo->prepare("INSERT INTO agendas (title, description, event_date, location, status) VALUES (?,?,?,?,?)")
                ->execute([$title, $desc, $date, $loc, $status]);
            setFlash('success', 'Agenda berhasil ditambahkan.');
        }
        redirect('agenda.php');
    }
}

$editId = (int)($_GET['edit'] ?? 0);
$editData = null;
if ($editId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM agendas WHERE id=?");
    $stmt->execute([$editId]);
    $editData = $stmt->fetch();
}
$agendas = $pdo->query("SELECT * FROM agendas ORDER BY (event_date IS NULL) DESC, event_date DESC, id DESC")->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= $editData ? 'Edit Agenda' : 'Tambah Agenda' ?></h3></div>
  <div class="card-body">
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editData['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group full"><label>Judul Agenda <span class="req">*</span></label>
          <input type="text" name="title" maxlength="200" class="form-control" required value="<?= e($editData['title'] ?? '') ?>"></div>
        <div class="form-group"><label>Tanggal (opsional)</label>
          <input type="date" name="event_date" class="form-control" value="<?= e($editData['event_date'] ?? '') ?>">
          <p class="form-hint">Boleh dikosongkan bila tanggal belum pasti.</p></div>
        <div class="form-group"><label>Status</label>
          <select name="status" class="form-control">
            <option value="otomatis" <?= (($editData['status'] ?? 'otomatis') !== 'akan_datang') ? 'selected' : '' ?>>Otomatis (menurut tanggal)</option>
            <option value="akan_datang" <?= (($editData['status'] ?? '') === 'akan_datang') ? 'selected' : '' ?>>Akan Datang</option>
          </select>
          <p class="form-hint">"Akan Datang" selalu tampil di bagian Akan Datang walau tanggalnya belum diisi atau sudah lewat.</p></div>
        <div class="form-group"><label>Lokasi</label>
          <input type="text" name="location" maxlength="150" class="form-control" value="<?= e($editData['location'] ?? '') ?>"></div>
        <div class="form-group full"><label>Deskripsi</label>
          <textarea name="description" class="form-control"><?= e($editData['description'] ?? '') ?></textarea></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <?php if ($editData): ?><a href="agenda.php" class="btn btn-outline">Batal Edit</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar Agenda</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($agendas) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-calendar-days"></i><p>Belum ada agenda.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Tanggal</th><th>Judul</th><th>Lokasi</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($agendas as $a): ?>
          <tr>
            <td><?= !empty($a['event_date']) ? tanggalIndo($a['event_date']) : '<em>Belum ditentukan</em>' ?></td>
            <td><?= e($a['title']) ?></td>
            <td><?= e($a['location'] ?: '-') ?></td>
            <td><?= (($a['status'] ?? '') === 'akan_datang' || empty($a['event_date'])) ? 'Akan Datang' : (($a['event_date'] >= date('Y-m-d')) ? 'Mendatang' : 'Selesai') ?></td>
            <td class="actions"><div class="row-actions">
              <a href="agenda.php?edit=<?= (int)$a['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus agenda ini?')" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Konten PKL';
ensurePklTable($pdo);

$types = pklTypes();
$type = $_GET['type'] ?? ($_POST['item_type'] ?? 'tentang');
if (!isset($types[$type])) $type = 'tentang';
$iconSuggestions = ['fa-solid fa-circle-info', 'fa-solid fa-handshake-simple', 'fa-solid fa-clipboard-list', 'fa-solid fa-file-signature', 'fa-solid fa-route',
    'fa-solid fa-chart-column', 'fa-solid fa-award', 'fa-solid fa-briefcase', 'fa-solid fa-building', 'fa-solid fa-user-tie', 'fa-solid fa-screwdriver-wrench',
    'fa-solid fa-diagram-project', 'fa-solid fa-chalkboard-user', 'fa-solid fa-user-gear', 'fa-solid fa-star', 'fa-solid fa-shield-halved'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $title = safeCut(trim($_POST['title'] ?? ''), 200);
            $content = trim($_POST['content'] ?? '');
            $icon = safeCut(trim($_POST['icon'] ?? ''), 60);
            if (!preg_match('~^[a-z0-9 \-]*$~i', $icon)) $icon = '';        // hanya nama kelas ikon (cegah sisipan HTML)
            if ($icon === '') $icon = 'fa-solid fa-circle-info';
            $sort = (int)($_POST['sort_order'] ?? 0);
            $isActive = isset($_POST['is_active']) ? 1 : 0;
            if ($title === '') {
                setFlash('error', 'Judul wajib diisi.');
                redirect('pkl.php?type=' . urlencode($type) . ($id > 0 ? '&edit=' . $id : ''));
            }
            if ($id > 0) {
                $pdo->prepare("UPDATE pkl_items SET title=?, content=?, icon=?, sort_order=?, is_active=? WHERE id=? AND kind=?")
                    ->execute([$title, $content, $icon, $sort, $isActive, $id, $type]);
                setFlash('success', 'Data PKL berhasil diperbarui.');
            } else {
                if ($sort === 0) {   // urutan otomatis: paling akhir
                    $m = $pdo->prepare("SELECT COALESCE(MAX(sort_order),0)+1 FROM pkl_items WHERE kind=?");
                    $m->execute([$type]);
                    $sort = (int)$m->fetchColumn();
                }
                $pdo->prepare("INSERT INTO pkl_items (kind, title, content, icon, sort_order, is_active) VALUES (?,?,?,?,?,?)")
                    ->execute([$type, $title, $content, $icon, $sort, $isActive]);
                setFlash('success', 'Data PKL berhasil ditambahkan.');
            }
        } elseif ($action === 'toggle') {
            $pdo->prepare("UPDATE pkl_items SET is_active = 1 - is_active WHERE id=? AND kind=?")->execute([(int)($_POST['id'] ?? 0), $type]);
            setFlash('success', 'Status tampil diperbarui.');
        } elseif ($action === 'delete') {
            $pdo->prepare("DELETE FROM pkl_items WHERE id=? AND kind=?")->execute([(int)($_POST['id'] ?? 0), $type]);
            setFlash('success', 'Data PKL berhasil dihapus.');
        }
    } catch (Throwable $e) {
        setFlash('error', friendlyErrorMessage($e));
    }
    redirect('pkl.php?type=' . urlencode($type));
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM pkl_items WHERE id=? AND kind=?");
    $stmt->execute([(int)$_GET['edit'], $type]);
    $editItem = $stmt->fetch() ?: null;
}
$items = pklItems($pdo, $type, false);
$counts = [];
foreach ($types as $k => $_label) $counts[$k] = count(pklItems($pdo, $k, false));
$isAbout = $type === 'tentang';

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-body" style="display:flex;flex-wrap:wrap;gap:8px;">
    <?php foreach ($types as $k => $label): ?>
      <a href="pkl.php?type=<?= e($k) ?>" class="btn <?= $k === $type ? 'btn-primary' : 'btn-outline' ?> btn-sm"><?= e($label) ?> <span class="badge <?= $k === $type ? 'badge-gold' : 'badge-gray' ?>"><?= (int)$counts[$k] ?></span></a>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3><?= $editItem ? 'Edit' : 'Tambah' ?> — <?= e($types[$type]) ?></h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Semua isi halaman publik <b>PKL</b> (menu Informasi) dikelola di sini. Kalimat pembuka "Tentang PKL" diubah di <a href="akademik.php"><b>Kurikulum, Kalender &amp; PKL</b></a>. Urutan tampil mengikuti angka <b>Urutan</b> (kecil lebih dulu).</p>
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="item_type" value="<?= e($type) ?>">
      <input type="hidden" name="id" value="<?= (int)($editItem['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group full"><label><?= $isAbout ? 'Judul internal (tidak tampil di website)' : 'Judul' ?> <span class="req">*</span></label>
          <input type="text" name="title" class="form-control" required maxlength="200" value="<?= e($editItem['title'] ?? '') ?>"></div>
        <div class="form-group full"><label><?= $isAbout ? 'Isi paragraf' : 'Penjelasan' ?></label>
          <textarea name="content" class="form-control" style="min-height:120px;"><?= e($editItem['content'] ?? '') ?></textarea></div>
        <?php if (!$isAbout): ?>
        <div class="form-group"><label>Ikon (Font Awesome)</label>
          <input type="text" name="icon" list="pklIcons" class="form-control" maxlength="60" value="<?= e($editItem['icon'] ?? 'fa-solid fa-circle-info') ?>">
          <datalist id="pklIcons"><?php foreach ($iconSuggestions as $ic): ?><option value="<?= e($ic) ?>"><?php endforeach; ?></datalist>
          <p class="form-hint">Contoh: <code>fa-solid fa-award</code>. Cari nama ikon di fontawesome.com/icons.</p></div>
        <?php else: ?><input type="hidden" name="icon" value="fa-solid fa-circle-info"><?php endif; ?>
        <div class="form-group"><label>Urutan</label>
          <input type="number" name="sort_order" class="form-control" value="<?= (int)($editItem['sort_order'] ?? 0) ?>">
          <p class="form-hint">Isi 0 untuk otomatis ditaruh paling akhir.</p></div>
        <div class="form-group"><label style="margin-top:6px;"><input type="checkbox" name="is_active" value="1" <?= (!$editItem || (int)$editItem['is_active'] === 1) ? 'checked' : '' ?>> Tampilkan di website</label></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <?php if ($editItem): ?><a href="pkl.php?type=<?= e($type) ?>" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar — <?= e($types[$type]) ?></h3><a href="<?= BASE_URL ?>pkl.php" target="_blank" class="btn btn-outline btn-sm"><i class="fa-solid fa-arrow-up-right-from-square"></i> Lihat halaman PKL</a></div>
  <div class="card-body table-responsive">
    <?php if (count($items) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-briefcase"></i><p>Belum ada data. Tambahkan lewat formulir di atas.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Urutan</th><th>Judul</th><th>Isi</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($items as $it): ?>
          <tr>
            <td><?= (int)$it['sort_order'] ?></td>
            <td><i class="<?= e($it['icon']) ?>" style="color:var(--admin-navy);margin-right:6px;"></i><?= e($it['title']) ?></td>
            <td style="max-width:360px;color:var(--admin-muted);"><?= e(mb_or_cut(trim(preg_replace('~\s+~', ' ', (string)$it['content'])), 110)) ?></td>
            <td><?= (int)$it['is_active'] === 1 ? '<span class="badge badge-success">Tampil</span>' : '<span class="badge badge-gray">Disembunyikan</span>' ?></td>
            <td class="actions"><div class="row-actions">
              <a href="?type=<?= e($type) ?>&edit=<?= (int)$it['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" style="display:inline;">
                <?= csrfField() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="item_type" value="<?= e($type) ?>"><input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                <button class="btn btn-outline btn-sm btn-icon" type="submit" title="<?= (int)$it['is_active'] === 1 ? 'Sembunyikan' : 'Tampilkan' ?>"><i class="fa-solid fa-<?= (int)$it['is_active'] === 1 ? 'eye-slash' : 'eye' ?>"></i></button>
              </form>
              <form method="post" onsubmit="return confirm('Hapus data ini?')" style="display:inline;">
                <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="item_type" value="<?= e($type) ?>"><input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Persyaratan Program Magang Jepang';
ensureJepangTables($pdo);
$module = 'persyaratan';
$suggestedTags = ['Persyaratan Umum', 'Dokumen', 'Bahasa', 'Kesehatan', 'Tambahan'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $tag = trim($_POST['tag'] ?? '') ?: 'Persyaratan Umum';
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        if (strcasecmp($tag, JEPANG_TAHAPAN_TAG) === 0) $tag = 'Persyaratan Umum'; // bagian Tahapan Program sudah dihapus
        if ($title === '') {
            setFlash('error', 'Judul persyaratan wajib diisi.');
        } elseif ($id > 0) {
            $pdo->prepare("UPDATE jepang_sections SET tag=?, title=?, content=?, sort_order=?, is_active=? WHERE id=? AND module=?")
                ->execute([$tag, $title, trim($_POST['content'] ?? ''), (int)($_POST['sort_order'] ?? 0), $isActive, $id, $module]);
            setFlash('success', 'Data berhasil diperbarui.');
        } else {
            $pdo->prepare("INSERT INTO jepang_sections (module, tag, title, content, sort_order, is_active) VALUES (?,?,?,?,?,?)")
                ->execute([$module, $tag, $title, trim($_POST['content'] ?? ''), (int)($_POST['sort_order'] ?? 0), $isActive]);
            setFlash('success', 'Data berhasil ditambahkan.');
        }
        redirect('jepang-persyaratan.php');
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM jepang_sections WHERE id=? AND module=?")->execute([(int)($_POST['id'] ?? 0), $module]);
        setFlash('success', 'Data berhasil dihapus.');
        redirect('jepang-persyaratan.php');
    }
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM jepang_sections WHERE id=? AND module=?");
    $stmt->execute([(int)$_GET['edit'], $module]);
    $editItem = $stmt->fetch() ?: null;
}
$stmt = $pdo->prepare("SELECT * FROM jepang_sections WHERE module=? ORDER BY sort_order ASC, id ASC");
$stmt->execute([$module]);
$items = $stmt->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= $editItem ? 'Edit Persyaratan' : 'Tambah Persyaratan' ?></h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Persyaratan dikelompokkan berdasarkan <b>Kategori</b> dan tampil berurutan (sesuai kolom <b>Urutan</b>) di halaman publik Magang. Contoh kategori: <?= e(implode(', ', $suggestedTags)) ?>.</p>
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editItem['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group"><label>Kategori</label><input type="text" name="tag" list="tagOptions" class="form-control" value="<?= e($editItem['tag'] ?? 'Persyaratan Umum') ?>"><datalist id="tagOptions"><?php foreach ($suggestedTags as $t): ?><option value="<?= e($t) ?>"><?php endforeach; ?></datalist></div>
        <div class="form-group"><label>Urutan</label><input type="number" name="sort_order" class="form-control" value="<?= (int)($editItem['sort_order'] ?? 0) ?>"></div>
        <div class="form-group full"><label>Judul Persyaratan <span class="req">*</span></label><input type="text" name="title" class="form-control" required maxlength="200" placeholder="Contoh: Usia minimal 18 tahun" value="<?= e($editItem['title'] ?? '') ?>"></div>
        <div class="form-group full"><label>Penjelasan (opsional)</label><textarea name="content" class="form-control" style="min-height:90px;"><?= e($editItem['content'] ?? '') ?></textarea></div>
        <div class="form-group"><label style="margin-top:28px;"><input type="checkbox" name="is_active" value="1" <?= (!$editItem || (int)$editItem['is_active'] === 1) ? 'checked' : '' ?>> Tampilkan di website</label></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <?php if ($editItem): ?><a href="jepang-persyaratan.php" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar Persyaratan</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($items) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-clipboard-check"></i><p>Belum ada data persyaratan atau tahapan.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Kategori</th><th>Judul</th><th>Status</th><th>Urutan</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($items as $it): ?>
          <tr>
            <td><?= e($it['tag']) ?></td>
            <td><?= e($it['title']) ?></td>
            <td><?= (int)$it['is_active'] === 1 ? '<span class="badge badge-success">Tampil</span>' : '<span class="badge badge-gray">Disembunyikan</span>' ?></td>
            <td><?= (int)$it['sort_order'] ?></td>
            <td class="actions"><div class="row-actions">
              <a href="?edit=<?= (int)$it['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus data ini?')">
                <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

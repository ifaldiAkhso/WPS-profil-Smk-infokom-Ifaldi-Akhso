<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();

$id = (int)($_GET['id'] ?? 0);
$program = null;
if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM programs WHERE id=?");
    $stmt->execute([$id]);
    $program = $stmt->fetch();
    if (!$program) { setFlash('error', 'Data jurusan tidak ditemukan.'); redirect('program.php'); }
}
$pageTitle = $program ? 'Edit Program Keahlian' : 'Tambah Program Keahlian';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $upload = handleImageUpload('image', 'jurusan');
    if (!$upload['ok']) {
        setFlash('error', $upload['message']);
    } else {
        $name = trim($_POST['name'] ?? '');
        $slug = uniqueSlug($pdo, 'programs', slugify($name), (int)($program['id'] ?? 0));
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        if ($program) {
            $image = $upload['file'] ?? $program['image'];
            $stmt = $pdo->prepare("UPDATE programs SET name=?, slug=?, image=?, description=?, excellence=?, sort_order=?, is_active=? WHERE id=?");
            $stmt->execute([$name, $slug, $image, trim($_POST['description'] ?? ''), trim($_POST['excellence'] ?? ''), (int)($_POST['sort_order'] ?? 0), $isActive, $program['id']]);
            setFlash('success', 'Program keahlian berhasil diperbarui.');
        } else {
            $stmt = $pdo->prepare("INSERT INTO programs (name, slug, image, description, excellence, sort_order, is_active) VALUES (?,?,?,?,?,?,?)");
            $stmt->execute([$name, $slug, $upload['file'], trim($_POST['description'] ?? ''), trim($_POST['excellence'] ?? ''), (int)($_POST['sort_order'] ?? 0), $isActive]);
            setFlash('success', 'Program keahlian berhasil ditambahkan.');
        }
        redirect('program.php');
    }
}

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= e($pageTitle) ?></h3></div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <div class="form-grid">
        <div class="form-group full"><label>Nama Jurusan <span class="req">*</span></label><input type="text" name="name" maxlength="150" class="form-control" required value="<?= e($program['name'] ?? '') ?>"></div>
        <div class="form-group full"><label>Deskripsi</label><textarea name="description" class="form-control" style="min-height:120px;"><?= e($program['description'] ?? '') ?></textarea></div>
        <div class="form-group full"><label>Keunggulan</label><textarea name="excellence" class="form-control"><?= e($program['excellence'] ?? '') ?></textarea></div>
        <div class="form-group"><label>Urutan</label><input type="number" name="sort_order" class="form-control" value="<?= (int)($program['sort_order'] ?? 0) ?>"></div>
        <div class="form-group"><label style="margin-top:28px;"><input type="checkbox" name="is_active" <?= (($program['is_active'] ?? 1)) ? 'checked' : '' ?>> Tampilkan di website</label></div>
        <div class="form-group full">
          <label>Gambar Jurusan</label>
          <input type="file" name="image" class="form-control js-image-preview" data-preview-target="imgPreview" accept="image/*">
          <img id="imgPreview" class="img-preview" style="display:<?= !empty($program['image']) ? 'block' : 'none' ?>;" src="<?= uploadUrl($program['image'] ?? null) ?>">
        </div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <a href="program.php" class="btn btn-outline">Batal</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

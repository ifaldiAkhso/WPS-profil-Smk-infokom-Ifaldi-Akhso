<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Program Keahlian';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf() && ($_POST['action'] ?? '') === 'delete') {
    $pdo->prepare("DELETE FROM programs WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
    setFlash('success', 'Program keahlian berhasil dihapus.');
    redirect('program.php');
}

$programs = $pdo->query("SELECT * FROM programs ORDER BY sort_order")->fetchAll();
include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header">
    <h3>Daftar Program Keahlian</h3>
    <a href="program-form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Tambah Jurusan</a>
  </div>
  <div class="card-body table-responsive">
    <?php if (count($programs) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-layer-group"></i><p>Belum ada program keahlian.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Gambar</th><th>Nama Jurusan</th><th>Status</th><th>Urutan</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($programs as $p): ?>
          <tr>
            <td><img src="<?= uploadUrl($p['image'], 'assets/images/program-placeholder.jpg') ?>" class="thumb-sm"></td>
            <td><?= e($p['name']) ?></td>
            <td><?= $p['is_active'] ? '<span class="badge badge-success">Aktif</span>' : '<span class="badge badge-gray">Nonaktif</span>' ?></td>
            <td><?= (int)$p['sort_order'] ?></td>
            <td class="actions"><div class="row-actions">
              <a href="program-form.php?id=<?= (int)$p['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus jurusan ini?')" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

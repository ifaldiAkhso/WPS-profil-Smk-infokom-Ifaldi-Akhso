<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
ensureJepangTables($pdo);
$jepangCatId = ensureJepangGalleryCategory($pdo);

// Mode edit: ?id=... (hanya foto milik kategori Program Jepang)
$item = null;
$editId = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
if ($editId > 0) {
    $st = $pdo->prepare("SELECT * FROM gallery WHERE id = ? AND category_id = ?");
    $st->execute([$editId, $jepangCatId]);
    $item = $st->fetch() ?: null;
    if (!$item) { setFlash('error', 'Foto tidak ditemukan.'); redirect('jepang-galeri.php'); }
}
$pageTitle = $item ? 'Edit Foto Siswa Magang ke Jepang' : 'Tambah Foto Siswa Magang ke Jepang';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        setFlash('error', 'Sesi formulir kedaluwarsa. Muat ulang halaman lalu coba lagi.');
    } elseif ($jepangCatId <= 0) {
        setFlash('error', 'Kategori galeri Program Jepang gagal dibuat. Pastikan database sudah diimpor dan pengguna database boleh menambah data.');
    } elseif ($item) {
        // Edit: ubah judul dan (opsional) ganti foto
        $title  = trim($_POST['title'] ?? '');
        $upload = handleImageUpload('image', 'galeri');
        if (!$upload['ok']) {
            setFlash('error', $upload['message']);
        } else {
            $image = $upload['file'] ?? $item['image'];
            $pdo->prepare("UPDATE gallery SET title=?, image=? WHERE id=? AND category_id=?")
                ->execute([$title !== '' ? safeCut($title, 150) : null, $image, $item['id'], $jepangCatId]);
            setFlash('success', 'Foto berhasil diperbarui.');
            redirect('jepang-galeri.php');
        }
    } else {
        // Boleh pilih banyak foto sekaligus. Foto disimpan ke tabel galeri (kategori "Program Jepang"),
        // dan HANYA tampil di halaman Magang (disaring dari galeri umum lewat galleryPublicSql()).
        $multi = handleMultiImageUpload('images', 'galeri');
        $title = trim($_POST['title'] ?? '');
        $saved = 0;
        $ins = $pdo->prepare("INSERT INTO gallery (category_id, title, image) VALUES (?,?,?)");
        foreach ($multi['files'] as $file) {
            $ins->execute([$jepangCatId, $title !== '' ? safeCut($title, 150) : null, $file]);
            $saved++;
        }
        if ($saved > 0 && !$multi['errors']) {
            setFlash('success', $saved . ' foto berhasil ditambahkan dan hanya tampil di halaman Magang.');
            redirect('jepang-galeri.php');
        } elseif ($saved > 0) {
            setFlash('error', $saved . ' foto berhasil disimpan, tetapi ada yang gagal — ' . implode('; ', $multi['errors']));
            redirect('jepang-galeri.php');
        } elseif ($multi['errors']) {
            setFlash('error', implode('; ', $multi['errors']));
        } else {
            setFlash('error', 'Pilih minimal satu foto untuk diunggah. (Jika sudah memilih tetapi tetap gagal, ukuran total foto mungkin melebihi batas server — unggah lebih sedikit foto sekaligus.)');
        }
    }
}

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= $item ? 'Edit Foto Siswa Magang' : 'Tambah Foto Siswa Magang' ?></h3></div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <?php if ($item): ?><input type="hidden" name="id" value="<?= (int)$item['id'] ?>"><?php endif; ?>
      <div class="form-grid">
        <div class="form-group full"><label>Nama Siswa / Angkatan (opsional)</label><input type="text" name="title" maxlength="150" class="form-control" placeholder="Contoh: Angkatan 2026" value="<?= e($_POST['title'] ?? ($item['title'] ?? '')) ?>"><p class="form-hint"><?= $item ? 'Judul foto ini.' : 'Judul ini dipakai untuk semua foto yang diunggah pada sekali simpan.' ?></p></div>
        <?php if ($item): ?>
        <div class="form-group full">
          <label>Foto Saat Ini</label>
          <img src="<?= uploadUrl($item['image']) ?>" alt="" style="max-width:260px;width:100%;border-radius:12px;display:block;margin-bottom:10px;">
          <label>Ganti Foto (opsional)</label>
          <input type="file" name="image" class="form-control" accept="image/*">
          <p class="form-hint">Kosongkan jika tidak ingin mengganti foto. Format JPG/PNG/WEBP, maks. 8MB.</p>
        </div>
        <?php else: ?>
        <div class="form-group full">
          <label>Foto <span class="req">*</span> (boleh pilih beberapa sekaligus)</label>
          <input type="file" name="images[]" class="form-control" accept="image/*" multiple required>
          <p class="form-hint">Format JPG/PNG/WEBP. Foto berukuran besar dari HP otomatis dikecilkan (maks. 8MB per foto).</p>
        </div>
        <?php endif; ?>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <a href="jepang-galeri.php" class="btn btn-outline">Batal</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

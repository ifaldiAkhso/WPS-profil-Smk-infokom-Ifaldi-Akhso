<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Foto Siswa Magang ke Jepang';
ensureJepangTables($pdo);
$jepangCatId = ensureJepangGalleryCategory($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    if ($action === 'delete') {
        $pdo->prepare("DELETE FROM gallery WHERE id=? AND category_id=?")->execute([(int)($_POST['id'] ?? 0), $jepangCatId]);
        setFlash('success', 'Foto berhasil dihapus.');
        redirect('jepang-galeri.php');
    }
}

$stmt = $pdo->prepare("SELECT * FROM gallery WHERE category_id = ? ORDER BY created_at DESC");
$stmt->execute([$jepangCatId]);
$list = $stmt->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<style>
  .btn-edit-green{background:#e7f8ee;color:#1a7f45;border:1px solid #bfe9d0;}
  .btn-edit-green:hover{background:#d6f2e2;color:#146b3a;}
  .jg-actions{display:flex;gap:8px;}
  .jg-actions form{flex:1;margin:0;}
  .jg-actions .btn{width:100%;justify-content:center;}
</style>
<div class="card">
  <div class="card-header">
    <h3>Foto Siswa yang Sudah Berangkat Magang ke Jepang</h3>
    <a href="jepang-galeri-form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Tambah Foto</a>
  </div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Foto di sini hanya tampil sebagai dokumentasi pada halaman publik <b>Magang</b> dan <b>tidak masuk ke halaman Galeri</b> maupun beranda. Cukup isi judul singkat (misalnya nama siswa/angkatan) dan pilih fotonya.</p>
    <?php if (count($list) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-images"></i><p>Belum ada foto siswa magang ke Jepang.</p></div>
    <?php else: ?>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:16px;">
        <?php foreach ($list as $g): ?>
          <div style="border:1px solid var(--line-200,#e5edf5);border-radius:12px;overflow:hidden;">
            <img src="<?= uploadUrl($g['image']) ?>" style="width:100%;height:120px;object-fit:cover;">
            <div style="padding:10px;">
              <strong style="display:block;font-size:.82rem;margin-bottom:8px;"><?= e($g['title'] ?: '(Tanpa judul)') ?></strong>
              <div class="jg-actions">
                <a href="jepang-galeri-form.php?id=<?= (int)$g['id'] ?>" class="btn btn-edit-green btn-sm"><i class="fa-solid fa-pen"></i> Edit</a>
                <form method="post" onsubmit="return confirm('Hapus foto ini?')">
                  <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$g['id'] ?>">
                  <button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-trash"></i> Hapus</button>
                </form>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

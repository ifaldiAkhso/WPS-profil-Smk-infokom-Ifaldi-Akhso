<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT r.*, p.name AS program_name FROM ppdb_registrations r LEFT JOIN programs p ON p.id=r.program_id WHERE r.id=?");
$stmt->execute([$id]);
$reg = $stmt->fetch();
if (!$reg) { setFlash('error', 'Data pendaftar tidak ditemukan.'); redirect('ppdb.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $status = $_POST['status'];
    $note = trim($_POST['admin_note'] ?? '');
    if (in_array($status, ['Menunggu','Diverifikasi','Diterima','Ditolak'], true)) {
        $pdo->prepare("UPDATE ppdb_registrations SET status=?, admin_note=? WHERE id=?")->execute([$status, $note, $id]);
        setFlash('success', 'Status pendaftar berhasil diperbarui.');
        redirect('ppdb-detail.php?id=' . $id);
    }
}

$docs = $pdo->prepare("SELECT * FROM ppdb_documents WHERE registration_id=?");
$docs->execute([$id]);
$documents = $docs->fetchAll();

$pageTitle = 'Detail Pendaftar';
$isPrint = !empty($_GET['print']);

if ($isPrint):
?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><title>Cetak - <?= e($reg['registration_number']) ?></title>
<style>body{font-family:Arial,sans-serif;padding:30px;color:#111;} table{width:100%;border-collapse:collapse;} td{padding:6px 8px;border-bottom:1px solid #eee;} .label{width:220px;font-weight:bold;color:#333;} h2{margin-bottom:0;} .muted{color:#666;margin-top:0;}</style>
</head><body onload="window.print()">
<h2>Formulir Pendaftaran PPDB - SMK INFOKOM BOGOR</h2>
<p class="muted">No. Pendaftaran: <b><?= e($reg['registration_number']) ?></b> &mdash; Status: <b><?= e($reg['status']) ?></b></p>
<table>
<tr><td class="label">Nama Lengkap</td><td><?= e($reg['full_name']) ?></td></tr>
<tr><td class="label">NIK</td><td><?= e($reg['nik']) ?></td></tr>
<tr><td class="label">NISN</td><td><?= e($reg['nisn']) ?></td></tr>
<tr><td class="label">Tempat, Tanggal Lahir</td><td><?= e($reg['birth_place']) ?>, <?= tanggalIndo($reg['birth_date']) ?></td></tr>
<tr><td class="label">Jenis Kelamin</td><td><?= e($reg['gender']) ?></td></tr>
<tr><td class="label">Agama</td><td><?= e($reg['religion']) ?></td></tr>
<tr><td class="label">Alamat</td><td><?= nl2br(e($reg['address'])) ?></td></tr>
<tr><td class="label">No. HP</td><td><?= e($reg['phone']) ?></td></tr>
<tr><td class="label">Email</td><td><?= e($reg['email']) ?></td></tr>
<tr><td class="label">Nama Orang Tua/Wali</td><td><?= e($reg['parent_name']) ?></td></tr>
<tr><td class="label">No. HP Orang Tua</td><td><?= e($reg['parent_phone']) ?></td></tr>
<tr><td class="label">Asal Sekolah</td><td><?= e($reg['previous_school']) ?></td></tr>
<tr><td class="label">Pilihan Jurusan</td><td><?= e($reg['program_name'] ?? '-') ?></td></tr>
<tr><td class="label">Tahun Ajaran</td><td><?= e($reg['academic_year']) ?></td></tr>
<tr><td class="label">Tanggal Daftar</td><td><?= tanggalIndo($reg['created_at'], true) ?></td></tr>
</table>
</body></html>
<?php
exit;
endif;

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
$statusClass = ['Menunggu'=>'badge-warning','Diverifikasi'=>'badge-info','Diterima'=>'badge-success','Ditolak'=>'badge-danger'];
?>
<div class="card">
  <div class="card-header">
    <h3>Detail Pendaftar &mdash; <?= e($reg['registration_number']) ?></h3>
    <div style="display:flex;gap:8px;">
      <span class="badge <?= $statusClass[$reg['status']] ?? 'badge-gray' ?>"><?= e($reg['status']) ?></span>
      <a href="ppdb-detail.php?id=<?= $id ?>&print=1" target="_blank" class="btn btn-outline btn-sm"><i class="fa-solid fa-print"></i> Cetak</a>
      <a href="ppdb.php" class="btn btn-outline btn-sm"><i class="fa-solid fa-arrow-left"></i> Kembali</a>
    </div>
  </div>
  <div class="card-body">
    <fieldset>
      <legend>Data Pribadi</legend>
      <div class="detail-grid">
        <div><span>Nama Lengkap</span><b><?= e($reg['full_name']) ?></b></div>
        <div><span>NIK</span><b><?= e($reg['nik']) ?></b></div>
        <div><span>NISN</span><b><?= e($reg['nisn'] ?: '-') ?></b></div>
        <div><span>Tempat, Tanggal Lahir</span><b><?= e($reg['birth_place']) ?>, <?= tanggalIndo($reg['birth_date']) ?></b></div>
        <div><span>Jenis Kelamin</span><b><?= e($reg['gender']) ?></b></div>
        <div><span>Agama</span><b><?= e($reg['religion'] ?: '-') ?></b></div>
        <div style="grid-column:1/-1;"><span>Alamat</span><b><?= nl2br(e($reg['address'])) ?></b></div>
      </div>
    </fieldset>
    <fieldset>
      <legend>Kontak & Orang Tua</legend>
      <div class="detail-grid">
        <div><span>No. HP</span><b><?= e($reg['phone']) ?></b></div>
        <div><span>Email</span><b><?= e($reg['email'] ?: '-') ?></b></div>
        <div><span>Nama Orang Tua/Wali</span><b><?= e($reg['parent_name'] ?: '-') ?></b></div>
        <div><span>No. HP Orang Tua</span><b><?= e($reg['parent_phone'] ?: '-') ?></b></div>
      </div>
    </fieldset>
    <fieldset>
      <legend>Asal Sekolah & Jurusan</legend>
      <div class="detail-grid">
        <div><span>Asal Sekolah</span><b><?= e($reg['previous_school'] ?: '-') ?></b></div>
        <div><span>Pilihan Jurusan</span><b><?= e($reg['program_name'] ?? '-') ?></b></div>
        <div><span>Tahun Ajaran</span><b><?= e($reg['academic_year'] ?: '-') ?></b></div>
        <div><span>Tanggal Daftar</span><b><?= tanggalIndo($reg['created_at'], true) ?></b></div>
      </div>
    </fieldset>
    <?php if ($documents): ?>
    <fieldset>
      <legend>Dokumen</legend>
      <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <?php foreach ($documents as $d): ?>
          <a href="<?= uploadUrl($d['file_path']) ?>" target="_blank" class="btn btn-outline btn-sm"><i class="fa-solid fa-file"></i> <?= e($d['document_type']) ?></a>
        <?php endforeach; ?>
      </div>
    </fieldset>
    <?php endif; ?>

    <fieldset>
      <legend>Ubah Status Pendaftaran</legend>
      <form method="post">
        <?= csrfField() ?>
        <div class="form-grid">
          <div class="form-group">
            <label>Status</label>
            <select name="status" class="form-control">
              <?php foreach (['Menunggu','Diverifikasi','Diterima','Ditolak'] as $s): ?>
                <option value="<?= $s ?>" <?= $reg['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group full">
            <label>Catatan Admin (opsional)</label>
            <textarea name="admin_note" class="form-control"><?= e($reg['admin_note'] ?? '') ?></textarea>
          </div>
        </div>
        <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan Status</button>
      </form>
    </fieldset>
  </div>
</div>
<style>
.detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.detail-grid div{display:flex;flex-direction:column;gap:3px;}
.detail-grid span{font-size:.78rem;color:var(--ink-500);}
.detail-grid b{font-weight:600;color:var(--ink-900);}
</style>
<?php include __DIR__ . '/includes/footer.php'; ?>

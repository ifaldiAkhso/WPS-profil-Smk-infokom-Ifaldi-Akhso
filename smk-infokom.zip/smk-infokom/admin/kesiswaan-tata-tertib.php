<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Tata Tertib';
ensureKesiswaanTables($pdo);
$categories = studentRuleCategories();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $category = in_array($_POST['category'] ?? '', $categories, true) ? $_POST['category'] : $categories[0];
        $title = trim($_POST['title'] ?? '');
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        if ($title === '') {
            setFlash('error', 'Judul aturan wajib diisi.');
        } elseif ($id > 0) {
            $pdo->prepare("UPDATE student_rules SET category=?, title=?, content=?, sort_order=?, is_active=? WHERE id=?")
                ->execute([$category, $title, trim($_POST['content'] ?? ''), (int)($_POST['sort_order'] ?? 0), $isActive, $id]);
            setFlash('success', 'Aturan berhasil diperbarui.');
        } else {
            $pdo->prepare("INSERT INTO student_rules (category, title, content, sort_order, is_active) VALUES (?,?,?,?,?)")
                ->execute([$category, $title, trim($_POST['content'] ?? ''), (int)($_POST['sort_order'] ?? 0), $isActive]);
            setFlash('success', 'Aturan berhasil ditambahkan.');
        }
        redirect('kesiswaan-tata-tertib.php');
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM student_rules WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Aturan berhasil dihapus.');
        redirect('kesiswaan-tata-tertib.php');
    }
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM student_rules WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editItem = $stmt->fetch() ?: null;
}
$items = $pdo->query("SELECT * FROM student_rules ORDER BY FIELD(category,'" . implode("','", $categories) . "'), sort_order ASC, id ASC")->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= $editItem ? 'Edit Aturan' : 'Tambah Aturan Tata Tertib' ?></h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Aturan dikelompokkan per kategori dan ditampilkan sebagai accordion di halaman <b>Tata Tertib</b>. Kategori <b>Pengantar</b> ditampilkan sebagai teks pembuka (isi 1 data saja).</p>
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editItem['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group">
          <label>Kategori <span class="req">*</span></label>
          <select name="category" class="form-control">
            <?php foreach ($categories as $c): ?><option value="<?= e($c) ?>" <?= (($editItem['category'] ?? '') === $c) ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="form-group"><label>Urutan</label><input type="number" name="sort_order" class="form-control" value="<?= (int)($editItem['sort_order'] ?? 0) ?>"></div>
        <div class="form-group full"><label>Judul / Poin Aturan <span class="req">*</span></label><input type="text" name="title" class="form-control" required maxlength="200" placeholder="Contoh: Siswa wajib hadir 15 menit sebelum KBM dimulai" value="<?= e($editItem['title'] ?? '') ?>"></div>
        <div class="form-group full"><label>Penjelasan (opsional)</label><textarea name="content" class="form-control" style="min-height:110px;"><?= e($editItem['content'] ?? '') ?></textarea></div>
        <div class="form-group"><label style="margin-top:28px;"><input type="checkbox" name="is_active" value="1" <?= (!$editItem || (int)$editItem['is_active'] === 1) ? 'checked' : '' ?>> Tampilkan di website</label></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <?php if ($editItem): ?><a href="kesiswaan-tata-tertib.php" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar Aturan Tata Tertib</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($items) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-scale-balanced"></i><p>Belum ada data tata tertib.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Kategori</th><th>Judul</th><th>Status</th><th>Urutan</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($items as $it): ?>
          <tr>
            <td><?= e($it['category']) ?></td>
            <td><?= e($it['title']) ?></td>
            <td><?= (int)$it['is_active'] === 1 ? '<span class="badge badge-success">Tampil</span>' : '<span class="badge badge-gray">Disembunyikan</span>' ?></td>
            <td><?= (int)$it['sort_order'] ?></td>
            <td class="actions"><div class="row-actions">
              <a href="?edit=<?= (int)$it['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus aturan ini?')">
                <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

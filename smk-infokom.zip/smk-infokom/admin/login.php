<?php
require_once __DIR__ . '/../includes/functions.php';

if (!empty($_SESSION['admin_id'])) {
    redirect('dashboard.php');
}

// Logo: pakai logo dari Profil Sekolah bila sudah diunggah, jika belum pakai logo bawaan SMK INFOKOM.
$loginLogo = BASE_URL . 'assets/images/logo-smk-infokom.png';
try {
    $loginProfile = schoolProfile();
    if (!empty($loginProfile['logo']) && is_file(BASE_PATH . '/assets/uploads/' . ltrim($loginProfile['logo'], '/'))) {
        $loginLogo = uploadUrl($loginProfile['logo']);
    }
} catch (Throwable $e) {
    // Database belum siap: tetap tampilkan logo bawaan agar halaman login tidak error.
}

$error = '';
if (!empty($_GET['expired'])) {
    $error = 'Sesi Anda telah berakhir. Silakan login kembali.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        $error = 'Sesi form kedaluwarsa, silakan coba lagi.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        // Rate limiting sederhana berbasis session
        $_SESSION['login_attempts'] = $_SESSION['login_attempts'] ?? 0;
        $_SESSION['login_attempt_time'] = $_SESSION['login_attempt_time'] ?? time();
        if (time() - $_SESSION['login_attempt_time'] > 300) {
            $_SESSION['login_attempts'] = 0;
            $_SESSION['login_attempt_time'] = time();
        }

        if ($_SESSION['login_attempts'] >= 5) {
            $error = 'Terlalu banyak percobaan login. Coba lagi dalam beberapa menit.';
        } elseif ($username === '' || $password === '') {
            $error = 'Username dan password wajib diisi.';
        } else {
            $stmt = getDB()->prepare("SELECT * FROM admins WHERE (username = ? OR email = ?) AND is_active = 1 LIMIT 1");
            $stmt->execute([$username, $username]);
            $admin = $stmt->fetch();

            if ($admin && password_verify($password, $admin['password'])) {
                session_regenerate_id(true);
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['username'];
                $_SESSION['admin_full_name'] = $admin['full_name'];
                $_SESSION['admin_photo'] = $admin['photo'];
                $_SESSION['admin_role'] = $admin['role'];
                $_SESSION['admin_last_activity'] = time();
                $_SESSION['login_attempts'] = 0;

                getDB()->prepare("UPDATE admins SET last_login = NOW() WHERE id = ?")->execute([$admin['id']]);
                redirect('dashboard.php');
            } else {
                $_SESSION['login_attempts']++;
                $error = 'Username atau password salah.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Admin - SMK INFOKOM BOGOR</title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" type="image/png" href="<?= BASE_URL ?>assets/images/favicon.png">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/admin.css">
</head>
<body>
<div class="login-wrap">
  <div class="login-card">
    <section class="login-brand-panel">
      <img class="login-brand-logo" src="<?= e($loginLogo) ?>" alt="Logo SMK INFOKOM BOGOR">
      <h2>Admin SMK INFOKOM</h2>
      <p>Kelola website sekolah dengan antarmuka yang rapi, cepat, dan terpusat.</p>
      <div class="login-feature-list">
        <div><i class="fa-solid fa-check"></i><span>Kelola PPDB dan data pendaftar</span></div>
        <div><i class="fa-solid fa-check"></i><span>Atur profil, guru & staff</span></div>
        <div><i class="fa-solid fa-check"></i><span>Publikasi berita, galeri & prestasi</span></div>
        <div><i class="fa-solid fa-check"></i><span>Pantau pesan dan aktivitas website</span></div>
      </div>
    </section>

    <section class="login-form-panel">
      <h1>Masuk ke Dashboard</h1>
      <p>Gunakan akun administrator yang terdaftar pada database sekolah.</p>

      <?php if ($error): ?>
        <div class="login-alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div>
      <?php endif; ?>

      <form method="post" autocomplete="off">
        <?= csrfField() ?>
        <div class="form-group">
          <label>Username atau Email</label>
          <div class="input-icon">
            <i class="fa-solid fa-user"></i>
            <input type="text" name="username" class="form-control" required autofocus value="<?= e($_POST['username'] ?? '') ?>">
          </div>
        </div>
        <div class="form-group">
          <label>Password</label>
          <div class="input-icon">
            <i class="fa-solid fa-lock"></i>
            <input type="password" name="password" id="passwordInput" class="form-control" required style="padding-right:40px;">
            <button type="button" class="toggle-pass js-toggle-pass" data-target="passwordInput" aria-label="Tampilkan password"><i class="fa-solid fa-eye"></i></button>
          </div>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;padding:13px;">
          <i class="fa-solid fa-right-to-bracket"></i> Masuk ke Dashboard
        </button>
      </form>
      <a href="<?= BASE_URL ?>index.php" class="back-site"><i class="fa-solid fa-arrow-left"></i> Kembali ke Website</a>
    </section>
  </div>
</div>
<script src="<?= BASE_URL ?>assets/js/admin.js"></script>
</body>
</html>

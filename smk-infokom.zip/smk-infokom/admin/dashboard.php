<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Dashboard';

$totalNews = (int)$pdo->query("SELECT COUNT(*) FROM news")->fetchColumn();
$totalPpdb = (int)$pdo->query("SELECT COUNT(*) FROM ppdb_registrations")->fetchColumn();
$newPpdb = (int)$pdo->query("SELECT COUNT(*) FROM ppdb_registrations WHERE status='Menunggu'")->fetchColumn();
$totalAchievements = (int)$pdo->query("SELECT COUNT(*) FROM achievements")->fetchColumn();
$totalGallery = (int)$pdo->query("SELECT COUNT(*) FROM gallery WHERE " . galleryPublicSql($pdo))->fetchColumn();
$totalPrograms = (int)$pdo->query("SELECT COUNT(*) FROM programs")->fetchColumn();
$unreadMessages = (int)$pdo->query("SELECT COUNT(*) FROM contact_messages WHERE is_read=0")->fetchColumn();
$totalStaff = (int)$pdo->query("SELECT COUNT(*) FROM staff WHERE is_active=1")->fetchColumn();

$ppdbByProgram = $pdo->query("
  SELECT p.name, COUNT(r.id) AS total FROM programs p
  LEFT JOIN ppdb_registrations r ON r.program_id = p.id
  GROUP BY p.id ORDER BY total DESC, p.name ASC
")->fetchAll();

$recentPpdb = $pdo->query("SELECT r.*, p.name AS program_name FROM ppdb_registrations r LEFT JOIN programs p ON p.id=r.program_id ORDER BY r.created_at DESC LIMIT 6")->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';

$statusClass = ['Menunggu'=>'badge-warning','Diverifikasi'=>'badge-info','Diterima'=>'badge-success','Ditolak'=>'badge-danger'];
?>
<section class="dashboard-welcome">
  <div class="dashboard-welcome-content">
    <div class="dashboard-eyebrow">Panel Administrasi • SMK INFOKOM BOGOR</div>
    <h1>Selamat datang, <?= e($currentAdmin['full_name']) ?> 👋</h1>
    <p>Pantau konten sekolah, data PPDB, guru & staff, publikasi berita, serta pesan masuk dari satu dashboard.</p>
    <div class="dashboard-date"><i class="fa-regular fa-calendar"></i><?= tanggalIndo(date('Y-m-d')) ?></div>
  </div>
</section>

<div class="kpi-grid">
  <div class="card kpi-card"><div><div class="kpi-value"><?= $totalPpdb ?></div><div class="kpi-label">Total Pendaftar PPDB</div></div><div class="kpi-icon"><i class="fa-solid fa-user-graduate"></i></div></div>
  <div class="card kpi-card"><div><div class="kpi-value"><?= $newPpdb ?></div><div class="kpi-label">Pendaftar Menunggu</div></div><div class="kpi-icon"><i class="fa-solid fa-hourglass-half"></i></div></div>
  <div class="card kpi-card"><div><div class="kpi-value"><?= $totalNews ?></div><div class="kpi-label">Total Berita</div></div><div class="kpi-icon"><i class="fa-solid fa-newspaper"></i></div></div>
  <div class="card kpi-card"><div><div class="kpi-value"><?= $totalStaff ?></div><div class="kpi-label">Guru & Staff Aktif</div></div><div class="kpi-icon"><i class="fa-solid fa-users"></i></div></div>
  <div class="card kpi-card"><div><div class="kpi-value"><?= $totalPrograms ?></div><div class="kpi-label">Program Keahlian</div></div><div class="kpi-icon"><i class="fa-solid fa-layer-group"></i></div></div>
  <div class="card kpi-card"><div><div class="kpi-value"><?= $totalGallery ?></div><div class="kpi-label">Item Galeri</div></div><div class="kpi-icon"><i class="fa-solid fa-images"></i></div></div>
  <div class="card kpi-card"><div><div class="kpi-value"><?= $totalAchievements ?></div><div class="kpi-label">Total Prestasi</div></div><div class="kpi-icon"><i class="fa-solid fa-trophy"></i></div></div>
  <div class="card kpi-card"><div><div class="kpi-value"><?= $unreadMessages ?></div><div class="kpi-label">Pesan Belum Dibaca</div></div><div class="kpi-icon"><i class="fa-solid fa-envelope"></i></div></div>
</div>

<div class="dashboard-grid">
  <div class="card chart-card">
    <div class="card-header"><h3>Distribusi Pendaftar PPDB per Jurusan</h3><a href="ppdb.php" class="btn btn-outline btn-sm">Kelola PPDB</a></div>
    <div class="card-body"><div style="position:relative;height:280px;"><canvas id="ppdbChart"></canvas></div></div>
  </div>

  <aside class="card">
    <div class="card-header"><h3>Akses Cepat</h3></div>
    <div class="card-body">
      <div class="quick-actions">
        <a class="quick-action primary" href="ppdb.php"><i class="fa-solid fa-user-graduate"></i><span>Data PPDB</span></a>
        <a class="quick-action" href="guru-staff.php"><i class="fa-solid fa-users"></i><span>Guru & Staff</span></a>
        <a class="quick-action" href="berita-form.php"><i class="fa-solid fa-newspaper"></i><span>Tambah Berita</span></a>
        <a class="quick-action" href="profil.php#banner"><i class="fa-solid fa-panorama"></i><span>Banner Slider</span></a>
        <a class="quick-action" href="profil.php"><i class="fa-solid fa-school"></i><span>Profil Sekolah</span></a>
        <a class="quick-action" href="kontak.php"><i class="fa-solid fa-envelope"></i><span>Pesan Masuk</span></a>
      </div>
      <div style="height:12px"></div>
      <div class="dashboard-note"><i class="fa-solid fa-circle-info"></i><span>Gunakan menu <strong>Profil Sekolah</strong> untuk memperbarui sejarah, visi-misi, sambutan, dan informasi utama sekolah.</span></div>
    </div>
  </aside>
</div>

<div class="card">
  <div class="card-header"><h3>Pendaftar PPDB Terbaru</h3><a href="ppdb.php" class="btn btn-outline btn-sm">Lihat Semua</a></div>
  <div class="card-body table-responsive">
    <?php if (!$recentPpdb): ?>
      <div class="empty-state"><i class="fa-solid fa-inbox"></i><p>Belum ada data pendaftar.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>No. Pendaftaran</th><th>Nama</th><th>Jurusan</th><th>Tanggal</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($recentPpdb as $r): ?>
            <tr>
              <td><strong><?= e($r['registration_number']) ?></strong></td>
              <td><?= e($r['full_name']) ?></td>
              <td><?= e($r['program_name'] ?? '-') ?></td>
              <td><?= tanggalIndo($r['created_at']) ?></td>
              <td><span class="badge <?= $statusClass[$r['status']] ?? 'badge-gray' ?>"><?= e($r['status']) ?></span></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
const chartEl = document.getElementById('ppdbChart');
if (chartEl && typeof Chart !== 'undefined') {
  new Chart(chartEl, {
    type: 'bar',
    data: {
      labels: <?= json_encode(array_column($ppdbByProgram, 'name'), JSON_UNESCAPED_UNICODE) ?>,
      datasets: [{
        label: 'Jumlah Pendaftar',
        data: <?= json_encode(array_map('intval', array_column($ppdbByProgram, 'total'))) ?>,
        backgroundColor: '#0d4d91',
        borderRadius: 9,
        maxBarThickness: 42
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: { color: '#74879a', font: { size: 10 } } },
        y: { beginAtZero: true, ticks: { precision: 0, color: '#74879a' }, grid: { color: '#e8eff5' } }
      }
    }
  });
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>

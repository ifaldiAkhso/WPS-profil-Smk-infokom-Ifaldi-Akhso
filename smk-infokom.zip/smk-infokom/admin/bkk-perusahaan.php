<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Perusahaan Mitra';
ensureBkkTables($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    if ($action === 'delete') {
        $pdo->prepare("DELETE FROM partner_companies WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Perusahaan mitra berhasil dihapus.');
        redirect('bkk-perusahaan.php');
    } elseif ($action === 'toggle') {
        $pdo->prepare("UPDATE partner_companies SET is_partner = 1 - is_partner WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Status mitra berhasil diperbarui.');
        redirect('bkk-perusahaan.php');
    }
}

$search = trim($_GET['q'] ?? '');
$where = [];
$params = [];
if ($search !== '') { $where[] = "name LIKE ?"; $params[] = "%$search%"; }
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
$stmt = $pdo->prepare("SELECT * FROM partner_companies $whereSql ORDER BY name ASC");
$stmt->execute($params);
$list = $stmt->fetchAll();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header">
    <h3>Daftar Perusahaan Mitra</h3>
    <a href="bkk-perusahaan-form.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Tambah Perusahaan</a>
  </div>
  <div class="card-body">
    <form method="get" class="filter-bar">
      <input type="text" name="q" class="form-control" placeholder="Cari nama perusahaan" value="<?= e($search) ?>">
      <button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Cari</button>
      <?php if ($search !== ''): ?><a href="bkk-perusahaan.php" class="btn btn-outline btn-sm">Reset</a><?php endif; ?>
    </form>

    <div class="table-responsive" style="margin-top:18px;">
    <?php if (count($list) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-handshake"></i><p>Belum ada data perusahaan mitra.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Logo</th><th>Nama</th><th>Bidang</th><th>Lokasi</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($list as $c): ?>
          <tr>
            <td><?php if (uploadExists($c['logo'])): ?><img src="<?= uploadUrl($c['logo']) ?>" class="thumb-sm" alt=""><?php else: ?><span class="muted">-</span><?php endif; ?></td>
            <td><?= trim((string)$c['name']) !== '' ? e($c['name']) : '<em style="color:#b42318;">(nama kosong - silakan edit atau hapus)</em>' ?></td>
            <td><?= e($c['field'] ?: '-') ?></td>
            <td><?= e($c['location'] ?: '-') ?></td>
            <td>
              <form method="post" style="display:inline;">
                <?= csrfField() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                <button type="submit" class="badge <?= (int)$c['is_partner'] === 1 ? 'badge-success' : 'badge-gray' ?>" style="border:0;cursor:pointer;">
                  <?= (int)$c['is_partner'] === 1 ? 'Mitra Aktif' : 'Nonaktif' ?>
                </button>
              </form>
            </td>
            <td class="actions"><div class="row-actions">
              <a href="<?= BASE_URL ?>bkk-perusahaan-detail.php?id=<?= (int)$c['id'] ?>" target="_blank" class="btn btn-outline btn-sm btn-icon" title="Lihat"><i class="fa-solid fa-eye"></i></a>
              <a href="bkk-perusahaan-form.php?id=<?= (int)$c['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus perusahaan ini? Lowongan terkait juga akan terhapus.')" style="display:inline;">
                <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

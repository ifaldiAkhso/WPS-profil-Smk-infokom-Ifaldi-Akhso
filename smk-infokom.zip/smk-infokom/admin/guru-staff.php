<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Guru & Staff';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $upload = handleImageUpload('photo', 'staff');
        if (!$upload['ok']) {
            setFlash('error', $upload['message']);
        } else {
            $id = (int)($_POST['id'] ?? 0);
            $category = $_POST['category'] === 'staff' ? 'staff' : 'guru';
            $isActive = isset($_POST['is_active']) ? 1 : 0;
            if ($id > 0) {
                $existing = $pdo->prepare("SELECT photo, nip, sort_order FROM staff WHERE id=?");
                $existing->execute([$id]);
                $existingRow = $existing->fetch();
                $photo = $upload['file'] ?? ($existingRow['photo'] ?? null);
                $nip = $existingRow['nip'] ?? '';
                $sortOrder = (int)($existingRow['sort_order'] ?? 0);
                $stmt = $pdo->prepare("UPDATE staff SET name=?, category=?, position=?, subject=?, nip=?, photo=?, sort_order=?, is_active=? WHERE id=?");
                $stmt->execute([trim($_POST['name'] ?? ''), $category, trim($_POST['position'] ?? ''), trim($_POST['subject'] ?? ''), $nip, $photo, $sortOrder, $isActive, $id]);
                setFlash('success', 'Data guru/staff berhasil diperbarui.');
            } else {
                $sortOrder = (int)$pdo->query("SELECT COALESCE(MAX(sort_order),0)+1 FROM staff")->fetchColumn();
                $stmt = $pdo->prepare("INSERT INTO staff (name, category, position, subject, nip, photo, sort_order, is_active) VALUES (?,?,?,?,?,?,?,?)");
                $stmt->execute([trim($_POST['name'] ?? ''), $category, trim($_POST['position'] ?? ''), trim($_POST['subject'] ?? ''), '', $upload['file'], $sortOrder, $isActive]);
                setFlash('success', 'Data guru/staff berhasil ditambahkan.');
            }
        }
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM staff WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Data berhasil dihapus.');
    }
    redirect('guru-staff.php');
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM staff WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editItem = $stmt->fetch();
}

$filter = $_GET['filter'] ?? 'all';
$sql = "SELECT * FROM staff";
if ($filter === 'guru' || $filter === 'staff') {
    $sql .= " WHERE category = " . $pdo->quote($filter);
}
$sql .= " ORDER BY category = 'staff', sort_order ASC, name ASC";
$allItems = $pdo->query($sql)->fetchAll();
$totalGuru = (int)$pdo->query("SELECT COUNT(*) FROM staff WHERE category='guru'")->fetchColumn();
$totalStaff = (int)$pdo->query("SELECT COUNT(*) FROM staff WHERE category='staff'")->fetchColumn();

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="kpi-grid">
  <div class="kpi-card">
    <div><div class="kpi-value"><?= $totalGuru + $totalStaff ?></div><div class="kpi-label">Total Guru & Staff</div></div>
    <div class="kpi-icon"><i class="fa-solid fa-people-group"></i></div>
  </div>
  <div class="kpi-card">
    <div><div class="kpi-value"><?= $totalGuru ?></div><div class="kpi-label">Guru</div></div>
    <div class="kpi-icon"><i class="fa-solid fa-chalkboard-user"></i></div>
  </div>
  <div class="kpi-card">
    <div><div class="kpi-value"><?= $totalStaff ?></div><div class="kpi-label">Staff / Tenaga Kependidikan</div></div>
    <div class="kpi-icon"><i class="fa-solid fa-user-tie"></i></div>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3><?= $editItem ? 'Edit Data Guru/Staff' : 'Tambah Guru/Staff Baru' ?></h3></div>
  <div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editItem['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group"><label>Nama Lengkap <span class="req">*</span></label><input type="text" name="name" maxlength="150" class="form-control" required value="<?= e($editItem['name'] ?? '') ?>"></div>
        <div class="form-group">
          <label>Kategori <span class="req">*</span></label>
          <select name="category" class="form-control">
            <option value="guru" <?= ($editItem['category'] ?? 'guru') === 'guru' ? 'selected' : '' ?>>Guru</option>
            <option value="staff" <?= ($editItem['category'] ?? '') === 'staff' ? 'selected' : '' ?>>Staff / Tenaga Kependidikan</option>
          </select>
        </div>
        <div class="form-group"><label>Jabatan</label><input type="text" name="position" maxlength="150" class="form-control" placeholder="Contoh: Wali Kelas XI RPL 1 / Kepala Tata Usaha" value="<?= e($editItem['position'] ?? '') ?>"></div>
        <div class="form-group"><label>Mata Pelajaran Diampu (khusus guru)</label><input type="text" name="subject" maxlength="150" class="form-control" placeholder="Contoh: Pemrograman Web" value="<?= e($editItem['subject'] ?? '') ?>"></div>
        <div class="form-group full">
          <label>Foto</label>
          <input type="file" name="photo" class="form-control js-image-preview" data-preview-target="staffPhotoPreview" accept="image/*">
          <img id="staffPhotoPreview" class="img-preview" style="display:<?= !empty($editItem['photo']) ? 'block' : 'none' ?>;" src="<?= uploadUrl($editItem['photo'] ?? null) ?>">
        </div>
        <div class="form-group full">
          <label><input type="checkbox" name="is_active" value="1" <?= (!isset($editItem) || (int)($editItem['is_active'] ?? 1) === 1) ? 'checked' : '' ?>> Tampilkan di halaman publik</label>
        </div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <?php if ($editItem): ?><a href="guru-staff.php" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <h3>Daftar Guru & Staff</h3>
    <div style="display:flex;gap:8px;">
      <a href="?filter=all" class="btn btn-sm <?= $filter === 'all' ? 'btn-primary' : 'btn-outline' ?>">Semua</a>
      <a href="?filter=guru" class="btn btn-sm <?= $filter === 'guru' ? 'btn-primary' : 'btn-outline' ?>">Guru</a>
      <a href="?filter=staff" class="btn btn-sm <?= $filter === 'staff' ? 'btn-primary' : 'btn-outline' ?>">Staff</a>
    </div>
  </div>
  <div class="card-body table-responsive">
    <?php if (count($allItems) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-chalkboard-user"></i><p>Belum ada data guru/staff.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Foto</th><th>Nama</th><th>Kategori</th><th>Jabatan</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($allItems as $s): ?>
          <tr>
            <td><img src="<?= uploadUrl($s['photo'], 'assets/images/avatar-placeholder.jpg') ?>" class="thumb-sm"></td>
            <td><?= e($s['name']) ?></td>
            <td><span class="badge <?= $s['category'] === 'guru' ? 'badge-info' : 'badge-gray' ?>"><?= $s['category'] === 'guru' ? 'Guru' : 'Staff' ?></span></td>
            <td><?= e($s['position'] ?: '-') ?></td>
            <td><span class="badge <?= (int)$s['is_active'] === 1 ? 'badge-success' : 'badge-danger' ?>"><?= (int)$s['is_active'] === 1 ? 'Tampil' : 'Disembunyikan' ?></span></td>
            <td class="actions"><div class="row-actions">
              <a href="?edit=<?= (int)$s['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus data ini?')" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

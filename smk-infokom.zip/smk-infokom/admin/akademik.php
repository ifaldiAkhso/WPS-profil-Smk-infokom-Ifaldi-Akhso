<?php
require_once __DIR__ . '/includes/auth.php';
$pdo = getDB();
$pageTitle = 'Informasi Akademik';
ensureAcademicTable($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $icon = trim($_POST['icon'] ?? '') ?: 'fa-solid fa-book-open';
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $sectionKey = in_array($_POST['section_key'] ?? '', ['kurikulum', 'kalender'], true) ? $_POST['section_key'] : 'kurikulum';
        if ($title === '') {
            setFlash('error', 'Judul wajib diisi.');
        } elseif ($id > 0) {
            $pdo->prepare("UPDATE academic_info SET section_key=?, title=?, content=?, icon=?, sort_order=?, is_active=? WHERE id=?")
                ->execute([$sectionKey, $title, trim($_POST['content'] ?? ''), $icon, (int)($_POST['sort_order'] ?? 0), $isActive, $id]);
            setFlash('success', 'Informasi akademik berhasil diperbarui.');
        } else {
            $pdo->prepare("INSERT INTO academic_info (section_key, title, content, icon, sort_order, is_active) VALUES (?,?,?,?,?,?)")
                ->execute([$sectionKey, $title, trim($_POST['content'] ?? ''), $icon, (int)($_POST['sort_order'] ?? 0), $isActive]);
            setFlash('success', 'Informasi akademik berhasil ditambahkan.');
        }
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM academic_info WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'Informasi akademik berhasil dihapus.');
    }
    redirect('akademik.php');
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM academic_info WHERE id=?");
    $stmt->execute([(int)$_GET['edit']]);
    $editItem = $stmt->fetch() ?: null;
}
$items = academicSections($pdo, false);

include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidebar.php';
include __DIR__ . '/includes/topbar.php';
?>
<div class="card">
  <div class="card-header"><h3><?= $editItem ? 'Edit Informasi Akademik' : 'Tambah Informasi Akademik' ?></h3></div>
  <div class="card-body">
    <p class="form-hint" style="margin-top:0;">Bagian ini tampil di halaman <b>Akademik</b> (di bawah daftar program keahlian), terbagi dua kelompok: <b>Kurikulum</b> dan <b>Kalender Pendidikan</b>. Pilih jenisnya di bawah — kalau tidak dipilih, entri baru tidak akan muncul di kelompok yang benar. PKL dikelola di menu <b>Konten PKL</b>, Ekstrakurikuler di menu <b>Ekstrakurikuler</b>.</p>
    <form method="post">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editItem['id'] ?? 0) ?>">
      <div class="form-grid">
        <div class="form-group">
          <label>Jenis <span class="req">*</span></label>
          <select name="section_key" class="form-control">
            <option value="kurikulum" <?= ($editItem['section_key'] ?? 'kurikulum') === 'kurikulum' ? 'selected' : '' ?>>Kurikulum</option>
            <option value="kalender" <?= ($editItem['section_key'] ?? '') === 'kalender' ? 'selected' : '' ?>>Kalender Pendidikan</option>
          </select>
        </div>
        <div class="form-group"><label>Judul <span class="req">*</span></label><input type="text" name="title" class="form-control" required maxlength="150" placeholder="Contoh: Kurikulum" value="<?= e($editItem['title'] ?? '') ?>"></div>
        <div class="form-group"><label>Urutan</label><input type="number" name="sort_order" class="form-control" value="<?= (int)($editItem['sort_order'] ?? 0) ?>"></div>
        <div class="form-group full"><label>Isi / Penjelasan</label><textarea name="content" class="form-control" style="min-height:130px;" placeholder="Untuk Kalender Pendidikan, tulis satu kegiatan per baris dengan format: Tanggal | Kegiatan&#10;Contoh: 14 Juli 2026 | Awal Tahun Ajaran Baru"><?= e($editItem['content'] ?? '') ?></textarea><p class="form-hint">Khusus <b>Kalender Pendidikan</b>: tulis satu baris per kegiatan dengan format <code>Tanggal | Kegiatan</code> agar tampil rapi sebagai tabel. Untuk Kurikulum, tulis sebagai paragraf biasa.</p></div>
        <div class="form-group"><label>Ikon (Font Awesome class)</label><input type="text" name="icon" class="form-control" maxlength="60" placeholder="fa-solid fa-book-open" value="<?= e($editItem['icon'] ?? 'fa-solid fa-book-open') ?>"></div>
        <div class="form-group"><label style="margin-top:28px;"><input type="checkbox" name="is_active" value="1" <?= (!$editItem || (int)$editItem['is_active'] === 1) ? 'checked' : '' ?>> Tampilkan di website</label></div>
      </div>
      <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
      <?php if ($editItem): ?><a href="akademik.php" class="btn btn-outline">Batal</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header"><h3>Daftar Informasi Akademik</h3></div>
  <div class="card-body table-responsive">
    <?php if (count($items) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-graduation-cap"></i><p>Belum ada informasi akademik.</p></div>
    <?php else: ?>
      <table class="data-table">
        <thead><tr><th>Jenis</th><th>Ikon</th><th>Judul</th><th>Status</th><th>Urutan</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($items as $it): ?>
          <tr>
            <td><span class="badge badge-gray"><?= $it['section_key'] === 'kalender' ? 'Kalender' : 'Kurikulum' ?></span></td>
            <td style="width:50px;"><i class="<?= e($it['icon']) ?>" style="font-size:1.2rem;color:var(--navy-800);"></i></td>
            <td><?= e($it['title']) ?></td>
            <td><?= (int)$it['is_active'] === 1 ? '<span class="badge badge-success">Tampil</span>' : '<span class="badge badge-gray">Disembunyikan</span>' ?></td>
            <td><?= (int)$it['sort_order'] ?></td>
            <td class="actions"><div class="row-actions">
              <a href="?edit=<?= (int)$it['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
              <form method="post" onsubmit="return confirm('Hapus informasi ini?')">
                <?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                <button class="btn btn-danger btn-sm btn-icon" type="submit" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
              </form>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>

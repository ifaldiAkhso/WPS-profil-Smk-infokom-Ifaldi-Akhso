# Website Resmi SMK INFOKOM BOGOR

Website profil sekolah lengkap dengan PPDB Online & Dashboard Admin.
Dibangun dengan **PHP Native 8+, PDO, MySQL/MariaDB, HTML5, CSS3, JavaScript Vanilla** (tanpa framework frontend).

---

## 1. Struktur Folder

```
smk-infokom/
├── index.php, profil.php, sejarah.php, visi-misi.php, sambutan.php,
│   struktur.php, fasilitas.php, akademik.php, berita.php, detail-berita.php,
│   galeri.php, prestasi.php, ppdb.php, ppdb-sukses.php, cek-status.php, kontak.php
├── assets/
│   ├── css/frontend.css     (frontend publik, SATU file)
│   ├── css/admin.css        (dashboard admin)
│   ├── js/script.js         (frontend publik)
│   ├── js/admin.js          (dashboard admin)
│   ├── images/              (placeholder & logo)
│   └── uploads/             (file upload dari admin: berita, galeri, jurusan, prestasi, fasilitas, lainnya)
├── config/database.php      (koneksi PDO)
├── includes/                (header, navbar, footer, functions.php)
├── admin/
│   ├── login.php, logout.php, dashboard.php
│   ├── profil.php, statistik.php, struktur.php, banner.php
│   ├── berita.php + berita-form.php
│   ├── program.php + program-form.php
│   ├── galeri.php, fasilitas.php
│   ├── prestasi.php + prestasi-form.php
│   ├── agenda.php, pengumuman.php
│   ├── ppdb.php, ppdb-detail.php, ppdb-pengaturan.php
│   ├── kontak.php (pesan masuk), pengaturan.php (akun admin)
│   └── includes/ (auth.php, head.php, sidebar.php, topbar.php, footer.php)
└── database/database.sql
```

---

## 2. Instalasi dengan XAMPP

### Langkah 1 — Salin Folder Project
Salin/ekstrak folder `smk-infokom` ke:
- **Windows**: `C:\xampp\htdocs\smk-infokom\`
- **Linux**: `/opt/lampp/htdocs/smk-infokom/`

### Langkah 2 — Import Database
1. Jalankan **Apache** dan **MySQL** dari XAMPP Control Panel.
2. Buka `http://localhost/phpmyadmin`.
3. Klik **New**, buat database (atau langsung import, database akan otomatis dibuat).
4. Klik tab **Import** → pilih file `database/database.sql` → klik **Go**.
5. Pastikan database `smk_infokom` berhasil terbentuk dengan seluruh tabelnya.

> ⚠️ **PENTING — Pindah ke Laptop/Server Lain**: File `database.sql` hanya berisi DATA TEKS (nama, judul, path/nama file gambar), **BUKAN file gambarnya**. Semua file gambar/foto yang pernah diunggah lewat admin tersimpan fisik di folder `assets/uploads/`. Jadi setiap kali memindahkan website ke laptop/server lain, selain meng-import `database.sql`, Anda **WAJIB ikut menyalin seluruh folder `assets/uploads/`** (misalnya lewat flashdisk, zip, atau cloud) ke lokasi project yang baru. Jika folder ini tidak ikut disalin, semua gambar akan tampil rusak/kosong karena path di database menunjuk ke file yang tidak ada di komputer baru.

Atau via terminal:
```bash
mysql -u root -p < database/database.sql
```

### Langkah 3 — Konfigurasi Koneksi Database
Buka `config/database.php`, sesuaikan bila perlu (default sudah cocok untuk XAMPP default):
```php
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'smk_infokom');
define('DB_USER', 'root');
define('DB_PASS', '');       // isi jika MySQL root Anda memakai password
```
`BASE_URL` (alamat dasar situs) sekarang **dideteksi otomatis**, jadi folder project boleh diberi nama apa saja
(mis. `smk-infokom-modern`) atau diletakkan langsung di root. Anda tidak perlu mengubah apa pun.
Jika deteksi otomatis tidak cocok dengan server Anda, buka `config/database.php` dan ganti baris
`define('BASE_URL', detectBaseUrl());` dengan nilai tetap, misalnya `define('BASE_URL', '/nama-folder-anda/');`.

### Langkah 4 — Jalankan Apache & MySQL
Nyalakan kedua service tersebut dari **XAMPP Control Panel**.

### Langkah 5 — Buka Website
- **Website Publik**: http://localhost/smk-infokom/
- **Login Admin**: http://localhost/smk-infokom/admin/login.php

### Langkah 6 — Login Admin (Akun Awal untuk Testing)
```
Username : admin
Password : Admin@123
```
⚠️ **WAJIB segera diganti** setelah login pertama, melalui menu **Pengaturan Admin → Ganti Password**.

### Langkah 7 — Mengecek Data PPDB Masuk Database
1. Isi & kirim form di halaman **PPDB Online** (`ppdb.php`) pada website publik.
2. Catat nomor pendaftaran yang muncul di halaman sukses.
3. Login sebagai admin → menu **PPDB → Data Pendaftar**, data akan langsung terlihat (bersumber langsung dari tabel `ppdb_registrations`).
4. Anda juga bisa memverifikasi melalui phpMyAdmin → tabel `ppdb_registrations`.

### Langkah 8 — Mengatasi Error Umum
| Gejala | Solusi |
|---|---|
| "Koneksi database gagal" | Pastikan service MySQL XAMPP menyala & kredensial di `config/database.php` benar |
| Halaman blank / error 500 | Aktifkan `display_errors` di `php.ini` sementara untuk debugging, cek `error_log` Apache |
| Upload gambar gagal | Pastikan folder `assets/uploads/*` memiliki izin tulis (`chmod 755` di Linux) |
| CSS/JS tidak termuat | `BASE_URL` dideteksi otomatis; bila tetap gagal, isi manual di `config/database.php` (lihat Langkah 3) |
| Klik **Simpan** di admin, tampil pesan merah | Baca pesannya: biasanya isian terlalu panjang, nama duplikat, sesi kedaluwarsa, atau gambar melebihi 2MB (cek juga `upload_max_filesize` & `post_max_size` di `php.ini`) |
| Konten halaman kosong / tidak muncul | Pastikan file `assets/js/script.js` dapat diakses; tekan Ctrl+F5 untuk membersihkan cache browser |
| Ikon tombol tampil kosong | Ikon Font Awesome dimuat dari internet (CDN). Tanpa internet ikon tidak tampil, tetapi tombol tetap berfungsi (arahkan kursor untuk melihat tooltip) |
| Login admin gagal terus | Pastikan tabel `admins` berhasil ter-import dan berisi 1 baris data awal |

---

## 3. Akun Admin Default

| Username | Password | Role |
|---|---|---|
| admin | Admin@123 | Superadmin |

Cara mengganti password: **Login Admin → menu Pengaturan Admin (ikon profil pojok kanan atas) → form "Ganti Password"**.

---

## 4. Data yang Masih Perlu Dilengkapi Admin

Karena data resmi seperti nama Kepala Sekolah, sejarah lengkap, visi-misi, dan struktur organisasi tidak tersedia saat pembuatan website, field tersebut diisi **placeholder** yang jelas ditandai, misalnya `[NAMA KEPALA SEKOLAH]`, `[ISI SEJARAH SEKOLAH]`, dsb. Silakan lengkapi melalui:
- **Admin → Profil Sekolah** (sejarah, visi, misi, sambutan kepala sekolah, kontak)
- **Admin → Struktur Organisasi**
- **Admin → PPDB → Pengaturan PPDB** (persyaratan, alur, FAQ)

Data alamat, telepon, email, dan NPSN sudah diisi berdasarkan informasi publik resmi SMK INFOKOM BOGOR (Jl. Letjend Ibrahim Adjie No. 178, Bogor Barat, NPSN 20238531) — silakan periksa dan sesuaikan kembali bila diperlukan.

---

## 5. Checklist Testing

- [x] Tidak ada syntax error PHP (lolos `php -l` pada seluruh file)
- [x] Koneksi PDO ke MySQL berjalan
- [x] Login admin bekerja (bcrypt + prepared statement + rate limiting sederhana)
- [x] Logout & proteksi session (auto logout 2 jam idle) bekerja
- [x] Dashboard admin menampilkan statistik real dari database
- [x] CRUD Berita, Program Keahlian, Galeri, Prestasi, Fasilitas, Agenda, Pengumuman bekerja
- [x] Upload gambar tervalidasi (ekstensi, MIME, ukuran maks 8MB, otomatis dikecilkan) & tersimpan ke `assets/uploads/`
- [x] Form PPDB tersimpan ke MySQL & menghasilkan nomor pendaftaran otomatis (teruji end-to-end)
- [x] Cek Status PPDB menampilkan data sesuai nomor pendaftaran (teruji end-to-end)
- [x] Berita tampil dari database ke halaman publik & halaman detail (teruji end-to-end)
- [x] Statistik, galeri, jurusan tampil dari database dengan empty-state jika kosong
- [x] Halaman kontak & pesan masuk ke admin
- [x] Mobile responsive (hamburger menu, grid menyesuaikan, tabel admin scroll horizontal)
- [x] Tanpa dark mode
- [x] Tidak ada nama sekolah lain selain SMK INFOKOM BOGOR
- [x] Tidak ada menu E-Learning yang tidak diminta
- [x] Query menggunakan PDO prepared statement (aman dari SQL Injection — teruji dengan payload `' OR '1'='1`)
- [x] CSRF token pada seluruh form penting (login, PPDB, CRUD admin)

---

## 6. Catatan Keamanan

- Password admin di-hash dengan `password_hash()` (bcrypt) dan diverifikasi dengan `password_verify()`.
- Semua query database memakai **PDO prepared statement**.
- Upload gambar divalidasi ekstensi + MIME type + ukuran, nama file di-random agar tidak bisa dieksekusi sebagai script.
- CSRF token disematkan di setiap form POST penting.
- Halaman admin diproteksi session (`admin/includes/auth.php`), otomatis logout setelah 2 jam tidak aktif.
- Output di-escape dengan `htmlspecialchars()` melalui fungsi helper `e()` untuk mencegah XSS.

Selamat menggunakan website SMK INFOKOM BOGOR! 🎓

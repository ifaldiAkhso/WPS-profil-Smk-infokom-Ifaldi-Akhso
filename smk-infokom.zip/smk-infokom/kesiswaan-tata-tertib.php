<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-akademik no-footer';
$pdo = getDB();
$pageTitle = 'Tata Tertib';
ensureKesiswaanTables($pdo);

$allRules = $pdo->query("SELECT * FROM student_rules WHERE is_active = 1 ORDER BY sort_order ASC, id ASC")->fetchAll();

$grouped = [];
foreach ($allRules as $r) {
    $grouped[$r['category']][] = $r;
}
$categoryOrder = studentRuleCategories();
// kategori yang ada di data tapi di luar urutan baku tetap ditampilkan di akhir
foreach (array_keys($grouped) as $cat) {
    if (!in_array($cat, $categoryOrder, true)) $categoryOrder[] = $cat;
}

$intro = $grouped['Pengantar'][0] ?? null;

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'Kesiswaan';
$heroTitle   = 'Tata Tertib';
$heroText    = 'Panduan hak, kewajiban, dan ketentuan bagi siswa SMK INFOKOM BOGOR.';
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Kesiswaan', BASE_URL . 'kesiswaan.php'], ['Tata Tertib', null]];
$heroImage = null;
include __DIR__ . '/includes/page-hero.php';

$catIcons = [
    'Pengantar' => 'fa-solid fa-book-open',
    'Hak Siswa' => 'fa-solid fa-hand-holding-heart',
    'Kewajiban Siswa' => 'fa-solid fa-list-check',
    'Ketentuan Seragam' => 'fa-solid fa-shirt',
    'Ketentuan Kehadiran' => 'fa-solid fa-calendar-check',
    'Peraturan Umum' => 'fa-solid fa-gavel',
    'Larangan' => 'fa-solid fa-ban',
    'Jenis Pelanggaran' => 'fa-solid fa-triangle-exclamation',
    'Sanksi' => 'fa-solid fa-scale-balanced',
    'Ketentuan Tambahan' => 'fa-solid fa-circle-plus',
];
?>
<section class="profile-section">
  <div class="container">

    <div class="profile-heading reveal">
      <div class="article-kicker"><span></span> Tata Tertib <span></span></div>
      <h2>Tata Tertib Siswa</h2>
      <p>Disusun agar proses belajar mengajar berjalan tertib, aman, dan nyaman bagi seluruh warga sekolah.</p>
    </div>

    <div class="ks-rule-intro reveal">
      <?php if ($intro && trim((string)$intro['content']) !== ''): ?>
        <?= nl2br(e($intro['content'])) ?>
      <?php else: ?>
        Tata tertib ini berlaku bagi seluruh siswa SMK INFOKOM BOGOR selama berada di lingkungan sekolah maupun saat mengikuti kegiatan yang diselenggarakan oleh sekolah. Setiap siswa wajib memahami dan mematuhi seluruh ketentuan yang berlaku.
      <?php endif; ?>
    </div>

    <?php if (count($allRules) === 0): ?>
      <div class="empty-state modern-empty" style="margin-top:26px;"><i class="fa-solid fa-scale-balanced"></i><p>Isi tata tertib belum tersedia. Admin dapat mengisinya melalui Dashboard Admin &gt; Kesiswaan &gt; Tata Tertib.</p></div>
    <?php else: ?>
      <div class="ks-rule-groups">
        <?php foreach ($categoryOrder as $cat): ?>
          <?php if ($cat === 'Pengantar' || empty($grouped[$cat])) continue; ?>
          <div class="faq-item reveal">
            <div class="faq-question"><span><i class="<?= e($catIcons[$cat] ?? 'fa-solid fa-list') ?>"></i> <?= e($cat) ?></span> <i class="fa-solid fa-chevron-down"></i></div>
            <div class="faq-answer">
              <ul class="ks-rule-list">
                <?php foreach ($grouped[$cat] as $i => $r): ?>
                  <li>
                    <span class="ks-rule-num"><?= $i + 1 ?></span>
                    <div>
                      <strong><?= e($r['title']) ?></strong>
                      <?php if (trim((string)$r['content']) !== ''): ?><span><?= nl2br(e($r['content'])) ?></span><?php endif; ?>
                    </div>
                  </li>
                <?php endforeach; ?>
              </ul>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="ks-rule-highlight reveal">
        <i class="fa-solid fa-circle-info"></i>
        <p>Pelanggaran terhadap tata tertib ini akan ditindaklanjuti sesuai dengan jenis pelanggaran dan sanksi yang berlaku di sekolah. Untuk informasi lebih lanjut, siswa dan orang tua/wali dapat menghubungi pihak Kesiswaan sekolah.</p>
      </div>
    <?php endif; ?>

  </div>
</section>
<?php $backHref = BASE_URL . 'kesiswaan.php'; $backLabel = 'Kembali ke Kesiswaan'; include __DIR__ . '/includes/back-button.php'; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-info pf-info';
$pdo = getDB();
$pageTitle = 'Berita';
ensureNewsColumns($pdo);

$perPage = 9;
$page = max(1, (int)($_GET['page'] ?? 1));
$search = trim($_GET['q'] ?? '');
$categoryId = (int)($_GET['kategori'] ?? 0);

$where = ["n.status = 'published'"];  // hanya berita yang sudah dipublikasikan
$params = [];
if ($search !== '') {
    // Cari di judul, ringkasan, dan isi berita (karakter % dan _ dianggap teks biasa)
    $where[] = '(n.title LIKE ? OR n.excerpt LIKE ? OR n.content LIKE ?)';
    $like = likeParam($search);
    array_push($params, $like, $like, $like);
}
if ($categoryId > 0) { $where[] = 'n.category_id = ?'; $params[] = $categoryId; }
$whereSql = implode(' AND ', $where);

$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM news n WHERE $whereSql");
$totalStmt->execute($params);
$total = (int)$totalStmt->fetchColumn();
$totalPages = max(1, (int)ceil($total / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$sql = "SELECT n.*, c.name AS category_name FROM news n LEFT JOIN news_categories c ON c.id = n.category_id
        WHERE $whereSql ORDER BY n.published_at DESC, n.id DESC LIMIT $perPage OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$newsList = $stmt->fetchAll();

$categories = $pdo->query("SELECT * FROM news_categories ORDER BY name")->fetchAll();

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>
<?php
$heroEyebrow = 'Informasi';
$heroTitle = 'Berita Terbaru';
$heroText = 'Kabar, kegiatan, dan informasi terbaru dari SMK INFOKOM BOGOR.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['Berita', null]];
$heroImage = 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';
?>

<section>
  <div class="container">
    <?php
    $fbSearch = $search; $fbPlaceholder = 'Cari judul atau isi berita...'; $fbNoun = 'berita'; $fbTotal = $total;
    $fbSelects = [[
        'name' => 'kategori', 'label' => 'Kategori', 'all' => 'Semua Kategori',
        'options' => array_column($categories, 'name', 'id'), 'value' => $categoryId > 0 ? (string)$categoryId : '',
    ]];
    include __DIR__ . '/includes/filter-bar.php';
    ?>

    <?php if (count($newsList) === 0): ?>
      <div class="empty-state"><i class="fa-solid fa-newspaper"></i><p><?= ($search !== '' || $categoryId > 0) ? 'Tidak ada berita yang sesuai pencarian.' : 'Belum ada berita.' ?></p></div>
    <?php else: ?>
      <div class="nc-grid">
        <?php foreach ($newsList as $n): include __DIR__ . '/includes/news-card.php'; endforeach; ?>
      </div>

      <?php if ($totalPages > 1): ?>
        <?php $qs = fn(int $pg) => '?' . http_build_query(['page' => $pg, 'q' => $search, 'kategori' => $categoryId]); ?>
        <nav class="pager" aria-label="Halaman berita">
          <?php if ($page > 1): ?><a href="<?= e($qs($page - 1)) ?>" class="btn btn-sm btn-outline-navy" rel="prev"><i class="fa-solid fa-chevron-left"></i></a><?php endif; ?>
          <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="<?= e($qs($i)) ?>" class="btn btn-sm <?= $i === $page ? 'btn-primary' : 'btn-outline-navy' ?>" <?= $i === $page ? 'aria-current="page"' : '' ?>><?= $i ?></a>
          <?php endfor; ?>
          <?php if ($page < $totalPages): ?><a href="<?= e($qs($page + 1)) ?>" class="btn btn-sm btn-outline-navy" rel="next"><i class="fa-solid fa-chevron-right"></i></a><?php endif; ?>
        </nav>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

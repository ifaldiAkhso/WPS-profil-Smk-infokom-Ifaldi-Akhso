# Catatan Perbaikan

## Perubahan v13 — gambar "No Image" di detail lowongan

- Gambar abu-abu "No Image" adalah `placeholder.png`, dipakai sistem bila berkas foto tidak ditemukan. Kini poster lowongan hanya ditampilkan lewat `jobPosterUrl()`: berkas harus ada di `assets/uploads/` dan benar-benar gambar valid; bila tidak, kotak foto tidak dirender (tidak pernah ada gambar bawaan di halaman lowongan).
- Admin > Lowongan: setelah foto diunggah, sistem memeriksa berkasnya benar-benar tersimpan; bila tidak, muncul pesan error yang jelas (biasanya masalah izin folder `assets/uploads/lowongan`).

## Perubahan v12 — gambar bawaan "IB" dihapus total

- **Penyebab IB masih muncul**: bila nama file poster/logo tersimpan di database tetapi berkasnya tidak ada di `assets/uploads/`, `uploadUrl()` memakai gambar bawaan `logo-placeholder.png` (logo "IB"). Kini ada `uploadExists()`; poster lowongan hanya ditampilkan bila berkasnya benar-benar ada (`jobHasImage()`), jadi kotak gambar tidak muncul sama sekali bila tidak ada.
- Logo mitra yang berkasnya hilang tidak lagi diganti "IB": kartu Mitra memakai inisial perusahaan, daftar mitra di halaman PKL tampil tanpa gambar, tabel admin diberi tanda "-".
- Logo sekolah di navbar, footer, dan sidebar admin kini cadangan ke `logo-smk-infokom.png`. Berkas `assets/images/logo-placeholder.png` dihapus dari proyek.
- Bila poster lowongan ingin tampil lagi, unggah ulang poster di Admin > BKK > Lowongan > Edit.

## Perubahan v11 — BKK Lowongan

- Logo (termasuk logo "IB") tidak lagi ditampilkan di halaman lowongan: kotak foto hanya muncul bila lowongan punya poster sendiri. Berlaku di detail lowongan, kartu daftar, kartu di halaman Perusahaan Mitra, dan kolom gambar admin.
- Bagian "Deskripsi Pekerjaan" disembunyikan bila kosong (tidak lagi menampilkan teks "belum diisi").
- Daftar Persyaratan dirapikan untuk banyak poin: tiap poin dipisah garis tipis, teks panjang dan tautan tidak merusak tata letak, dan alamat web (https://...) otomatis menjadi tautan yang bisa diklik.

## Perubahan v10 — BKK Lowongan (lanjutan)

- Logo bawaan "IB" dihapus: gambar hanya tampil bila lowongan punya poster atau Mitra punya logo asli. Tanpa keduanya, detail lowongan tampil satu kolom tanpa kotak gambar, kartu daftar tanpa logo, dan kolom gambar admin diberi tanda "-" (fungsi baru `jobHasImage()` di `includes/functions.php`).
- Kartu daftar lowongan: poster kini penuh sampai tepi kartu (rasio mengikuti foto), isi teks dirapikan (judul, perusahaan, badge, lokasi/batas, tombol rata di bawah). Kartu lowongan di halaman detail Perusahaan Mitra memakai susunan yang sama.

## Perubahan v9 — BKK Lowongan

**Detail lowongan (`bkk-lowongan-detail.php`)**: tata letak dirapikan (foto di kiri, judul, badge Aktif, deskripsi, persyaratan, dan kotak info di kanan; di HP menumpuk ke bawah). Foto mengikuti bentuknya: poster potret tampil utuh (tidak terpotong, klik untuk memperbesar), poster lanskap tampil lebar di atas, tanpa poster dipakai logo kecil (bukan kotak besar kosong).

**Persyaratan**: selalu tampil sebagai daftar centang (satu poin per baris; tanda `-` atau nomor di depan dibuang otomatis). Bila belum diisi tampil catatan singkat. Di admin (`admin/bkk-lowongan-form.php`) isiannya diberi nama "Persyaratan Penting" lengkap dengan contoh dan petunjuk: tulis poin penting saja, satu poin per baris.

**Daftar lowongan & admin**: kartu poster di `bkk-lowongan.php` kini mengikuti rasio foto (potret tidak terpotong). Pratinjau gambar di form admin menampilkan foto utuh.

## Perubahan v8 (terbaru)

**Admin — tanda kuning dihapus**: label kuning "Belum di website" (di menu sidebar Agenda, Pengumuman, Prestasi Sekolah, isian Nama Sekolah, dan Alur Pendaftaran PPDB) beserta keterangan legenda di bawah sidebar sudah dihapus. Daftar di `admin/includes/frontend-status.php` dikosongkan, CSS `.tag-pending` dibuang dari `admin.css`.

**Mitra Industri — warna hitam saat klik/sentuh**: kartu mitra di halaman PKL (`.pkl-partner`) berubah menjadi hitam saat di-hover/diketuk (dan teks nama ikut gelap sehingga tidak terbaca). Sekarang tetap putih pada hover, klik, dan fokus (`assets/css/frontend.css`).

**Kunjungan Industri — tanpa nama otomatis**: bila judul dikosongkan, website tidak lagi membuat judul "Kunjungan ke ..." atau "Kunjungan Industri". Yang tampil hanya judul yang diisi admin; bila kosong dipakai nama perusahaan; bila itu juga kosong, judul disembunyikan. Eyebrow di halaman detail diganti "Informasi", teks contoh/petunjuk di form admin diperbarui (`visitTitle()` di `includes/functions.php`).

**Kunjungan Industri — foto potret**: kartu daftar dan foto di halaman detail kini mengikuti bentuk asli foto (potret, persegi, atau lanskap) memakai `imageRatio()`, tidak lagi dipaksa 16:10 sehingga foto potret tidak terpotong parah.

## Perubahan v7 (terbaru)

**Klik tanpa delay** — penyebab: dropdown desktop hanya terbuka setelah klik pertama (klik pertama pada induk diblokir), ada penutupan paksa 900 ms setelah klik, ada celah hover 10px, fade halaman 0,5 detik, smooth-scroll, dan transisi `all` pada semua tautan. Sekarang: dropdown terbuka saat kursor/fokus (tanpa celah), klik anak maupun induk langsung membuka halaman pada klik pertama; di tablet sentuh ketukan pertama membuka dropdown, kedua membuka halaman. Perbaikan ada di `assets/js/toast.js`, `assets/css/theme.css`, dan file baru `assets/css/final.css` (dimuat terakhir).

**Upload & pemindahan** — path di database sudah relatif (aman dipindah). Ditemukan: `database.sql` merujuk 104 file gambar, tetapi **87 tidak ada** di folder `assets/uploads` pada zip ini — itulah penyebab gambar "hilang". Salin seluruh folder `assets/uploads/` dari server/laptop lama bersama database. `uploadUrl()` kini menambahkan `?v=<waktu ubah file>` (anti cache lama) dan menampilkan placeholder bila file tidak ada. `.htaccess` menambah cache panjang yang aman karena URL berubah saat file berubah.

**Berita** — kartu (beranda, halaman Berita, Berita Terkait) dan sampul halaman detail memakai potret 4:5 ukuran sedang (kartu ±270px, sampul maks 400px); sampul bisa diklik untuk memperbesar. Hint unggah di admin menyebut rasio 4:5.

**FAQ PPDB** — desain baru dua kolom (intro + daftar bersih, buka-tutup native tanpa JS). Bug lama: baris FAQ tanpa tanda `?` tampil sebagai "Pertanyaan 1, 3, 5…". FAQ kini punya tabel `ppdb_faqs` dan halaman **Admin > Ubah FAQ** (tambah, edit, hapus, naik/turun, sembunyikan). Teks FAQ lama dipindahkan otomatis (format `Pertanyaan | Jawaban` atau `Pertanyaan? Jawaban`).

---

## Perubahan v6 (terbaru)

**Database**: `database/database.sql` diperbarui dari dump terbaru yang Anda kirim (sudah termasuk semua data yang sudah diisi), ditambah 1 kolom baru: `school_profile.kabar_video_url`. Kolom ini juga dibuat otomatis kalau belum ada, jadi database yang sudah berjalan tidak perlu diimpor ulang.

**Animasi Sejarah → Visi & Misi**: animasi *scroll-reveal* (fade + geser halus) yang sebelumnya dimatikan di halaman Sejarah, Visi & Misi, Sambutan, Struktur Organisasi, dan Fasilitas kini diaktifkan, dengan jeda bertahap (foto muncul dulu, lalu teks) supaya terasa lebih smooth.

**Kabar Sekolah (beranda)**: bagian baru di bawah Galeri Kegiatan, khusus halaman Beranda, berisi 1 video YouTube. Isi linknya di Admin > Profil & Sambutan > "Video Kabar Sekolah". Kosongkan untuk menyembunyikan bagian ini.

**Berita**: gambar sampul di kartu berita dan halaman detail dirapikan memakai rasio ukuran tetap (`aspect-ratio`) supaya proporsional, tidak lagi terlalu besar/gepeng, dan konsisten di semua ukuran gambar yang diunggah admin.

**Ekstrakurikuler**: halaman detail dan tombol "Detail" dihapus dari alur. Kartu ekstrakurikuler (di halaman Ekstrakurikuler maupun cuplikan di halaman Kesiswaan) kini langsung menampilkan Jadwal, Pembina, Tempat Kegiatan, dan Kategori tepat di bawah foto; teks deskripsi dihapus.

**Kurikulum & Kalender Pendidikan**:
- Ditemukan **bug**: form Admin > Akademik sebelumnya tidak punya pilihan "Jenis" (Kurikulum/Kalender), sehingga entri BARU yang ditambahkan admin tersimpan tanpa kategori dan **tidak pernah muncul** di halaman publik Akademik (hanya entri lama yang tampil). Ini sudah diperbaiki: form sekarang wajib memilih Kurikulum atau Kalender Pendidikan, dan tabel daftarnya menampilkan kolom "Jenis".
- Tampilan publik dipisah jadi dua kelompok yang jelas: **Kurikulum** dan **Kalender Pendidikan**.
- Kalender Pendidikan kini bisa ditulis sebagai tabel rapi: isi kotak "Isi/Penjelasan" satu baris per kegiatan dengan format `Tanggal | Kegiatan` (contoh: `14 Juli 2026 | Awal Tahun Ajaran Baru`), otomatis tampil sebagai tabel 2 kolom. Jika tidak memakai format ini, tetap tampil sebagai paragraf biasa (tidak error).

**Sidebar Admin**: dikelompokkan ulang supaya lebih logis: Profil Sekolah, Akademik, Kesiswaan, Informasi & Berita, BKK & Magang Jepang, PPDB, Lainnya. Label menu yang sebelumnya membingungkan ("Kurikulum, Kalender & PKL" padahal PKL punya menu sendiri) sudah diperbaiki.

**Audit CRUD Admin**: seluruh form admin (isi teks maupun unggah foto) diperiksa ulang terhadap struktur database terbaru — semua kolom yang dipakai kode untuk simpan (INSERT/UPDATE) sudah cocok dengan tabel di database Anda, tidak ditemukan bug simpan-data lain selain bug Kurikulum/Kalender di atas.

---

## Perubahan v5 (terbaru)

**Database** — `database/database.sql` kini adalah dump database Anda (`smk_infokom.sql`), ditambah header `CREATE DATABASE`/`USE` dan dua kolom baru (lihat bawah). Kode disesuaikan dengan struktur itu.
- **PKL error "kolom tidak ditemukan"**: tabel `pkl_items` di database Anda memakai kolom `kind`, sedangkan kode mencari `item_type`. Kode kini memakai `kind` (halaman PKL publik & Admin > Konten PKL). Bila ada database lama berkolom `item_type`, kolomnya diganti nama otomatis.
- Kolom baru dibuat **otomatis** bila belum ada, jadi database lama tidak perlu diimpor ulang: `achievements.source_url/source_name`, `jepang_profile.video_url`.

**Banner halaman (breadcrumb)**: kotak transparan "Beranda / ... / ..." kini selebar isinya (tidak memanjang penuh) di semua halaman (Kontak, PKL, Berita, dst).

**Magang ke Jepang**: di bagian Dokumentasi, di bawah foto ditambah **Video Dokumentasi YouTube** (1–6 video). Isi link di Admin > Profil Magang > "Video YouTube Dokumentasi" (satu link per baris; mendukung youtube.com/watch, youtu.be, shorts, embed).

**Prestasi Sekolah**: ditambah **Link Sumber** + **Nama Sumber** (Admin > Prestasi Sekolah). Tampil sebagai tautan "Sumber: ..." pada kartu prestasi.

**Galeri**: **kategori dihapus** — filter kategori di halaman Galeri dan menu/isian kategori di Admin > Galeri sudah tidak ada. (Kategori internal "Program Jepang" tetap ada di database hanya untuk memisahkan foto magang dari galeri umum.)

---

## Perubahan v4 (terbaru)

**Navbar**
- Penyebab navbar tidak mau hilang: jarak scroll dibandingkan per-frame dengan ambang 6px, sehingga scroll halus/trackpad tidak pernah memicu. Kini jarak scroll diakumulasi per arah (hilang saat scroll ke bawah, muncul lagi saat scroll ke atas, selalu tampil di puncak halaman, dan muncul jika kursor menyentuh tepi atas layar).
- Menu mobile diperbaiki: header memakai `backdrop-filter` sehingga menu `position:fixed` ikut mengacu ke header; kini memakai posisi absolut tepat di bawah header.

**Galeri vs Foto Siswa Magang Jepang**
- Foto yang diunggah di Admin > Foto Siswa Magang kini HANYA tampil di halaman Magang. Tidak lagi muncul di halaman Galeri, beranda, maupun Admin > Galeri (helper `galleryPublicSql()`).
- Admin > Galeri: bisa unggah banyak foto, **edit** (judul, kategori, ganti gambar), hapus, cari/filter, dan **kelola kategori** (tambah/ubah/hapus).

**Beranda**: ditambah bagian **Sambutan Kepala Sekolah** (foto, nama, cuplikan sambutan + tombol Baca Selengkapnya). Isi diubah di Admin > Profil Sekolah.

**Pencarian** (komponen baru `includes/filter-bar.php`, dipakai Berita, Galeri, Lowongan, Perusahaan Mitra, Ekstrakurikuler)
- Desain baru: kolom cari besar, filter berlabel, jumlah hasil, chip filter aktif yang bisa dihapus satu per satu, tombol reset.
- Bug: karakter `%` dan `_` dianggap wildcard (kini di-escape lewat `likeParam()`); Berita kini mencari juga di isi berita; nomor halaman di luar jangkauan dirapikan; kolom `title/status` di query berita diberi alias tabel; pencarian Lowongan/Perusahaan/Ekskul mencakup lokasi/bidang/kategori.

**Admin Informasi (CRUD lengkap)**
- **Konten PKL** (menu baru Admin > Konten PKL): Tentang, Tujuan, Kerja Sama Industri, dan Tahapan bisa ditambah/diubah/dihapus/diurutkan/disembunyikan. Tabel `pkl_items` dibuat otomatis dan terisi teks bawaan yang sama seperti sebelumnya.
- **Kategori Berita** bisa dikelola di Admin > Berita; pencarian admin berita ditambah filter kategori & status.

**Desain modern halaman Informasi**: kartu berita baru (berita terbaru tampil lebar di halaman 1), galeri grid rapi dengan ikon zoom saat hover, kartu PKL/BKK/Magang lebih lembut.

---

## Perubahan v3 (terbaru)

**PKL (`pkl.php`)**
- Ditambah bagian **Kerja Sama Industri** (bentuk kerja sama + daftar Mitra Industri otomatis dari Admin > Perusahaan Mitra).
- "Pelaksanaan" dilebur ke **Tahapan**, kini 6 tahap bernomor dengan penjelasan lengkap.
- Bagian **Syarat Peserta** dan **Manfaat** dihapus. Teks "Tentang PKL" diperpanjang dan tetap bisa diubah admin.

**Magang / Program Jepang**
- Bagian **Tahapan Program** dihapus dari halaman publik (Magang & Persyaratan) dan dari pilihan kategori admin.
- Ditambah **link sumber** (Admin > Profil Magang: Link & Nama Sumber) yang tampil sebagai tombol yang bisa diklik.
- Foto siswa magang: bisa unggah **banyak foto sekaligus**, otomatis masuk **Galeri** (kategori Program Jepang).

**Berita**
- Kartu berita bisa diklik penuh; URL di dalam isi berita otomatis menjadi link.
- Form berita: kolom **Link Sumber** + **Nama Sumber**, dan unggah **foto galeri berita** (sebelumnya fitur ini tampil di publik tetapi tidak ada cara mengisinya).
- Isi berita disanitasi (script/onclick/javascript: dibuang). Pencarian mencakup ringkasan. Pagination punya tombol sebelumnya/berikutnya.

**Navbar & menu**
- Navbar **hilang saat scroll ke bawah** dan muncul lagi saat scroll ke atas / di puncak halaman.
- **Galeri dipindahkan ke menu Informasi** (Berita, PKL, BKK, Magang, Galeri).

**Bug yang diperbaiki**
- Deskripsi banner (beranda & halaman dalam) meluber / tampil placeholder `[ISI ... ADMIN]` / kosong: kini dirapikan, dibatasi panjangnya, placeholder disembunyikan.
- Default `$heroImage` di `page-hero.php` ternyata ada di dalam komentar (tidak pernah berjalan).
- Upload foto: batas 2MB membuat foto HP ditolak. Kini maks 8MB per foto dan otomatis dikecilkan (GD); ekstensi disesuaikan isi file; `.htaccess` & `.user.ini` menaikkan batas PHP.
- Menu mobile tidak menutup setelah klik tautan anchor; scroll halaman terkunci saat menu terbuka.
- `mb_strimwidth` di beranda (error bila mbstring tidak aktif) diganti helper aman.
- Halaman admin: akses `$_POST[...]` tanpa pengecekan dirapikan; form berita tidak lagi kehilangan isian saat validasi gagal; slug berita dijamin unik.
- Kategori galeri "Program Jepang" dibuat lebih tahan (tidak error/duplikat).
- Lightbox foto kini juga berlaku untuk foto Jepang & galeri berita, ada tombol Esc.

**Desain**: navbar kaca buram bergaya pill, tombol & kartu lebih lembut, tab, tautan sumber, timeline PKL, lightbox baru.

**Database**: kolom `news.source_url`, `news.source_name`, `jepang_profile.source_url`, `jepang_profile.source_name` dibuat **otomatis** untuk instalasi lama (tidak perlu impor ulang).

---

## Perubahan final v2 (terbaru)

**Restrukturisasi navigasi (final, tidak berubah lagi):**
- Menu **Akademik** sekarang HANYA berisi 4 item: Program Keahlian, Kurikulum, Kalender Pendidikan,
  dan **Kesiswaan** (dipindahkan ke sini dari posisi menu sendiri sebelumnya).
- Menu **Kesiswaan** di navbar dihapus dan diganti menu baru **Informasi**, berisi HANYA 4 item:
  Berita, PKL, BKK, dan **Magang** (Program Kerja ke Jepang, sebelumnya berada di bawah Akademik).
- `akademik.php`: tab PKL/BKK/Program Luar Negeri dihapus dari halaman ini (karena sudah pindah ke
  Informasi), diganti tab Kesiswaan.
- Breadcrumb & label "Akademik" di halaman PKL, BKK (+Lowongan, +Perusahaan Mitra), Berita, dan
  Program Magang diganti menjadi "Informasi" agar konsisten dengan menu barunya.
- Kolom footer yang sebelumnya bernama "Informasi" (isinya Galeri/PPDB/Kontak) diganti nama menjadi
  **"Layanan"** supaya tidak bentrok/rancu dengan menu navbar baru "Informasi".

**Kesiswaan — Prestasi Siswa dihapus, desain baru:**
- Fitur Prestasi Siswa (bukan Prestasi Sekolah — dua hal berbeda) dihapus permanen: halaman publik
  `kesiswaan-prestasi.php` & `kesiswaan-prestasi-detail.php`, halaman admin `kesiswaan-prestasi.php` &
  `kesiswaan-prestasi-form.php`, tabel `student_achievements`, dan fungsi `handleCertificateUpload()`.
- Halaman `kesiswaan.php` ditulis ulang: kini hanya Ekstrakurikuler dan Tata Tertib, dengan tampilan
  baru yang mengikuti gaya galeri foto+teks besar seperti Program Keahlian, tetapi dengan sentuhan
  lebih modern (gradient, badge status, kartu ekstrakurikuler yang bisa diklik penuh).

**Struktur Organisasi — model Bidang, bukan lagi hierarki atasan/bawahan:**
- Kolom **Status** dan **Urutan** yang ditambahkan pada perubahan sebelumnya sudah **dihapus total**,
  sesuai permintaan.
- Model hierarki lama (Atasan Langsung / `parent_id`) diganti dengan pengelompokan per **Bidang**
  (mis. Pimpinan, Bidang Kurikulum, Bidang Kesiswaan, Staff Tata Usaha — bebas diisi admin, dengan
  saran otomatis). Bidang "Pimpinan" selalu tampil paling atas di halaman publik.
- Foto anggota struktur organisasi kini memakai kartu besar yang identik dengan halaman **Guru &
  Staff** (avatar bulat besar, kartu bergaya sama), bukan lagi foto kecil 64px seperti sebelumnya.
- Migrasi otomatis: instalasi lama yang masih memakai kolom `parent_id`/`status`/`sort_order` akan
  otomatis dipindahkan ke kolom `group_name` saat admin membuka halaman terkait — data tidak hilang,
  anggota level-puncak (`parent_id` kosong) masuk ke bidang "Pimpinan", sisanya masuk ke bidang
  sementara "Bidang Lainnya" (tinggal admin ganti namanya sesuai kebutuhan).

**Sosial Media — fitur baru sekaligus bug lama yang diperbaiki:**
- Ditemukan bahwa tabel `social_media` sudah ada di database sejak awal dan tampil di footer, TAPI
  tidak ada satupun halaman admin untuk mengelolanya — link sosial media selamanya statis/hardcode
  dari data seed. Ini sudah diperbaiki: sekarang ada CRUD lengkap (tambah/edit/hapus) di **Admin →
  Profil Sekolah**, bagian paling bawah setelah Statistik.
- Halaman **Program Magang** (`program-jepang.php`) kini menampilkan tombol ajakan "Ikuti Update
  Program Magang" yang otomatis memakai Instagram bila tersedia, atau sosial media lain sebagai
  cadangan.

**Admin — menyesuaikan struktur baru:**
- Sidebar admin (`admin/includes/sidebar.php`) ditulis ulang, dikelompokkan mengikuti menu publik:
  grup **Akademik** (Program Keahlian, Kurikulum & Kalender, Ekstrakurikuler, Tata Tertib) dan grup
  **Informasi** (Berita, Profil BKK, Lowongan Kerja, Perusahaan Mitra, Profil Magang, Persyaratan &
  Tahapan, Foto Siswa Magang).

**Database (`database/database.sql`):**
- Skema `organization_structure` diperbarui: kolom `parent_id`, `status`, `sort_order` dihapus,
  digantikan kolom `group_name`.

---

## Perubahan final (v1)

**Dihapus permanen:**
- Program Kerja Luar Negeri: sub-menu Program/Bidang, Pelatihan, Budaya & Etika, Mitra, Dokumen, FAQ,
  dan Pendaftar (halaman admin maupun publik, termasuk formulir pendaftaran dan halaman suksesnya).
  Tahapan Program tidak dihapus, tetapi digabung ke dalam menu Persyaratan (lihat di bawah).
- Kesiswaan: sub-menu Kegiatan Siswa (halaman admin, halaman publik, dan kartu ringkasannya di
  beranda Kesiswaan).
- Menu admin terpisah Banner/Slider dan Statistik (dipindahkan, lihat di bawah — bukan dihapus datanya).
- File gambar `about-placeholder.jpg` yang sudah tidak dipakai di mana pun.

**Dipindahkan:**
- Banner/Slider dan Statistik Sekolah sekarang dikelola dari **Admin → Profil Sekolah**, di bagian
  paling bawah setelah kolom Embed Google Maps. Data lama (tabel `banners` dan `school_statistics`)
  tidak berubah, hanya halaman pengelolaannya yang berpindah.
- Tahapan Program kini menjadi kategori khusus **"Tahapan Program"** di dalam menu Admin →
  Persyaratan & Tahapan (dulu `jepang-tahapan.php`, sekarang bagian dari `jepang-persyaratan.php`).
  Data tahapan yang sudah ada di instalasi lama dipindahkan otomatis oleh `ensureJepangTables()`,
  tidak hilang.

**Ditambahkan:**
- Struktur Organisasi kini punya kolom **Status** (mis. PNS, PPPK, GTY, GTT, Honorer), diisi bebas
  dengan saran datalist, tampil sebagai badge di admin dan sebagai label kecil di halaman publik
  `struktur.php`.
- Halaman login admin menampilkan logo sekolah asli (bukan lagi placeholder "IB"): memakai logo dari
  Profil Sekolah bila admin sudah mengunggahnya, atau `assets/images/logo-smk-infokom.png` sebagai
  bawaan.
- Posisi scroll sidebar admin kini dipertahankan antar-halaman (lihat perbaikan bug di bawah).

**Bug yang diperbaiki:**
- Halaman publik Program Kerja ke Jepang (`program-jepang.php`) tidak pernah menampilkan Tentang
  Program, Tujuan, Durasi, dan Status, karena variabel `$profile` yang dipakai untuk data program
  tertimpa oleh `$profile` milik profil sekolah dari `includes/header.php` (yang di-include setelahnya).
  Sekarang program Jepang memakai variabel `$jp` supaya tidak bentrok.
- Halaman Struktur Organisasi publik hanya menampilkan 2 tingkat (pimpinan + bawahan langsung); anggota
  di tingkat ke-3 dan seterusnya tidak pernah tampil. Sekarang seluruh tingkat ditampilkan.
- Form admin Struktur Organisasi mengizinkan seseorang dipilih sebagai atasan dirinya sendiri atau
  atasan dari bawahannya sendiri (membuat rantai melingkar). Sekarang kombinasi tersebut ditolak
  dengan pesan kesalahan.
- Klik menu di bagian bawah sidebar admin (mis. "Pengaturan Admin") membuat sidebar kembali ke posisi
  paling atas setelah halaman baru dimuat, sehingga menu yang baru diklik tidak terlihat aktif tanpa
  di-scroll manual. Sekarang posisi scroll sidebar disimpan dan menu aktif otomatis berada di area
  yang terlihat.
- Batas ukuran upload di kode (`UPLOAD_MAX_SIZE`) sebenarnya 10MB, padahal pesan error dan panduan
  instalasi menyebut 2MB. Disamakan menjadi 2MB.
- Urutan tampil Banner dan Statistik tidak konsisten saat beberapa data punya angka urutan yang sama
  (urutan bisa tertukar setiap refresh). Ditambahkan `id ASC` sebagai penentu urutan kedua.

**Pembersihan data lama (opsional, dijalankan manual):**
Karena beberapa data lama tidak lagi dipakai kode tetapi masih tersimpan di database (agar tidak ada
data yang hilang tanpa sepengetahuan admin), disediakan skrip `database/bersihkan-fitur-lama.sql`
untuk menghapusnya bila memang tidak diperlukan lagi. Jalankan lewat phpMyAdmin → tab SQL, atau
`mysql -u root -p smk_infokom < database/bersihkan-fitur-lama.sql`. Baca komentar di dalam file
tersebut sebelum menjalankan — proses ini permanen dan tidak bisa dibatalkan.

---

## Bug yang diperbaiki
1. **Konten Sejarah, Visi & Misi, Sambutan, Struktur, Fasilitas, dan Guru & Staff tidak tampil.**
   Penyebab: konten memakai `.reveal` (`opacity:0`) yang baru ditampilkan oleh `assets/js/script.js`,
   tetapi halaman-halaman itu tidak memuat `footer.php` (tempat `script.js` dimuat). Sekarang footer dipasang di
   semua halaman, dan `.reveal` dibuat aman: konten tetap terlihat bila JavaScript gagal, serta elemen yang
   sangat tinggi tidak lagi terjebak tersembunyi.
2. **Admin "tidak bisa CRUD".** CRUD sendiri berfungsi, tetapi ada tiga kegagalan yang tidak diberi tahu ke admin:
   - Halaman putih (HTTP 500) saat data melanggar batas database (nama jurusan kembar, judul/alamat terlalu panjang).
   - Klik Simpan "diam saja" saat token CSRF gagal atau data melebihi `post_max_size`.
   - Pesan upload hanya berupa kode angka.
   Sekarang semua menampilkan pesan yang jelas (`admin/includes/auth.php`, `includes/functions.php`).
3. Formulir kontak publik menghasilkan halaman putih bila subjek/nama terlalu panjang.
4. Sidebar admin merujuk `fasilitas-form.php` yang tidak ada; tautan "Tambah Berita" di dashboard salah tujuan.
5. Layout kolom "Aksi" tabel admin rusak (`<td style="display:flex">`).
6. Dashboard error JS bila Chart.js tidak bisa dimuat.
7. Upload gagal bila ekstensi PHP `fileinfo` tidak aktif (kini ada cadangan deteksi).

## Penyeragaman desain
- Hero seragam (`includes/page-hero.php`) di seluruh halaman dalam.
- Halaman **Akademik** ditulis ulang dengan gaya Profil Sekolah.
- Footer kini tampil di semua halaman.

## Tambahan
- Menu admin **Akademik** (CRUD kurikulum, kalender, PKL, ekskul, dst.). Tabel `academic_info` dibuat otomatis
  bila belum ada, jadi database lama tidak perlu diimpor ulang.
- `BASE_URL` dideteksi otomatis.
- Batas panjang input (`maxlength`) disesuaikan dengan kolom database.

## Update desain & fitur (terbaru)
1. **Palet warna baru** — biru tua diperbarui (`--navy-900/800/700/600`, `--blue-500`) di `assets/css/style.css`
   agar tampilan lebih segar dan konsisten di seluruh situs (navbar, tombol, hero, dsb).
2. **Navbar** — ditambahkan ikon FontAwesome modern di setiap menu (termasuk submenu Profil), efek hover/aktif
   dengan gradient navy, dan garis aksen tipis di bawah header. Lihat `includes/navbar.php`.
3. **Dropdown menu Profil** dipastikan selalu terbuka ke bawah (bukan ke samping) — `display:flex;flex-direction:column`
   ditambahkan secara eksplisit pada `.dropdown-nav`.
4. **Hero halaman dalam** (Sejarah, Akademik, Visi & Misi, Struktur, dll. — via `includes/page-hero.php`):
   overlay gelap yang sebelumnya nyaris menutupi foto gedung sekolah kini dibuat jauh lebih transparan sehingga
   foto benar-benar terlihat, ditambah animasi *pan* halus pada foto latar dan lingkaran dekoratif yang
   berlebihan disederhanakan. CSS lama `.page-hero` yang sudah tidak dipakai dihapus.
5. **Animasi halus** — kurva easing baru `--ease-smooth` diterapkan pada transisi *reveal-on-scroll*, tombol,
   tautan, dan dropdown agar terasa lebih modern & profesional.
6. **Guru & Staff** — field **NIK/NIP** dan **Urutan Tampil** dihapus dari form tambah/edit di admin
   (`admin/guru-staff.php`) agar lebih ringkas. Data lama tetap tersimpan di database (tidak dihapus), hanya
   tidak ditampilkan/diminta lagi di form; urutan tampil baru otomatis mengikuti data terakhir. Tampilan
   NIP di kartu publik Guru & Staff juga dihapus (`guru-staff.php`).
7. **Informasi PPDB berbentuk gambar** — di **Admin > Pengaturan PPDB** kini ada field unggah **Gambar Informasi
   PPDB** (poster persyaratan/alur). Jika diisi, halaman publik PPDB akan menampilkan gambar tersebut
   menggantikan teks persyaratan. Kolom `info_image` pada tabel `ppdb_settings` dibuat otomatis saat halaman
   diakses (tidak perlu impor ulang database lama).

## Modul baru: Kesiswaan
Menu utama **Kesiswaan** ditambahkan (dropdown: Beranda Kesiswaan, Ekstrakurikuler, Prestasi Siswa,
Kegiatan Siswa, Tata Tertib) tanpa mengubah fitur, data, atau halaman yang sudah ada.

- **Database**: 4 tabel baru dibuat otomatis saat halaman pertama kali diakses (pola yang sama dengan
  `academic_info`), jadi `database/database.sql` **tidak perlu diimpor ulang**:
  `extracurriculars`, `student_achievements` (relasi ke `programs` untuk jurusan), `student_activities`,
  `student_rules`. Lihat `ensureKesiswaanTables()` di `includes/functions.php`.
- **Frontend**: `kesiswaan.php`, `kesiswaan-ekstrakurikuler.php` (+ `-detail.php`),
  `kesiswaan-prestasi.php` (+ `-detail.php`), `kesiswaan-kegiatan.php` (+ `-detail.php`),
  `kesiswaan-tata-tertib.php`. Mengikuti gaya hero/kartu/grid halaman Profil & Akademik yang sudah ada,
  tanpa data dummy — semua tampil dari database dengan empty state bila kosong.
- **Admin**: submenu **Kesiswaan** di sidebar dengan CRUD lengkap untuk Ekstrakurikuler, Prestasi Siswa
  (termasuk upload foto & sertifikat, status publikasi), Kegiatan Siswa (kategori, status, publikasi),
  dan Tata Tertib (kategori tetap, urutan, aktif/nonaktif).
- **Upload**: folder baru `assets/uploads/kesiswaan/{ekstrakurikuler,prestasi-siswa,kegiatan,sertifikat}`,
  memakai helper upload yang sudah ada (`handleImageUpload`) plus helper baru `handleCertificateUpload()`
  untuk sertifikat (gambar atau PDF, maks. 2MB).
- **Hero khusus**: memakai `assets/images/kesiswaan-hero.jpg` bila tersedia; jika belum ada file tersebut,
  otomatis memakai `assets/images/image.png` (placeholder yang sudah dipakai halaman lain) sebagai fallback
  — tidak ada gambar palsu yang dibuat.

## Modul baru: BKK (Bursa Kerja Khusus)
Menu utama **BKK** ditambahkan (dropdown: Profil BKK, Lowongan Kerja, Perusahaan Mitra) tanpa mengubah
fitur, data, atau modul Kesiswaan yang sudah ada.

- **Database**: 4 tabel baru dibuat otomatis saat halaman pertama kali diakses (pola yang sama dengan
  `academic_info` / modul Kesiswaan), jadi `database/database.sql` **tidak perlu diimpor ulang**:
  `bkk_settings` (pengaturan umum: deskripsi, kontak, koordinator — satu baris, seperti `school_profile`),
  `bkk_sections` (blok Tentang/Tujuan/Fungsi/Layanan BKK — bisa tambah/edit/hapus, seperti `academic_info`),
  `partner_companies` (perusahaan mitra), `job_vacancies` (lowongan kerja, relasi ke `partner_companies`
  dan ke `programs` untuk jurusan — logo lowongan mengikuti logo perusahaan, tidak upload ganda).
  Lihat `ensureBkkTables()` di `includes/functions.php`.
- **Frontend**: `bkk.php` (Profil BKK), `bkk-lowongan.php` + `-detail.php` (search, filter jurusan/lokasi/
  perusahaan/status, tombol Daftar hanya muncul jika lowongan aktif & link pendaftaran tersedia),
  `bkk-perusahaan.php` + `-detail.php` (menampilkan lowongan aktif dari perusahaan tsb).
- **Admin**: submenu **BKK** di sidebar — `admin/bkk.php` (pengaturan umum + CRUD bagian profil),
  `admin/bkk-perusahaan.php` + `-form.php`, `admin/bkk-lowongan.php` + `-form.php` (dengan proteksi:
  tidak bisa membuat lowongan sebelum ada data Perusahaan Mitra).
- **Upload**: folder baru `assets/uploads/bkk/{perusahaan,koordinator}`, memakai `handleImageUpload()`
  yang sudah ada.
- **Hero khusus**: memakai `assets/images/bkk-hero.jpg` bila tersedia; jika belum ada, otomatis memakai
  `assets/images/image.png` sebagai fallback — tidak ada gambar/data palsu yang dibuat.

## Modul baru: Program Kerja Luar Negeri (fokus Program Kerja ke Jepang)
Menu utama **Program Kerja Luar Negeri** ditambahkan, terpisah sepenuhnya dari BKK (BKK tetap menu
tersendiri: Profil BKK, Lowongan Kerja, Perusahaan Mitra — tidak diubah). Dropdown baru: Program Kerja ke
Jepang, Persyaratan, Tahapan Program, Pelatihan, Mitra, Dokumen, Pendaftaran.

- **Database**: 7 tabel baru dibuat otomatis saat halaman pertama diakses (pola yang sama dengan modul
  sebelumnya), jadi `database/database.sql` **tidak perlu diimpor ulang**:
  `jepang_profile` (profil program, 1 baris), `jepang_sections` (tabel gabungan untuk Persyaratan,
  Pelatihan Bahasa, Pelatihan Kompetensi, Budaya & Etika, dan Tahapan Program — dibedakan kolom `module`,
  supaya tidak membuat 5 tabel duplikat berstruktur sama), `jepang_programs` (Program/Bidang),
  `jepang_partners` (Mitra — tabel terpisah dari `partner_companies` milik BKK agar fitur ini berdiri
  sendiri sesuai instruksi), `jepang_documents`, `jepang_faqs`, `jepang_registrations` (Pendaftaran, status:
  Menunggu/Seleksi/Diproses/Lulus/Tidak Lulus). Galeri **tidak** membuat tabel baru — memakai tabel
  `gallery`/`gallery_categories` yang sudah ada, difilter kategori "Program Jepang" (auto-dibuat), supaya
  tidak duplikat sistem galeri dan tidak memengaruhi galeri umum di menu Galeri. Relasi jurusan memakai
  ulang tabel `programs` yang sudah ada.
- **Frontend**: `program-jepang.php` (halaman utama — hero, Profil Program, Program/Bidang, Budaya & Etika,
  FAQ, Galeri, CTA), `jepang-program-detail.php`, `jepang-persyaratan.php` (accordion per kategori),
  `jepang-tahapan.php` (timeline), `jepang-pelatihan.php` (Bahasa Jepang + Kompetensi), `jepang-mitra.php`,
  `jepang-dokumen.php` (unduhan), `jepang-pendaftaran.php` + `jepang-pendaftaran-sukses.php` (nomor
  pendaftaran otomatis format JPG-YYYY-XXXXX).
- **Admin**: modul **Program Kerja Luar Negeri** di sidebar dengan 11 submenu — Profil Program,
  Program/Bidang, Persyaratan, Pelatihan, Budaya & Etika, Tahapan Program, Mitra, Dokumen, FAQ, Galeri,
  Pendaftar (lengkap dengan ubah status & catatan admin).
- **Upload**: folder baru `assets/uploads/jepang/{program,mitra,dokumen,pendaftaran}`, memakai
  `handleImageUpload()` yang sudah ada plus helper baru `handleJepangDocumentUpload()` (PDF/DOC/DOCX/gambar,
  untuk menu Dokumen) dan `handleCertificateUpload()` yang sudah ada (untuk dokumen pendukung pendaftar).
- **Hero khusus**: memakai `assets/images/program-jepang-hero.jpg` bila tersedia; jika belum ada, otomatis
  memakai `assets/images/image.png` sebagai fallback — tidak ada gambar/data/klaim palsu yang dibuat.
- **Tidak ada klaim tanpa data**: seluruh bagian (profil, budaya & etika, mitra, tahapan, dsb.) menampilkan
  empty state yang jelas bila admin belum mengisi data, bukan konten bawaan/asumsi.

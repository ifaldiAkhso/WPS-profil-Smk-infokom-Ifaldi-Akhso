<?php
// tests/unit-test.php — jalankan dari akar proyek: php tests/unit-test.php
require_once __DIR__ . '/../includes/functions.php';

$total = 0;
$gagal = 0;

function uji(string $nama, $diharapkan, $hasil): void
{
    global $total, $gagal;
    $total++;
    $lulus = ($diharapkan === $hasil);
    if (!$lulus) $gagal++;
    echo ($lulus ? '[LULUS] ' : '[GAGAL] ') . $nama . "\n";
    if (!$lulus) {
        echo '   diharapkan: ' . var_export($diharapkan, true) . "\n";
        echo '   hasil     : ' . var_export($hasil, true) . "\n";
    }
}

uji('e() escape tag dan kutip', '&lt;b&gt;&quot;a&quot;&lt;/b&gt;', e('<b>"a"</b>'));
uji('e() null jadi kosong', '', e(null));
uji('likeParam() escape % dan _', '%50\%\_a%', likeParam('50%_a'));
uji('visitTitle() pakai judul', 'Studi Lapangan', visitTitle(['title' => 'Studi Lapangan', 'company' => 'PT A']));
uji('visitTitle() judul spasi pakai perusahaan', 'PT A', visitTitle(['title' => '  ', 'company' => 'PT A']));
uji('visitTitle() kosong semua', '', visitTitle(['title' => '', 'company' => '']));
uji('tanggalIndo() normal', '21 Februari 2025', tanggalIndo('2025-02-21'));
uji('tanggalIndo() null', '-', tanggalIndo(null));
uji('youtubeId() youtu.be', 'dQw4w9WgXcQ', youtubeId('https://youtu.be/dQw4w9WgXcQ'));
uji('youtubeId() watch?v=', 'dQw4w9WgXcQ', youtubeId('https://www.youtube.com/watch?v=dQw4w9WgXcQ'));
uji('youtubeId() bukan link', '', youtubeId('bukan-link'));
uji('safeUrl() tambah https', 'https://detik.com/x', safeUrl('detik.com/x'));
uji('safeUrl() tolak ftp', '', safeUrl('ftp://situs.com'));
uji('slugify() judul', 'gelar-karya-budaya', slugify('Gelar Karya & Budaya'));
uji('safeCut() potong 3', 'SMK', safeCut('SMK Infokom', 3));
uji('mb_or_cut() terpotong', 'Halo…', mb_or_cut('Halo dunia', 4));
uji('mb_or_cut() tidak terpotong', 'Halo', mb_or_cut('Halo', 10));
uji('imageRatio() berkas tidak ada', 0.75, imageRatio('tidak/ada.jpg', 'tidak/ada-juga.png'));

echo "\nTotal: $total uji, gagal: $gagal\n";
exit($gagal > 0 ? 1 : 0);

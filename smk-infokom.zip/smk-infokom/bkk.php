<?php
require_once __DIR__ . '/includes/functions.php';
$pdo = getDB();
$pageTitle = 'Profil BKK';
ensureBkkTables($pdo);

$settings = bkkSettings($pdo);
$sections = bkkSections($pdo, true);
$totalLowongan = (int)$pdo->query("SELECT COUNT(*) FROM job_vacancies WHERE status = 'aktif' AND (deadline IS NULL OR deadline >= CURDATE())")->fetchColumn();
$totalMitra    = (int)$pdo->query("SELECT COUNT(*) FROM partner_companies WHERE is_partner = 1")->fetchColumn();

$bodyClass = 'page-profil pf-info';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$heroEyebrow = 'BKK';
$heroTitle   = 'Bursa Kerja Khusus (BKK)';
$heroText    = !empty(trim((string)($settings['description'] ?? ''))) ? $settings['description'] : 'Unit layanan sekolah yang menjembatani lulusan SMK INFOKOM BOGOR dengan dunia kerja.';
$heroCrumbs  = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['BKK', null]];
$heroImage = null;
include __DIR__ . '/includes/page-hero.php';
?>
<section class="profile-section">
  <div class="container">

    <div class="profile-tabs-wrap">
      <nav class="profile-tabs profile-tabs-auto" aria-label="Navigasi BKK">
        <a href="<?= BASE_URL ?>bkk-lowongan.php"><i class="fa-solid fa-briefcase"></i><span>Lowongan Kerja</span></a>
        <a href="<?= BASE_URL ?>bkk-perusahaan.php"><i class="fa-solid fa-handshake"></i><span>Perusahaan Mitra</span></a>
        <?php /* Tombol Tujuan / Fungsi / Layanan dihapus dari menu; kartu isinya tetap tampil di halaman. */
        foreach ($sections as $sec):
          if (in_array((string)($sec['section_key'] ?? ''), ['tujuan', 'fungsi', 'layanan'], true)) continue; ?>
          <a href="#info-<?= (int)$sec['id'] ?>"><i class="<?= e($sec['icon'] ?: 'fa-solid fa-briefcase') ?>"></i><span><?= e($sec['title']) ?></span></a>
        <?php endforeach; ?>
      </nav>
    </div>

    <div class="profile-heading reveal">
      <div class="article-kicker"><span></span> BKK <span></span></div>
      <h2>Bursa Kerja Khusus SMK INFOKOM BOGOR</h2>
      <p><?= nl2br(e($heroText)) ?></p>
    </div>

    <div class="ks-info-grid" style="grid-template-columns:repeat(2,minmax(0,1fr));max-width:560px;">
      <a href="<?= BASE_URL ?>bkk-lowongan.php" class="ks-info-card reveal">
        <div class="ks-info-icon"><i class="fa-solid fa-briefcase"></i></div>
        <strong><?= $totalLowongan ?></strong>
        <span>Lowongan Aktif</span>
      </a>
      <a href="<?= BASE_URL ?>bkk-perusahaan.php" class="ks-info-card reveal">
        <div class="ks-info-icon"><i class="fa-solid fa-handshake"></i></div>
        <strong><?= $totalMitra ?></strong>
        <span>Perusahaan Mitra</span>
      </a>
    </div>

    <?php if (count($sections) === 0): ?>
      <div class="empty-state modern-empty" style="margin-top:26px;"><i class="fa-solid fa-building-user"></i><p>Informasi Profil BKK belum tersedia.</p></div>
    <?php else: ?>
      <div class="academic-info-grid">
        <?php foreach ($sections as $sec): ?>
          <article class="vm-modern-card academic-info-card reveal" id="info-<?= (int)$sec['id'] ?>">
            <div class="vm-card-mark"><i class="<?= e($sec['icon'] ?: 'fa-solid fa-briefcase') ?>"></i></div>
            <h2><?= e($sec['title']) ?></h2>
            <p class="vm-lead"><?= nl2br(e(trim((string)($sec['content'] ?? '')) !== '' ? $sec['content'] : 'Informasi belum diisi.')) ?></p>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if (!empty($settings['coordinator_name'])): ?>
      <div class="profile-heading reveal">
        <div class="article-kicker"><span></span> Pengelola <span></span></div>
        <h2>Koordinator BKK</h2>
      </div>
      <div class="bkk-coordinator reveal">
        <img src="<?= uploadUrl($settings['coordinator_photo'] ?? null, 'assets/images/avatar-placeholder.jpg') ?>" alt="<?= e($settings['coordinator_name']) ?>">
        <div>
          <h4><?= e($settings['coordinator_name']) ?></h4>
          <span><?= e($settings['coordinator_position'] ?: 'Koordinator BKK') ?></span>
        </div>
      </div>
    <?php endif; ?>

    <?php if (!empty($settings['contact_phone']) || !empty($settings['contact_email']) || !empty($settings['contact_address'])): ?>
      <div class="profile-heading reveal">
        <div class="article-kicker"><span></span> Kontak <span></span></div>
        <h2>Informasi Kontak BKK</h2>
      </div>
      <div class="bkk-contact-grid">
        <?php if (!empty($settings['contact_phone'])): ?>
        <div class="contact-info-item reveal" style="background:#fff;border:1px solid var(--modern-line);border-radius:14px;padding:18px;">
          <i class="fa-solid fa-phone"></i>
          <div><strong style="display:block;color:var(--modern-navy);">Telepon</strong><span><?= e($settings['contact_phone']) ?></span></div>
        </div>
        <?php endif; ?>
        <?php if (!empty($settings['contact_email'])): ?>
        <div class="contact-info-item reveal" style="background:#fff;border:1px solid var(--modern-line);border-radius:14px;padding:18px;">
          <i class="fa-solid fa-envelope"></i>
          <div><strong style="display:block;color:var(--modern-navy);">Email</strong><span><?= e($settings['contact_email']) ?></span></div>
        </div>
        <?php endif; ?>
        <?php if (!empty($settings['contact_address'])): ?>
        <div class="contact-info-item reveal" style="background:#fff;border:1px solid var(--modern-line);border-radius:14px;padding:18px;">
          <i class="fa-solid fa-location-dot"></i>
          <div><strong style="display:block;color:var(--modern-navy);">Alamat</strong><span><?= e($settings['contact_address']) ?></span></div>
        </div>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <div class="cta-banner reveal" style="margin-top:50px;display:flex;align-items:center;justify-content:space-between;gap:20px;flex-wrap:wrap;">
      <div>
        <h3>Siap memulai karier setelah lulus?</h3>
        <p>Lihat lowongan kerja terbaru dari perusahaan mitra SMK INFOKOM BOGOR.</p>
      </div>
      <a href="<?= BASE_URL ?>bkk-lowongan.php" class="btn btn-gold">Lihat Lowongan Kerja</a>
    </div>

  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

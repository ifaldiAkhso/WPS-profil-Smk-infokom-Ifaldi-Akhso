<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'pf-staff page-profil no-footer';
$pdo = getDB();
$pageTitle = 'Guru & Staff';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$filter = $_GET['filter'] ?? 'all';
$filter = in_array($filter, ['guru', 'staff'], true) ? $filter : 'all';
$staffList = $pdo->query("SELECT * FROM staff WHERE is_active = 1 ORDER BY CASE WHEN category='guru' THEN 0 ELSE 1 END, sort_order ASC, name ASC")->fetchAll();
$totalGuru = count(array_filter($staffList, fn($s) => $s['category'] === 'guru'));
$totalStaff = count(array_filter($staffList, fn($s) => $s['category'] === 'staff'));
?>
<?php
$heroEyebrow = 'Guru & Staff';
$heroTitle = 'Guru & Staff';
$heroText = 'Tenaga pendidik dan staff profesional yang siap mendukung proses belajar mengajar di SMK INFOKOM BOGOR.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Guru & Staff', null]];
$heroImage = 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';
?>

<section class="staff-section">
  <div class="container">
    <div class="staff-filter-wrap reveal">
      <div class="staff-tabs staff-tabs-modern" id="staffTabs">
        <button type="button" class="<?= $filter === 'all' ? 'active' : '' ?>" data-filter="all"><i class="fa-solid fa-users"></i> Semua <span><?= count($staffList) ?></span></button>
        <button type="button" class="<?= $filter === 'guru' ? 'active' : '' ?>" data-filter="guru"><i class="fa-solid fa-chalkboard-user"></i> Guru <span><?= $totalGuru ?></span></button>
        <button type="button" class="<?= $filter === 'staff' ? 'active' : '' ?>" data-filter="staff"><i class="fa-solid fa-user-gear"></i> Staff <span><?= $totalStaff ?></span></button>
      </div>
    </div>

    <?php if (!$staffList): ?>
      <div class="staff-empty reveal"><div class="staff-empty-icon"><i class="fa-solid fa-users"></i></div><h2>Data Guru & Staff Belum Tersedia</h2><p>Tambahkan data melalui Dashboard Admin > Guru & Staff.</p></div>
    <?php else: ?>
      <div class="staff-grid staff-grid-modern" id="staffGrid">
        <?php foreach ($staffList as $staff): ?>
          <?php $isGuru = $staff['category'] === 'guru'; ?>
          <article class="staff-card-modern reveal" data-category="<?= e($staff['category']) ?>" style="<?= ($filter !== 'all' && $staff['category'] !== $filter) ? 'display:none;' : '' ?>">
            <div class="staff-card-top">
              <span class="staff-role-badge <?= $isGuru ? 'guru' : 'staff' ?>"><i class="fa-solid <?= $isGuru ? 'fa-graduation-cap' : 'fa-user-tie' ?>"></i> <?= $isGuru ? 'Guru' : 'Staff' ?></span>
              <div class="staff-avatar-modern">
                <img src="<?= uploadUrl($staff['photo'] ?? null, 'assets/images/avatar-placeholder.jpg') ?>" alt="<?= e($staff['name']) ?>">
              </div>
            </div>
            <div class="staff-card-body-modern">
              <h2><?= e($staff['name']) ?></h2>
              <p class="staff-position"><?= e($staff['position'] ?: ($isGuru ? 'Guru' : 'Staff')) ?></p>
              <?php if (!empty($staff['subject'])): ?><p class="staff-subject"><i class="fa-solid fa-book-open"></i><?= e($staff['subject']) ?></p><?php endif; ?>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <a href="<?= BASE_URL ?>index.php" class="btn btn-outline-navy profile-back"><i class="fa-solid fa-arrow-left"></i> Kembali ke Beranda</a>
  </div>
</section>
<script>
(function(){
  var tabs = document.querySelectorAll('#staffTabs button');
  var cards = document.querySelectorAll('#staffGrid .staff-card-modern');
  tabs.forEach(function(btn){
    btn.addEventListener('click', function(){
      var filter = btn.getAttribute('data-filter');
      tabs.forEach(function(b){ b.classList.remove('active'); });
      btn.classList.add('active');
      cards.forEach(function(card){
        var show = filter === 'all' || card.getAttribute('data-category') === filter;
        card.style.display = show ? '' : 'none';
        if (show) card.classList.add('show'); // kartu yang tadinya tersembunyi tidak pernah terpantau observer -> paksa tampil
      });
    });
  });
})();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>

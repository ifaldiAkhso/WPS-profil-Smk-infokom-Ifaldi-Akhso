<?php
/**
 * Konfigurasi Koneksi Database - SMK INFOKOM BOGOR
 * Menggunakan PDO + MySQL
 */

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'smk_infokom');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('BASE_PATH', dirname(__DIR__));

/**
 * Deteksi BASE_URL otomatis dari lokasi skrip yang sedang berjalan, sehingga folder
 * proyek boleh diberi nama apa saja (mis. "smk-infokom-modern") atau diletakkan di root.
 * Jika ingin manual, ganti pemanggilan di bawah dengan string tetap, mis. '/sekolah/'.
 */
function detectBaseUrl(): string
{
    $fallback   = '/smk-infokom/';
    $scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $scriptFile = $_SERVER['SCRIPT_FILENAME'] ?? '';
    if ($scriptName === '' || $scriptFile === '') return $fallback;

    $real = realpath($scriptFile);
    $root = realpath(BASE_PATH);
    if (!$real || !$root) return $fallback;

    $real = str_replace('\\', '/', $real);
    $root = str_replace('\\', '/', $root);
    if (strpos($real, $root) !== 0) return $fallback;

    $relative = substr($real, strlen($root));                 // mis. "/admin/dashboard.php"
    if ($relative === '' || substr($scriptName, -strlen($relative)) !== $relative) return $fallback;

    $base = substr($scriptName, 0, strlen($scriptName) - strlen($relative));
    return rtrim($base, '/') . '/';
}

// Base URL (otomatis). Lihat detectBaseUrl() di atas.
define('BASE_URL', detectBaseUrl());

// Upload constraints
define('UPLOAD_TARGET_SIZE', 400 * 1024); // hasil simpan gambar dikompres sampai <= 400KB
define('UPLOAD_MAX_SIZE', 10 * 1024 * 1024); // 10MB per file (foto 9MB tetap diterima); foto besar otomatis dikecilkan (lihat optimizeUploadedImage)
define('UPLOAD_ALLOWED_EXT', ['jpg', 'jpeg', 'png', 'webp']);

function getDB(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            http_response_code(500);
            die('Koneksi database gagal. Periksa konfigurasi di config/database.php. (' . htmlspecialchars($e->getMessage()) . ')');
        }
    }
    return $pdo;
}

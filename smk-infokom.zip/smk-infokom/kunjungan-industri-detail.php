<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-info no-footer';
$pdo = getDB();
$pageTitle = 'Detail Kegiatan';
$ready = ensureIndustryVisits($pdo);
$id = (int)($_GET['id'] ?? 0);
$v = null;
if ($ready && $id > 0) { $st = $pdo->prepare("SELECT * FROM industry_visits WHERE id = ? AND is_active = 1"); $st->execute([$id]); $v = $st->fetch(); }
if (!$v) { http_response_code(404); redirect('kunjungan-industri.php'); }
$vTitle = visitTitle($v);
$pageTitle = $vTitle !== '' ? $vTitle : 'Detail Kegiatan';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
$heroEyebrow = 'Informasi';
$heroTitle = $vTitle !== '' ? $vTitle : 'Detail Kegiatan';
$heroText = $vTitle !== '' ? (string)($v['company'] ?? '') : '';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Informasi', BASE_URL . 'berita.php'], ['Kunjungan Industri', BASE_URL . 'kunjungan-industri.php'], ['Detail', null]];
include __DIR__ . '/includes/page-hero.php';
?>
<section>
  <div class="container">
    <div class="visit-detail">
      <figure class="visit-detail-photo" style="--ar:<?= round(imageRatio($v['image'], 'assets/images/news-placeholder.jpg'), 4) ?>"><img src="<?= uploadUrl($v['image'], 'assets/images/news-placeholder.jpg') ?>" alt="<?= e($vTitle) ?>"></figure>
      <article class="visit-detail-card">
        <?php if ($vTitle !== ''): ?><h2><?= e($vTitle) ?></h2><?php endif; ?>
        <div class="visit-facts">
          <?php if (!empty($v['company'])): ?><div><i class="fa-solid fa-building"></i><small>Perusahaan</small><strong><?= e($v['company']) ?></strong></div><?php endif; ?>
          <?php if (!empty($v['visit_date'])): ?><div><i class="fa-regular fa-calendar"></i><small>Tanggal</small><strong><?= e(tanggalIndo($v['visit_date'])) ?></strong></div><?php endif; ?>
          <?php if (!empty($v['location'])): ?><div><i class="fa-solid fa-location-dot"></i><small>Lokasi</small><strong><?= e($v['location']) ?></strong></div><?php endif; ?>
          <?php if (!empty($v['participants'])): ?><div><i class="fa-solid fa-users"></i><small>Peserta</small><strong><?= e($v['participants']) ?></strong></div><?php endif; ?>
        </div>
        <?php if (trim((string)$v['description']) !== ''): ?><div class="visit-text"><?= nl2br(e(trim($v['description']))) ?></div><?php endif; ?>
      </article>
    </div>
  </div>
</section>
<?php $backHref = BASE_URL . 'kunjungan-industri.php'; $backLabel = 'Kembali ke Kunjungan Industri'; include __DIR__ . '/includes/back-button.php'; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>

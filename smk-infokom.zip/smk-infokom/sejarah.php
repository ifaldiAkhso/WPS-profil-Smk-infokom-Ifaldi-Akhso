<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'page-profil pf-school no-tabs';
$profile = schoolProfile();
$pageTitle = 'Sejarah Sekolah';
$activeProfile = 'sejarah.php';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$historyText = trim((string)($profile['history'] ?? ''));
if ($historyText === '') {
    $historyText = 'Informasi sejarah sekolah belum diisi. Admin dapat memperbaruinya melalui Dashboard Admin > Profil Sekolah.';
}
$historyParagraphs = preg_split('/\R{2,}/', $historyText);
$address = trim((string)($profile['address'] ?? ''));
?>
<?php
$heroEyebrow = 'Profil Sekolah';
$heroTitle = 'Sejarah Sekolah';
$heroText = 'Mengenal perjalanan dan perkembangan SMK INFOKOM BOGOR sejak berdiri hingga saat ini.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Sejarah Sekolah', null]];
include __DIR__ . '/includes/page-hero.php';
?>

<section class="profile-section">
  <div class="container">
    <?php include __DIR__ . '/includes/profile-nav.php'; ?>

    <div class="profile-story-grid reveal">
      <div class="profile-photo-card">
        <img src="<?= uploadUrl($profile['history_image'] ?? null, 'assets/images/profile-school-building.jpg') ?>" alt="Gedung SMK INFOKOM BOGOR">
        <div class="photo-caption"><i class="fa-solid fa-school"></i><span>SMK INFOKOM BOGOR</span></div>
      </div>

      <article class="profile-article-card">
        <div class="article-kicker"><span></span> Sejarah Sekolah <span></span></div>
        <h2>Sejarah Berdirinya<br>SMK INFOKOM BOGOR</h2>
        <div class="article-copy">
          <?php foreach ($historyParagraphs as $paragraph): ?>
            <?php if (trim($paragraph) !== ''): ?><p><?= nl2br(e(trim($paragraph))) ?></p><?php endif; ?>
          <?php endforeach; ?>
        </div>

        
      </article>
    </div>

    <div class="school-facts">
          <div class="school-fact">
            <span class="school-fact-icon"><i class="fa-regular fa-calendar-check"></i></span>
            <div><small>Berdiri Sejak</small><strong>18 Juli 2005</strong></div>
          </div>
          <div class="school-fact">
            <span class="school-fact-icon"><i class="fa-solid fa-location-dot"></i></span>
            <div><small>Lokasi</small><strong><?= e($address !== '' ? (preg_match('/Kota Bogor/i', $address) ? 'Kota Bogor' : $address) : 'Kota Bogor') ?></strong></div>
          </div>
          <div class="school-fact">
            <span class="school-fact-icon"><i class="fa-solid fa-building-columns"></i></span>
            <div><small>NPSN</small><strong><?= e($profile['npsn'] ?? '20238531') ?></strong></div>
          </div>
          <div class="school-fact">
            <span class="school-fact-icon"><i class="fa-solid fa-award"></i></span>
            <div><small>Status</small><strong>Sekolah Swasta</strong></div>
          </div>
        </div>

    <a href="<?= BASE_URL ?>index.php" class="btn btn-outline-navy profile-back"><i class="fa-solid fa-arrow-left"></i> Kembali ke Beranda</a>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'pf-form page-profil';
$pdo = getDB();
$profile = schoolProfile();
$pageTitle = 'Kontak';

$errors = [];
$success = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        $errors[] = 'Sesi form telah kedaluwarsa, silakan coba lagi.';
    } else {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $message = trim($_POST['message'] ?? '');
        if ($name === '' || $email === '' || $message === '') $errors[] = 'Nama, email, dan pesan wajib diisi.';
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Format email tidak valid.';
        if (safeCut($name, 150) !== $name || safeCut($email, 100) !== $email) $errors[] = 'Nama (maks. 150 karakter) atau email (maks. 100 karakter) terlalu panjang.';

        if (empty($errors)) {
            $stmt = $pdo->prepare("INSERT INTO contact_messages (name, email, phone, subject, message) VALUES (?,?,?,?,?)");
            $stmt->execute([$name, $email, safeCut(trim($_POST['phone'] ?? ''), 30), safeCut(trim($_POST['subject'] ?? ''), 200), $message]);
            $success = true;
        }
    }
}

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>
<?php
$heroEyebrow = 'Kontak';
$heroTitle = 'Kontak Kami';
$heroText = 'Hubungi kami untuk informasi, pertanyaan, atau kerja sama.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['Kontak', null]];
$heroImage = 'assets/images/image.png';
include __DIR__ . '/includes/page-hero.php';
?>

<section>
  <div class="container contact-layout">
    <div class="contact-info-card reveal">
      <h3>Informasi Kontak</h3>
      <div class="contact-info-item"><i class="fa-solid fa-location-dot"></i><div><strong>Alamat</strong><p><?= e($profile['address'] ?? '[ALAMAT SEKOLAH]') ?></p></div></div>
      <div class="contact-info-item"><i class="fa-solid fa-phone"></i><div><strong>Telepon</strong><p><?= e($profile['phone'] ?? '[NOMOR TELEPON]') ?></p></div></div>
      <div class="contact-info-item"><i class="fa-solid fa-envelope"></i><div><strong>Email</strong><p><?= e($profile['email'] ?? '[EMAIL SEKOLAH]') ?></p></div></div>
      <div class="contact-info-item"><i class="fa-solid fa-clock"></i><div><strong>Jam Operasional</strong><p><?= e($profile['operating_hours'] ?? '-') ?></p></div></div>
      <div class="footer-social" style="margin-top:10px;">
        <?php foreach ($pdo->query('SELECT * FROM social_media ORDER BY sort_order') as $sm): ?>
          <a href="<?= e($sm['url']) ?>" target="_blank" rel="noopener" style="background:var(--navy-800);color:#fff;" aria-label="<?= e($sm['platform']) ?>"><i class="<?= e($sm['icon']) ?>"></i></a>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="contact-map reveal">
      <?php if (!empty($profile['map_embed'])): ?>
        <?= $profile['map_embed'] ?>
      <?php else: ?>
        <iframe src="https://www.google.com/maps?q=<?= urlencode($profile['address'] ?? 'SMK INFOKOM BOGOR') ?>&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      <?php endif; ?>
    </div>
  </div>
</section>

<section class="section-alt">
  <div class="container">
    <div class="section-head reveal"><span class="eyebrow">Hubungi Kami</span><h2>Kirim Pesan</h2></div>
    <?php if ($success): ?>
      <div class="form-card text-center form-success" data-toast="success" data-title="Pesan terkirim" data-message="Terima kasih, kami akan segera menindaklanjuti.">
        <span class="form-success-ico"><i class="fa-solid fa-check"></i></span>
        <h3>Pesan Terkirim</h3>
        <p>Terima kasih, pesan Anda telah kami terima dan akan segera ditindaklanjuti.</p>
      </div>
    <?php else: ?>
      <?php if (!empty($errors)): ?>
        <div class="form-alert form-alert-error" data-toast="error" data-title="Pesan belum terkirim" data-message="<?= e($errors[0]) ?>">
          <span class="form-alert-ico"><i class="fa-solid fa-triangle-exclamation"></i></span><div>
          <?php foreach ($errors as $err): ?><p class="form-error"><?= e($err) ?></p><?php endforeach; ?></div>
        </div>
      <?php endif; ?>
      <form method="post" class="form-card reveal" style="max-width:640px;margin:0 auto;">
        <?= csrfField() ?>
        <div class="form-group"><label>Nama <span class="req">*</span></label><input type="text" name="name" maxlength="150" class="form-control" required value="<?= e($_POST['name'] ?? '') ?>"></div>
        <div class="form-group"><label>Email <span class="req">*</span></label><input type="email" name="email" maxlength="100" class="form-control" required value="<?= e($_POST['email'] ?? '') ?>"></div>
        <div class="form-group"><label>Nomor HP</label><input type="text" name="phone" maxlength="30" class="form-control" value="<?= e($_POST['phone'] ?? '') ?>"></div>
        <div class="form-group"><label>Subjek</label><input type="text" name="subject" maxlength="200" class="form-control" value="<?= e($_POST['subject'] ?? '') ?>"></div>
        <div class="form-group"><label>Pesan <span class="req">*</span></label><textarea name="message" class="form-control" required><?= e($_POST['message'] ?? '') ?></textarea></div>
        <button type="submit" class="btn btn-primary btn-block">Kirim Pesan</button>
      </form>
    <?php endif; ?>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>

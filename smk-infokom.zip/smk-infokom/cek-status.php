<?php
require_once __DIR__ . '/includes/functions.php';
$bodyClass = 'pf-form page-profil';
$pdo = getDB();
$pageTitle = 'Cek Status PPDB';

$reg = null;
$notFound = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $no = trim($_POST['registration_number'] ?? '');
    if ($no !== '') {
        $stmt = $pdo->prepare("SELECT r.*, p.name AS program_name FROM ppdb_registrations r LEFT JOIN programs p ON p.id = r.program_id WHERE registration_number = ? LIMIT 1");
        $stmt->execute([$no]);
        $reg = $stmt->fetch();
        if (!$reg) $notFound = true;
    }
}

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';

$statusClass = [
    'Menunggu' => 'status-menunggu',
    'Diverifikasi' => 'status-diverifikasi',
    'Diterima' => 'status-diterima',
    'Ditolak' => 'status-ditolak',
];
?>
<?php
$heroEyebrow = 'PPDB';
$heroTitle = 'Cek Status Pendaftaran';
$heroText = 'Pantau perkembangan pendaftaran Anda menggunakan nomor pendaftaran.';
$heroCrumbs = [['Beranda', BASE_URL . 'index.php'], ['PPDB', BASE_URL . 'ppdb.php'], ['Cek Status', null]];
include __DIR__ . '/includes/page-hero.php';
?>

<section>
  <div class="container" style="max-width:640px;">
    <form method="post" class="form-card reveal">
      <?= csrfField() ?>
      <div class="form-group">
        <label>Nomor Pendaftaran <span class="req">*</span></label>
        <input type="text" name="registration_number" class="form-control" placeholder="Contoh: PPDB-2026-00001" required
               value="<?= e($_POST['registration_number'] ?? '') ?>">
      </div>
      <button type="submit" class="btn btn-primary btn-block">Cek Status</button>
    </form>

    <?php if ($notFound): ?>
      <div class="empty-state reveal"><i class="fa-solid fa-circle-exclamation"></i><p>Nomor pendaftaran tidak ditemukan. Periksa kembali penulisan nomor Anda.</p></div>
    <?php elseif ($reg): ?>
      <div class="form-card reveal" style="margin-top:24px;">
        <h3>Detail Pendaftaran</h3>
        <table class="detail-table">
          <tr><td class="dt-label">Nomor Pendaftaran</td><td class="dt-value"><?= e($reg['registration_number']) ?></td></tr>
          <tr><td class="dt-label">Nama</td><td class="dt-value"><?= e($reg['full_name']) ?></td></tr>
          <tr><td class="dt-label">Jurusan</td><td class="dt-value"><?= e($reg['program_name'] ?? '-') ?></td></tr>
          <tr><td class="dt-label">Tanggal Daftar</td><td class="dt-value"><?= tanggalIndo($reg['created_at']) ?></td></tr>
          <tr><td class="dt-label">Status</td><td class="dt-value"><span class="status-badge <?= $statusClass[$reg['status']] ?? '' ?>"><?= e($reg['status']) ?></span></td></tr>
          <?php if (!empty($reg['admin_note'])): ?>
          <tr><td class="dt-label">Keterangan</td><td class="dt-value"><?= e($reg['admin_note']) ?></td></tr>
          <?php endif; ?>
        </table>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
